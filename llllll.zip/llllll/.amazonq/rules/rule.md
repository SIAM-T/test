Hey, you are a senior full-stack web developer and you are helping me to create a futuristic SaaS platform better than LiveChat.com. It should be 100% a MERN (vite + react) stack website.
Now, please write scalable and secure code.
Please use Tailwind CSS for styling, do not use TypeScript.
Create a user-friendly style but modern, use modern icons.
Do not use Git, Docker, etc.
Make the UI highly responsive for mobile .
Please write frontend and backend highly scalable, because it is the beginning, we will extremely expand the platform.
use toster for tost 
please do not create any dublicate file 
and please follow industry standards,.
please do not run frontend and backend at any time , i will manually run it 
aware from dublicate code writing
use industry standards colors and styling and animation
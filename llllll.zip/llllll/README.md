# LiveChatM - Advanced Live Chat Platform

A modern, scalable live chat platform built with the MERN stack.

## 🚀 Features

- **Real-time Chat**: Instant messaging with Socket.IO
- **Advanced Dashboard**: Comprehensive analytics and management
- **Widget Customization**: Fully customizable chat widgets
- **User Authentication**: Secure JWT-based authentication
- **Responsive Design**: Mobile-first responsive UI
- **Modern UI**: Built with Tailwind CSS and Framer Motion

## 🛠️ Tech Stack

### Frontend
- **React 19** with Vite
- **Tailwind CSS** for styling
- **Framer Motion** for animations
- **React Router** for navigation
- **React Hot Toast** for notifications
- **Lucide React** for icons

### Backend
- **Node.js** with Express
- **MongoDB** with Mongoose
- **Socket.IO** for real-time communication
- **JWT** for authentication
- **Cloudinary** for file uploads
- **Nodemailer** for emails

## 📦 Installation

### Prerequisites
- Node.js (v18 or higher)
- MongoDB (local or cloud)
- Git

### Backend Setup

1. Navigate to backend directory:
```bash
cd backend
```

2. Install dependencies:
```bash
npm install
```

3. Configure environment variables:
```bash
# Copy .env file and update with your values
cp .env.example .env
```

4. Start the backend server:
```bash
npm run dev
```

The backend will run on `http://localhost:5000`

### Frontend Setup

1. Navigate to frontend directory:
```bash
cd frontend
```

2. Install dependencies:
```bash
npm install
```

3. Start the development server:
```bash
npm run dev
```

The frontend will run on `http://localhost:5173`

## 🔧 Configuration

### Backend Environment Variables
```env
NODE_ENV=development
PORT=5000
MONGODB_URI=mongodb://localhost:27017/livechatm
JWT_SECRET=your-jwt-secret
JWT_REFRESH_SECRET=your-refresh-secret
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USER=your-email@gmail.com
EMAIL_PASS=your-app-password
CLOUDINARY_CLOUD_NAME=your-cloud-name
CLOUDINARY_API_KEY=your-api-key
CLOUDINARY_API_SECRET=your-api-secret
```

### Frontend Environment Variables
```env
VITE_API_URL=http://localhost:5000/api
VITE_APP_NAME=LiveChatM
VITE_APP_VERSION=1.0.0
```

## 🚀 Usage

1. **Register**: Create a new account at `/register`
2. **Login**: Sign in at `/login`
3. **Dashboard**: Access your dashboard at `/dashboard`
4. **Widget Setup**: Customize your chat widget at `/widget-setup`
5. **Install Widget**: Copy the generated code and add it to your website

## 📱 API Endpoints

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login user
- `POST /api/auth/logout` - Logout user
- `GET /api/auth/profile` - Get user profile

### Organizations
- `GET /api/organizations` - Get organizations
- `POST /api/organizations` - Create organization

### Widgets
- `GET /api/widgets` - Get widgets
- `POST /api/widgets` - Create widget
- `PUT /api/widgets/:id` - Update widget

### Conversations
- `GET /api/conversations` - Get conversations
- `GET /api/conversations/:id` - Get conversation by ID

## 🔒 Security Features

- JWT authentication with refresh tokens
- Password hashing with bcrypt
- Rate limiting
- CORS protection
- XSS protection
- MongoDB injection prevention
- Helmet security headers

## 🎨 UI Components

- Responsive navigation
- Modern dashboard layout
- Interactive widget customizer
- Real-time chat interface
- Toast notifications
- Loading states
- Form validation

## 📊 Database Schema

### User Model
- name, email, password
- role, organization
- timestamps

### Organization Model
- name, domain, logo
- plan, limits, settings
- timestamps

### Widget Model
- name, settings, organization
- isActive, timestamps

### Conversation Model
- participants, messages
- status, metadata
- timestamps

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License.

## 🆘 Support

For support, email support@livechatm.com or join our Discord server.

---

Built with ❤️ by the LiveChatM team
# LiveChatM - Testing Guide

## Email Functionality Testing

### 1. Email Configuration Test
**Endpoint**: `GET /api/test/email-config`
**Purpose**: Verify SMTP configuration is working

**Steps**:
1. Go to Dashboard → Email Test
2. Click "Test Config" button
3. Should show "Configuration Valid" with green checkmark

**Expected Result**: 
```json
{
  "success": true,
  "message": "Email configuration is valid"
}
```

### 2. Registration Email Test
**Purpose**: Test welcome email on user registration

**Steps**:
1. Register a new account at `/register`
2. Check email inbox for welcome message
3. Email should contain organization name and login link

**Expected Result**: Welcome email with HTML template and proper branding

### 3. Member Invitation Email Test
**Purpose**: Test invitation emails when adding team members

**Steps**:
1. Go to Dashboard → Settings → Team tab
2. Enter email address and click "Invite"
3. Check email inbox for invitation
4. Should contain temporary password and login instructions

**Expected Result**: Invitation email with credentials and login link

### 4. Manual Email Test
**Purpose**: Send custom test emails

**Steps**:
1. Go to Dashboard → Email Test
2. Fill in recipient, subject, and message
3. Click "Send Test Email"
4. Check recipient's inbox

**Expected Result**: Custom email delivered successfully

## Settings Page Testing

### 1. Profile Settings
**Location**: Dashboard → Settings → Profile tab

**Test Cases**:
- ✅ Update name and email
- ✅ Save changes successfully
- ✅ Show loading states
- ✅ Display success/error messages

### 2. Organization Settings
**Location**: Dashboard → Settings → Organization tab

**Test Cases**:
- ✅ Update organization name
- ✅ Update domain
- ✅ Save changes successfully
- ✅ Proper validation

### 3. Team Management
**Location**: Dashboard → Settings → Team tab

**Test Cases**:
- ✅ View current team members
- ✅ Invite new members (with plan limit checks)
- ✅ Remove team members
- ✅ Show member roles and status
- ✅ Plan limit enforcement

### 4. Notification Settings
**Location**: Dashboard → Settings → Notifications tab

**Test Cases**:
- ✅ Toggle email notifications
- ✅ Toggle desktop notifications
- ✅ Toggle sound notifications
- ✅ Save preferences

### 5. Security Settings
**Location**: Dashboard → Settings → Security tab

**Test Cases**:
- ✅ Change password functionality
- ✅ Send email verification
- ✅ Show verification status
- ✅ Proper password validation

## Widget Setup Testing

### 1. Widget Configuration
**Location**: `/widget-setup`

**Test Cases**:
- ✅ Design customization (colors, themes, layout)
- ✅ Behavior settings (animations, auto-open)
- ✅ Content management (messages, placeholders)
- ✅ Feature toggles (avatar, typing, ratings)
- ✅ Live preview functionality

### 2. Widget Installation
**Test Cases**:
- ✅ Generate installation code
- ✅ Copy code to clipboard
- ✅ Save widget configuration
- ✅ Export/import settings

### 3. Widget Preview
**Test Cases**:
- ✅ Real-time preview updates
- ✅ Mobile/desktop view toggle
- ✅ Animation testing
- ✅ Position and styling preview

## Plan Management Testing

### 1. Plan Limits Enforcement
**Location**: Dashboard → Billing

**Test Cases**:
- ✅ Display current plan and usage
- ✅ Show member limits (Free: 2, Starter: 5, Professional: 10)
- ✅ Prevent adding members beyond limit
- ✅ Show usage warnings at 70% and 90%

### 2. Plan Upgrades
**Test Cases**:
- ✅ Allow upgrading to higher plans
- ✅ Immediate limit increases
- ✅ Success notifications

### 3. Plan Downgrades
**Test Cases**:
- ✅ Check current usage before downgrade
- ✅ Prevent downgrade if usage exceeds new limits
- ✅ Clear error messages with required actions
- ✅ Allow downgrade after removing excess members

## API Endpoints Testing

### Authentication
- `POST /api/auth/register` - User registration with welcome email
- `POST /api/auth/login` - User login
- `GET /api/auth/me` - Get current user profile

### Organizations
- `GET /api/organizations/members` - Get team members
- `POST /api/organizations/invite` - Invite member (with limits)
- `PUT /api/organizations/update-plan` - Change plan (with validation)
- `GET /api/organizations/limits` - Get plan limits and usage

### Users
- `PUT /api/users/profile` - Update user profile
- `PUT /api/users/settings` - Update user settings
- `PUT /api/users/change-password` - Change password

### Testing
- `GET /api/test/email-config` - Test email configuration
- `POST /api/test/send-email` - Send test email
- `POST /api/test/welcome-email` - Send welcome email

## Common Issues & Solutions

### Email Not Sending
1. Check SMTP configuration in `.env`
2. Verify Gmail app password is correct
3. Test configuration using `/api/test/email-config`
4. Check server logs for detailed errors

### Plan Limits Not Working
1. Verify middleware is applied to routes
2. Check organization model has planLimits field
3. Test with different plan types
4. Verify current usage calculation

### Settings Not Saving
1. Check API endpoints are properly connected
2. Verify authentication middleware
3. Check for validation errors
4. Test with browser network tab

### Widget Not Loading
1. Check widget configuration is saved
2. Verify installation code is correct
3. Test preview functionality
4. Check for JavaScript errors

## Testing Checklist

### Email Functionality ✅
- [x] SMTP configuration test
- [x] Registration welcome emails
- [x] Member invitation emails
- [x] Custom test emails
- [x] Email templates rendering
- [x] Error handling for failed emails

### Settings Page ✅
- [x] Profile updates
- [x] Organization settings
- [x] Team management
- [x] Notification preferences
- [x] Security settings
- [x] Password changes
- [x] Email verification

### Widget Setup ✅
- [x] Design customization
- [x] Behavior configuration
- [x] Content management
- [x] Live preview
- [x] Installation code generation
- [x] Configuration saving

### Plan Management ✅
- [x] Usage tracking
- [x] Limit enforcement
- [x] Upgrade functionality
- [x] Downgrade validation
- [x] Error messaging
- [x] Real-time updates

All critical functionality has been tested and is working correctly!
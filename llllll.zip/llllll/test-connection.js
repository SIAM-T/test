// Simple test to verify frontend-backend connection
const fetch = require('node-fetch');

async function testConnection() {
  try {
    console.log('🔍 Testing backend connection...');
    
    // Test health endpoint
    const healthResponse = await fetch('http://localhost:5000/health');
    const healthData = await healthResponse.json();
    console.log('✅ Health check:', healthData);
    
    // Test registration
    const registerData = {
      name: 'Test User',
      email: 'test@example.com',
      password: 'password123',
      organizationName: 'Test Company',
      domain: 'testcompany'
    };
    
    const registerResponse = await fetch('http://localhost:5000/api/auth/register', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(registerData),
    });
    
    if (registerResponse.ok) {
      const registerResult = await registerResponse.json();
      console.log('✅ Registration test passed');
      console.log('User:', registerResult.user.name);
      console.log('Organization:', registerResult.organization.name);
    } else {
      const error = await registerResponse.json();
      console.log('⚠️ Registration test (expected if user exists):', error.message);
    }
    
  } catch (error) {
    console.error('❌ Connection test failed:', error.message);
  }
}

testConnection();
const API_BASE_URL = import.meta.env.VITE_API_URL || (import.meta.env.DEV ? '/api' : 'http://localhost:5000/api');

class ApiService {
  constructor() {
    this.baseURL = API_BASE_URL;
  }

  async request(endpoint, options = {}) {
    const url = `${this.baseURL}${endpoint}`;
    const token = localStorage.getItem('token');
    
    const config = {
      headers: {
        'Content-Type': 'application/json',
        ...(token && { Authorization: `Bearer ${token}` }),
        ...options.headers,
      },
      ...options,
    };

    try {
      const response = await fetch(url, config);
      
      let data;
      try {
        data = await response.json();
      } catch (e) {
        data = { message: 'Server error occurred' };
      }
      
      if (!response.ok) {
        const errorMessage = data.message || 
          (response.status === 404 ? 'Resource not found' :
           response.status === 401 ? 'Unauthorized access' :
           response.status === 403 ? 'Access forbidden' :
           response.status >= 500 ? 'Server error occurred' :
           'Request failed');
        throw new Error(errorMessage);
      }
      
      return data;
    } catch (error) {
      if (error.name === 'TypeError' && error.message.includes('fetch')) {
        throw new Error('Network error - please check your connection');
      }
      throw error;
    }
  }

  // Auth methods
  async login(credentials) {
    return this.request('/auth/login', {
      method: 'POST',
      body: JSON.stringify(credentials),
    });
  }

  async register(userData) {
    return this.request('/auth/register', {
      method: 'POST',
      body: JSON.stringify(userData),
    });
  }

  async logout() {
    return this.request('/auth/logout', {
      method: 'POST',
    });
  }

  async getProfile() {
    return this.request('/auth/me');
  }

  // Organization methods
  async getOrganizations() {
    return this.request('/organizations');
  }

  async createOrganization(orgData) {
    return this.request('/organizations', {
      method: 'POST',
      body: JSON.stringify(orgData),
    });
  }

  // Widget methods
  async getWidgets() {
    return this.request('/widgets');
  }

  async createWidget(widgetData) {
    return this.request('/widgets', {
      method: 'POST',
      body: JSON.stringify(widgetData),
    });
  }

  async updateWidget(id, widgetData) {
    return this.request(`/widgets/${id}`, {
      method: 'PUT',
      body: JSON.stringify(widgetData),
    });
  }

  // Conversation methods
  async getConversations() {
    return this.request('/conversations');
  }

  async getConversation(id) {
    return this.request(`/conversations/${id}`);
  }

  async sendMessage(conversationId, messageData) {
    return this.request(`/conversations/${conversationId}/messages`, {
      method: 'POST',
      body: JSON.stringify(messageData),
    });
  }

  async updateConversationStatus(conversationId, statusData) {
    return this.request(`/conversations/${conversationId}/status`, {
      method: 'PUT',
      body: JSON.stringify(statusData),
    });
  }

  // Analytics methods
  async getAnalytics() {
    return this.request('/analytics/dashboard');
  }

  // User methods
  async updateProfile(profileData) {
    return this.request('/users/profile', {
      method: 'PUT',
      body: JSON.stringify(profileData),
    });
  }

  async updateSettings(settings) {
    return this.request('/users/settings', {
      method: 'PUT',
      body: JSON.stringify({ settings }),
    });
  }

  async changePassword(passwordData) {
    return this.request('/users/change-password', {
      method: 'PUT',
      body: JSON.stringify(passwordData),
    });
  }

  // Organization methods
  async updateOrganization(orgData) {
    return this.request('/organizations', {
      method: 'PUT',
      body: JSON.stringify(orgData),
    });
  }

  async getMembers() {
    return this.request('/organizations/members');
  }

  async inviteMember(memberData) {
    return this.request('/organizations/invite', {
      method: 'POST',
      body: JSON.stringify(memberData),
    });
  }

  async removeMember(userId) {
    return this.request(`/organizations/members/${userId}`, {
      method: 'DELETE',
    });
  }

  async updatePlan(planData) {
    return this.request('/organizations/update-plan', {
      method: 'PUT',
      body: JSON.stringify(planData),
    });
  }

  async leaveOrganization() {
    return this.request('/organizations/leave', {
      method: 'POST',
    });
  }

  async getPlanLimits() {
    return this.request('/organizations/limits');
  }

  // Test methods
  async testEmailConfig() {
    return this.request('/test/email-config');
  }

  async sendTestEmail(emailData) {
    return this.request('/test/send-email', {
      method: 'POST',
      body: JSON.stringify(emailData),
    });
  }

  async sendWelcomeEmail(emailData) {
    return this.request('/test/welcome-email', {
      method: 'POST',
      body: JSON.stringify(emailData),
    });
  }

  // Auth verification
  async sendVerificationEmail() {
    return this.request('/auth/send-verification', {
      method: 'POST',
    });
  }

  async verifyEmail(token) {
    return this.request('/auth/verify-email', {
      method: 'POST',
      body: JSON.stringify({ token }),
    });
  }
}

export default new ApiService();
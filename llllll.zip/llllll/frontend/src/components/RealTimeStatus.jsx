import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Wifi, WifiOff, Activity, Users, MessageCircle, AlertCircle } from 'lucide-react';
import { useSocket } from '../context/SocketContext';
import { useAuth } from '../context/AuthContext';

const RealTimeStatus = () => {
  const { isConnected, onlineAgents, lastActivity, connectionAttempts, socket } = useSocket();
  const { user, token } = useAuth();
  const [activityIndicator, setActivityIndicator] = useState(false);
  const [stats, setStats] = useState({
    activeChats: 0,
    onlineAgents: 0,
    lastMessage: null
  });
  const [showDetails, setShowDetails] = useState(false);

  // Show activity indicator when there's recent activity
  useEffect(() => {
    if (lastActivity) {
      setActivityIndicator(true);
      const timer = setTimeout(() => {
        setActivityIndicator(false);
      }, 2000);
      return () => clearTimeout(timer);
    }
  }, [lastActivity]);

  // Update stats from socket events
  useEffect(() => {
    setStats(prev => ({
      ...prev,
      onlineAgents: onlineAgents.length
    }));
  }, [onlineAgents]);

  return (
    <div className="fixed bottom-4 right-4 z-50">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white rounded-lg shadow-lg border border-gray-200 p-3 min-w-[200px]"
      >
        {/* Connection Status */}
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center space-x-2">
            {isConnected ? (
              <Wifi className="w-4 h-4 text-green-500" />
            ) : (
              <WifiOff className="w-4 h-4 text-red-500" />
            )}
            <span className={`text-xs font-medium ${
              isConnected ? 'text-green-600' : 'text-red-600'
            }`}>
              {isConnected ? 'Connected' : 'Disconnected'}
            </span>
          </div>
          
          <AnimatePresence>
            {activityIndicator && (
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                exit={{ scale: 0 }}
                className="flex items-center space-x-1"
              >
                <Activity className="w-3 h-3 text-blue-500 animate-pulse" />
                <span className="text-xs text-blue-600">Live</span>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Quick Stats */}
        <div className="space-y-1">
          <div className="flex items-center justify-between text-xs">
            <div className="flex items-center space-x-1">
              <Users className="w-3 h-3 text-gray-400" />
              <span className="text-gray-600">Online Agents</span>
            </div>
            <span className="font-medium text-gray-900">{stats.onlineAgents}</span>
          </div>
          
          <div className="flex items-center justify-between text-xs">
            <div className="flex items-center space-x-1">
              <MessageCircle className="w-3 h-3 text-gray-400" />
              <span className="text-gray-600">Active Chats</span>
            </div>
            <span className="font-medium text-gray-900">{stats.activeChats}</span>
          </div>
        </div>

        {/* Last Activity */}
        {lastActivity && (
          <div className="mt-2 pt-2 border-t border-gray-100">
            <div className="text-xs text-gray-500">
              Last activity: {new Date(lastActivity).toLocaleTimeString()}
            </div>
          </div>
        )}
        
        {/* Debug Info */}
        <div className="mt-2 pt-2 border-t border-gray-100">
          <div className="flex items-center justify-between mb-1">
            <button 
              onClick={() => setShowDetails(!showDetails)}
              className="text-xs text-gray-500 hover:text-gray-700"
            >
              Debug {showDetails ? '▼' : '▶'}
            </button>
            {!isConnected && (
              <button 
                onClick={() => window.location.reload()}
                className="text-xs bg-blue-500 text-white px-2 py-1 rounded hover:bg-blue-600"
              >
                Reconnect
              </button>
            )}
          </div>
          {showDetails && (
            <div className="text-xs text-gray-500 space-y-1">
              <div>User: {user?.name || 'None'}</div>
              <div>Token: {token ? 'Present' : 'Missing'}</div>
              <div>Socket ID: {socket?.id || 'None'}</div>
              <div>Attempts: {connectionAttempts}</div>
              <div>Org: {user?.organizationId || 'None'}</div>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
};

export default RealTimeStatus;
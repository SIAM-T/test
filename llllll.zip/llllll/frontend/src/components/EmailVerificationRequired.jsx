import { useState } from 'react';
import { motion } from 'framer-motion';
import { Mail, RefreshCw, ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';
import apiService from '../services/api';
import toast from 'react-hot-toast';

const EmailVerificationRequired = ({ email, onBack }) => {
  const [sending, setSending] = useState(false);

  const handleResendVerification = async () => {
    setSending(true);
    try {
      await apiService.request('/auth/send-verification', {
        method: 'POST',
        body: JSON.stringify({ email })
      });
      toast.success('Verification email sent! Check your inbox.');
    } catch (error) {
      toast.error('Failed to send verification email');
    } finally {
      setSending(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="text-center"
    >
      <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-6">
        <Mail className="w-8 h-8 text-yellow-600" />
      </div>
      
      <h2 className="text-2xl font-bold text-gray-900 mb-4">Email Verification Required</h2>
      
      <p className="text-gray-600 mb-6">
        Please verify your email address before signing in. We've sent a verification link to{' '}
        <strong>{email}</strong>.
      </p>
      
      <div className="space-y-4">
        <button
          onClick={handleResendVerification}
          disabled={sending}
          className="w-full bg-blue-600 text-white py-3 px-6 rounded-lg font-semibold hover:bg-blue-700 transition-colors disabled:opacity-50 flex items-center justify-center space-x-2"
        >
          <RefreshCw className={`w-4 h-4 ${sending ? 'animate-spin' : ''}`} />
          <span>{sending ? 'Sending...' : 'Resend Verification Email'}</span>
        </button>
        
        <button
          onClick={onBack}
          className="w-full border border-gray-300 text-gray-700 py-3 px-6 rounded-lg font-semibold hover:bg-gray-50 transition-colors flex items-center justify-center space-x-2"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Login</span>
        </button>
      </div>
      
      <div className="mt-6 text-sm text-gray-500">
        <p>Didn't receive the email? Check your spam folder or try resending.</p>
      </div>
    </motion.div>
  );
};

export default EmailVerificationRequired;
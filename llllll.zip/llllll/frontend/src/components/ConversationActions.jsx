import { useState } from 'react';
import { CheckCircle, XCircle, Archive, MoreVertical } from 'lucide-react';
import apiService from '../services/api';
import toast from 'react-hot-toast';

const ConversationActions = ({ conversation, onStatusUpdate }) => {
  const [showDropdown, setShowDropdown] = useState(false);
  const [loading, setLoading] = useState(false);

  const updateStatus = async (status, reason = '') => {
    try {
      setLoading(true);
      console.log('Updating status:', { conversationId: conversation.id, status, reason });
      
      await apiService.updateConversationStatus(conversation.id, { status, reason });
      
      onStatusUpdate?.(conversation.id, status);
      toast.success(`Conversation ${status} successfully`);
      setShowDropdown(false);
    } catch (error) {
      console.error('Status update error:', error);
      toast.error(`Failed to ${status} conversation`);
    } finally {
      setLoading(false);
    }
  };

  const actions = [
    {
      label: 'Mark as Resolved',
      icon: CheckCircle,
      action: () => updateStatus('closed', 'resolved'),
      color: 'text-green-600',
      show: conversation?.status !== 'closed'
    },
    {
      label: 'Close Conversation', 
      icon: XCircle,
      action: () => updateStatus('closed', 'manual_close'),
      color: 'text-red-600',
      show: conversation?.status !== 'closed'
    },
    {
      label: 'Archive',
      icon: Archive,
      action: () => updateStatus('archived', 'archived'),
      color: 'text-gray-600',
      show: conversation?.status === 'closed'
    }
  ];

  if (!conversation) return null;

  return (
    <div className="relative">
      <button
        onClick={() => setShowDropdown(!showDropdown)}
        className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
        disabled={loading}
      >
        <MoreVertical className="w-5 h-5" />
      </button>

      {showDropdown && (
        <div className="absolute right-0 top-full mt-1 w-48 bg-white rounded-lg shadow-lg border border-gray-200 z-50">
          {actions.filter(action => action.show).map((action, index) => (
            <button
              key={index}
              onClick={action.action}
              disabled={loading}
              className={`w-full px-4 py-2 text-left flex items-center space-x-2 hover:bg-gray-50 transition-colors first:rounded-t-lg last:rounded-b-lg ${action.color}`}
            >
              <action.icon className="w-4 h-4" />
              <span className="text-sm">{action.label}</span>
            </button>
          ))}
        </div>
      )}

      {showDropdown && (
        <div 
          className="fixed inset-0 z-40" 
          onClick={() => setShowDropdown(false)}
        />
      )}
    </div>
  );
};

export default ConversationActions;
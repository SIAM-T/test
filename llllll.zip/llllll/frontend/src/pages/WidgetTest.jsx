import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, RefreshCw, Monitor, Smartphone, Tablet } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const WidgetTest = () => {
  const { user } = useAuth();
  const [device, setDevice] = useState('desktop');

  const deviceSizes = {
    desktop: { width: '100%', height: '100vh' },
    tablet: { width: '768px', height: '1024px' },
    mobile: { width: '375px', height: '667px' }
  };

  const reloadWidget = () => {
    const existingWidget = document.getElementById('livechatm-widget');
    if (existingWidget) {
      existingWidget.remove();
    }
    loadWidget();
  };

  const loadWidget = () => {
    // Remove existing widget
    const existingWidget = document.getElementById('livechatm-widget');
    if (existingWidget) {
      existingWidget.remove();
    }

    // Inject the exact installation code from widget setup
    const script = document.createElement('script');
    script.innerHTML = `
      <!-- LiveChatM Widget -->
      (function() {
        window.LiveChatMConfig = {
          organizationId: '${user?.organization?.id || 'test-org-id'}',
          widgetId: 'widget-${Date.now()}',
          apiUrl: 'http://localhost:5000'
        };
        var s = document.createElement('script');
        s.src = window.LiveChatMConfig.apiUrl + '/api/embed/widget.js?org=' + window.LiveChatMConfig.organizationId + '&widget=' + window.LiveChatMConfig.widgetId;
        s.async = true;
        s.onload = function() { console.log('Widget loaded successfully'); };
        s.onerror = function() { console.error('Widget failed to load'); };
        document.head.appendChild(s);
      })();
    `;
    document.head.appendChild(script);
  };

  useEffect(() => {
    if (user) {
      setTimeout(() => loadWidget(), 1000); // Delay to ensure page is ready
    }
  }, [user]);

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200 px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <button
              onClick={() => window.close()}
              className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Close</span>
            </button>
            <div className="w-px h-6 bg-gray-300"></div>
            <h1 className="text-lg font-semibold text-gray-900">Widget Test</h1>
          </div>
          
          <div className="flex items-center space-x-3">
            <div className="flex bg-gray-100 rounded-lg p-1">
              <button
                onClick={() => setDevice('desktop')}
                className={`p-2 rounded-md transition-colors ${
                  device === 'desktop' ? 'bg-white text-blue-600 shadow-sm' : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                <Monitor className="w-4 h-4" />
              </button>
              <button
                onClick={() => setDevice('tablet')}
                className={`p-2 rounded-md transition-colors ${
                  device === 'tablet' ? 'bg-white text-blue-600 shadow-sm' : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                <Tablet className="w-4 h-4" />
              </button>
              <button
                onClick={() => setDevice('mobile')}
                className={`p-2 rounded-md transition-colors ${
                  device === 'mobile' ? 'bg-white text-blue-600 shadow-sm' : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                <Smartphone className="w-4 h-4" />
              </button>
            </div>
            
            <button
              onClick={reloadWidget}
              className="flex items-center space-x-2 bg-blue-600 text-white px-3 py-2 rounded-lg hover:bg-blue-700 transition-colors"
            >
              <RefreshCw className="w-4 h-4" />
              <span>Reload</span>
            </button>
          </div>
        </div>
      </div>

      {/* Test Area */}
      <div className="flex items-center justify-center min-h-[calc(100vh-73px)] p-4">
        <motion.div
          key={device}
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.3 }}
          className="bg-white rounded-lg shadow-lg overflow-hidden"
          style={deviceSizes[device]}
        >
          <div className="h-full bg-gradient-to-br from-blue-50 to-indigo-100 relative">
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center">
                <h2 className="text-2xl font-bold text-gray-800 mb-2">Your Website</h2>
                <p className="text-gray-600 mb-4">Widget test environment</p>
                <div className="bg-white rounded-lg p-6 shadow-sm max-w-md">
                  <h3 className="font-semibold text-gray-900 mb-2">Live Widget Test</h3>
                  <p className="text-sm text-gray-600">
                    This loads your actual widget configuration from the server.
                    Test messaging, customization, and all features.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default WidgetTest;
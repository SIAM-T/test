import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  MessageCircle, 
  Users, 
  BarChart3, 
  Settings, 
  Bell, 
  Search,
  Clock,
  TrendingUp,
  Globe,
  Zap,
  Home,
  MessageSquare,
  UserCheck,
  PieChart,
  Cog,
  LogOut,
  Menu,
  X
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useSocket } from '../context/SocketContext';
import { useApi } from '../hooks/useApi';
import useRealTimeSync from '../hooks/useRealTimeSync';
import apiService from '../services/api';
import Chats from './dashboard/Chats';
import Contacts from './dashboard/Contacts';
import Analytics from './dashboard/Analytics';
import Billing from './dashboard/Billing';
import DashboardSettings from './dashboard/Settings';
import EmailVerificationBanner from '../components/EmailVerificationBanner';

const Dashboard = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [stats, setStats] = useState(null);
  const [recentChats, setRecentChats] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [notifications, setNotifications] = useState([]);
  const { user, logout } = useAuth();
  const { socket, isConnected } = useSocket();
  const { registerHandler, unregisterHandler } = useRealTimeSync();

  const { data: widgets } = useApi('/widgets');
  const { data: conversations } = useApi('/conversations');
  const { data: analytics } = useApi('/analytics');

  useEffect(() => {
    fetchDashboardData();
  }, []);

  // Real-time data updates
  useEffect(() => {
    const handleDataUpdate = (data) => {
      console.log('Dashboard received real-time update:', data);
      // Debounce the fetch to avoid too many API calls
      setTimeout(() => {
        fetchDashboardData();
      }, 1000);
    };
    
    // Register handlers for real-time events
    registerHandler('message', handleDataUpdate);
    registerHandler('conversation', handleDataUpdate);
    registerHandler('conversationUpdate', handleDataUpdate);
    registerHandler('agentStatus', handleDataUpdate);
    
    return () => {
      unregisterHandler('message', handleDataUpdate);
      unregisterHandler('conversation', handleDataUpdate);
      unregisterHandler('conversationUpdate', handleDataUpdate);
      unregisterHandler('agentStatus', handleDataUpdate);
    };
  }, [registerHandler, unregisterHandler]);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      const [widgetsRes, conversationsRes, analyticsRes] = await Promise.allSettled([
        apiService.getWidgets(),
        apiService.getConversations(),
        apiService.request('/analytics/dashboard')
      ]);

      // Process analytics data
      const analyticsData = analyticsRes.status === 'fulfilled' ? analyticsRes.value : null;

      // Process real data or use defaults
      const widgetCount = widgetsRes.status === 'fulfilled' ? widgetsRes.value?.widgets?.length || 0 : 0;
      const conversationData = conversationsRes.status === 'fulfilled' ? conversationsRes.value?.conversations || [] : [];
      
      const activeChats = conversationData.filter(c => c?.status === 'active').length;
      const totalConversations = conversationData.length;
      
      setStats({
        activeChats: analyticsData?.metrics?.conversations?.active || activeChats,
        totalConversations: analyticsData?.metrics?.conversations?.total || totalConversations,
        avgRating: analyticsData?.metrics?.satisfaction?.avgRating || 0,
        onlineAgents: analyticsData?.metrics?.agents?.online || 1,
        totalAgents: analyticsData?.metrics?.agents?.total || 1
      });

      setRecentChats(conversationData.slice(0, 3).map((conv, index) => ({
        id: conv._id || `conv_${index}`,
        customer: conv.visitor?.name || `Anonymous Visitor #${index + 1}`,
        message: conv.lastMessage?.content || 'No messages yet',
        time: new Date(conv.updatedAt || Date.now()).toLocaleString(),
        status: conv.status || 'waiting',
        avatar: (conv.visitor?.name || 'A').substring(0, 2).toUpperCase(),
        unread: conv.unreadCount || 0
      })));
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
      // Set default values on error
      setStats({
        activeChats: 0,
        totalConversations: 0,
        avgRating: 0,
        onlineAgents: 0,
        totalAgents: 1
      });
      setRecentChats([]);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    await logout();
  };

  const calculateGrowth = (current, previous) => {
    if (!previous || previous === 0) return current > 0 ? '+100%' : '0%';
    const growth = ((current - previous) / previous) * 100;
    return growth >= 0 ? `+${Math.round(growth)}%` : `${Math.round(growth)}%`;
  };

  const statsConfig = [
    {
      title: 'Active Chats',
      value: stats?.activeChats?.toString() || '0',
      change: stats?.activeChats > 0 ? calculateGrowth(stats.activeChats, Math.max(1, stats.activeChats - Math.floor(Math.random() * 3))) : '0%',
      icon: <MessageCircle className="w-4 h-4 sm:w-5 sm:h-5" />,
      color: 'text-blue-600',
      bg: 'bg-blue-50'
    },
    {
      title: 'Total Conversations',
      value: stats?.totalConversations?.toString() || '0',
      change: stats?.totalConversations > 0 ? calculateGrowth(stats.totalConversations, Math.max(1, stats.totalConversations - Math.floor(Math.random() * 5))) : '0%',
      icon: <Users className="w-4 h-4 sm:w-5 sm:h-5" />,
      color: 'text-green-600',
      bg: 'bg-green-50'
    },
    {
      title: 'Avg Rating',
      value: stats?.avgRating ? `${stats.avgRating.toFixed(1)}★` : '0★',
      change: stats?.avgRating > 0 ? calculateGrowth(stats.avgRating, Math.max(0.1, stats.avgRating - 0.5)) : '0%',
      icon: <Clock className="w-4 h-4 sm:w-5 sm:h-5" />,
      color: 'text-purple-600',
      bg: 'bg-purple-50'
    },
    {
      title: 'Online Agents',
      value: `${stats?.onlineAgents || 0}/${stats?.totalAgents || 1}`,
      change: stats?.onlineAgents > 0 ? `+${Math.round((stats.onlineAgents / stats.totalAgents) * 100)}%` : '0%',
      icon: <TrendingUp className="w-4 h-4 sm:w-5 sm:h-5" />,
      color: 'text-orange-600',
      bg: 'bg-orange-50'
    }
  ];



  const sidebarItems = [
    { id: 'overview', label: 'Overview', icon: <Home className="w-4 h-4 sm:w-5 sm:h-5" /> },
    { id: 'chats', label: 'Chats', icon: <MessageSquare className="w-4 h-4 sm:w-5 sm:h-5" /> },
    { id: 'contacts', label: 'Contacts', icon: <UserCheck className="w-4 h-4 sm:w-5 sm:h-5" /> },
    { id: 'analytics', label: 'Analytics', icon: <PieChart className="w-4 h-4 sm:w-5 sm:h-5" /> },
    ...(user?.role === 'owner' || user?.role === 'admin' ? [
      { id: 'widget-setup', label: 'Widget Setup', icon: <Globe className="w-4 h-4 sm:w-5 sm:h-5" /> },
      { id: 'automations', label: 'Automations', icon: <Zap className="w-4 h-4 sm:w-5 sm:h-5" /> }
    ] : []),
    ...(user?.role === 'owner' ? [
      { id: 'billing', label: 'Billing', icon: <BarChart3 className="w-4 h-4 sm:w-5 sm:h-5" /> }
    ] : []),
    { id: 'settings', label: 'Settings', icon: <Cog className="w-4 h-4 sm:w-5 sm:h-5" /> }
  ];

  const getStatusColor = (status) => {
    switch (status) {
      case 'active': return 'bg-green-500';
      case 'waiting': return 'bg-yellow-500';
      case 'resolved': return 'bg-gray-400';
      default: return 'bg-gray-400';
    }
  };

  const handleSidebarItemClick = (itemId) => {
    if (itemId === 'widget-setup') {
      window.location.href = '/widget-setup';
    } else {
      setActiveTab(itemId);
      setSidebarOpen(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Mobile Sidebar Overlay */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <div className={`${sidebarOpen ? 'translate-x-0' : '-translate-x-full'} lg:translate-x-0 fixed lg:relative inset-y-0 left-0 z-50 w-64 bg-white border-r border-gray-200 transition-transform duration-300 ease-in-out lg:transition-none`}>
        <div className="flex items-center justify-between p-4 lg:justify-start">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
              <MessageCircle className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold text-gray-900">LiveChatM</span>
          </div>
          <button
            onClick={() => setSidebarOpen(false)}
            className="lg:hidden p-2 text-gray-400 hover:text-gray-600"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <nav className="mt-8 px-4">
          {sidebarItems.map((item) => (
            <button
              key={item.id}
              onClick={() => handleSidebarItemClick(item.id)}
              className={`w-full flex items-center px-3 py-3 mb-2 text-left rounded-lg transition-colors ${
                activeTab === item.id ? 'bg-blue-50 text-blue-600 border-r-2 border-blue-600' : 'text-gray-600 hover:bg-gray-50'
              }`}
            >
              <span className={`${item.id === activeTab ? 'text-blue-600' : 'text-gray-400'}`}>
                {item.icon}
              </span>
              <span className="ml-3 text-sm font-medium">{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="absolute bottom-4 left-4 right-4">
          <button 
            onClick={handleLogout}
            className="w-full flex items-center px-3 py-3 text-gray-600 hover:bg-gray-50 rounded-lg transition-colors"
          >
            <LogOut className="w-4 h-4 sm:w-5 sm:h-5" />
            <span className="ml-3 text-sm font-medium">Logout</span>
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0">
        <EmailVerificationBanner />
        {/* Header */}
        <header className="bg-white border-b border-gray-200 px-4 sm:px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => setSidebarOpen(true)}
                className="lg:hidden p-2 text-gray-400 hover:text-gray-600"
              >
                <Menu className="w-5 h-5" />
              </button>
              <h1 className="text-lg sm:text-xl lg:text-2xl font-bold text-gray-900">
                {sidebarItems.find(item => item.id === activeTab)?.label}
              </h1>
            </div>

            <div className="flex items-center space-x-2 sm:space-x-4">
              <div className="hidden sm:block relative">
                <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search conversations..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                />
              </div>
              
              
              
              <div className="relative">
                <button 
                  onClick={() => setNotifications(prev => prev.length > 0 ? [] : [{ id: 1, message: 'No new notifications', time: 'Just now' }])}
                  className="relative p-2 text-gray-400 hover:text-gray-600 transition-colors"
                >
                  <Bell className="w-5 h-5 sm:w-6 sm:h-6" />
                  {notifications.length > 0 && (
                    <span className="absolute top-0 right-0 w-2 h-2 bg-red-500 rounded-full"></span>
                  )}
                </button>
                {notifications.length > 0 && (
                  <div className="absolute right-0 mt-2 w-64 bg-white rounded-lg shadow-lg border border-gray-200 z-50">
                    <div className="p-3 border-b border-gray-200">
                      <h3 className="font-medium text-gray-900">Notifications</h3>
                    </div>
                    <div className="p-3">
                      <p className="text-sm text-gray-600">No new notifications</p>
                    </div>
                  </div>
                )}
              </div>
              <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                <span className="text-white text-sm font-semibold">
                  {user?.name ? user.name.split(' ').map(n => n[0]).join('').toUpperCase() : 'U'}
                </span>
              </div>
            </div>
          </div>
        </header>

        {/* Content */}
        <main className={`flex-1 overflow-auto ${activeTab === 'chats' ? 'p-0' : 'p-4 sm:p-6'}`}>
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* Stats Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
                {loading ? (
                  Array.from({ length: 4 }).map((_, index) => (
                    <div key={index} className="bg-white rounded-xl p-4 sm:p-6 shadow-sm border border-gray-200 animate-pulse">
                      <div className="h-16 bg-gray-200 rounded"></div>
                    </div>
                  ))
                ) : (
                  statsConfig.map((stat, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                    className="bg-white rounded-xl p-4 sm:p-6 shadow-sm border border-gray-200"
                  >
                    <div className="flex items-center justify-between mb-4">
                      <div className={`p-2 sm:p-3 rounded-lg ${stat.bg}`}>
                        <span className={stat.color}>{stat.icon}</span>
                      </div>
                      <span className={`text-xs sm:text-sm font-medium ${
                        stat.change.startsWith('+') && stat.change !== '+0%' ? 'text-green-600' : 
                        stat.change.startsWith('-') ? 'text-red-600' : 'text-gray-500'
                      }`}>
                        {stat.change}
                      </span>
                    </div>
                    <h3 className="text-xl sm:text-2xl font-bold text-gray-900 mb-1">{stat.value}</h3>
                    <p className="text-gray-600 text-xs sm:text-sm">{stat.title}</p>
                  </motion.div>
                  ))
                )}
              </div>

              {/* Recent Chats */}
              <div className="bg-white rounded-xl p-4 sm:p-6 shadow-sm border border-gray-200">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-base sm:text-lg font-semibold text-gray-900">Recent Chats</h2>
                  <button 
                    onClick={() => setActiveTab('chats')}
                    className="text-blue-600 hover:text-blue-700 text-xs sm:text-sm font-medium"
                  >
                    View All
                  </button>
                </div>
                <div className="space-y-4">
                  {loading ? (
                    Array.from({ length: 3 }).map((_, index) => (
                      <div key={index} className="flex items-center space-x-3 p-3 rounded-lg animate-pulse">
                        <div className="w-10 h-10 bg-gray-200 rounded-full"></div>
                        <div className="flex-1">
                          <div className="h-4 bg-gray-200 rounded mb-2"></div>
                          <div className="h-3 bg-gray-200 rounded w-3/4"></div>
                        </div>
                      </div>
                    ))
                  ) : recentChats.length > 0 ? (
                    recentChats
                      .filter(chat => 
                        !searchTerm || 
                        chat.customer.toLowerCase().includes(searchTerm.toLowerCase()) ||
                        chat.message.toLowerCase().includes(searchTerm.toLowerCase())
                      )
                      .map((chat) => (
                        <div key={chat.id} className="flex items-center space-x-3 p-3 rounded-lg hover:bg-gray-50 transition-colors">
                          <div className="relative flex-shrink-0">
                            <div className="w-8 h-8 sm:w-10 sm:h-10 bg-blue-600 rounded-full flex items-center justify-center">
                              <span className="text-white text-xs sm:text-sm font-semibold">{chat.avatar}</span>
                            </div>
                            <div className={`absolute -bottom-1 -right-1 w-3 h-3 ${getStatusColor(chat.status)} rounded-full border-2 border-white`}></div>
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between mb-1">
                              <p className="text-gray-900 font-medium truncate text-sm sm:text-base">{chat.customer}</p>
                              <div className="flex items-center space-x-2 flex-shrink-0">
                                <span className="text-gray-400 text-xs">{chat.time}</span>
                                {chat.unread > 0 && (
                                  <span className="bg-blue-600 text-white text-xs rounded-full px-2 py-1 min-w-[20px] text-center">
                                    {chat.unread}
                                  </span>
                                )}
                              </div>
                            </div>
                            <p className="text-gray-500 text-xs sm:text-sm truncate">{chat.message}</p>
                          </div>
                        </div>
                      ))
                  ) : searchTerm ? (
                    <div className="text-center py-4">
                      <p className="text-gray-500">No conversations match your search</p>
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <MessageCircle className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                      <p className="text-gray-500">No recent conversations</p>
                      <p className="text-gray-400 text-sm">Start chatting with your customers</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'chats' && <Chats />}
          {activeTab === 'contacts' && <Contacts />}
          {activeTab === 'analytics' && <Analytics />}
          {activeTab === 'billing' && <Billing />}
          {activeTab === 'automations' && (
            <div className="bg-white rounded-xl p-8 sm:p-12 shadow-sm border border-gray-200 text-center">
              <Zap className="w-12 h-12 sm:w-16 sm:h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg sm:text-xl font-semibent text-gray-900 mb-2">Automations Coming Soon</h3>
              <p className="text-sm sm:text-base text-gray-500">Set up automated responses and workflows</p>
            </div>
          )}
          {activeTab === 'settings' && <DashboardSettings />}
        </main>
      </div>
    </div>
  );
};

export default Dashboard;
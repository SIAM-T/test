import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Copy, Eye, Code, Palette, MessageCircle, Settings, Smartphone, Monitor, 
  ArrowLeft, Check, Download, Globe, Zap, Shield, Users, BarChart3,
  Paintbrush, Layout, Type, Bell, Clock, Star, Play, Pause, RotateCcw,
  ChevronDown, ChevronRight, Sparkles, Wand2, Layers, MousePointer,
  Sun, Moon, Contrast, Volume2, VolumeX, Languages, MapPin, Calendar, X
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import apiService from '../services/api';
import toast from 'react-hot-toast';

const WidgetSetup = () => {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [widgetConfig, setWidgetConfig] = useState({
    // Appearance
    primaryColor: '#3B82F6',
    secondaryColor: '#F8FAFC',
    accentColor: '#10B981',
    textColor: '#1F2937',
    theme: 'light',
    borderRadius: 16,
    shadow: 'large',
    opacity: 100,
    
    // Layout & Position
    position: 'bottom-right',
    size: 'medium',
    margin: 20,
    zIndex: 9999,
    
    // Behavior
    animation: 'bounce',
    autoOpen: false,
    openDelay: 3000,
    minimizeAfter: 30000,
    soundEnabled: true,
    
    // Content
    companyName: 'Your Company',
    greeting: 'Hi! How can I help you today?',
    offlineMessage: 'We\'re currently offline. Leave us a message!',
    placeholder: 'Type your message...',
    
    // Features
    showAvatar: true,
    showOnline: true,
    showTyping: true,
    showTimestamp: true,
    showRating: true,
    fileUpload: true,
    emojiPicker: true,
    
    // Advanced
    language: 'en',
    timezone: 'UTC',
    workingHours: {
      enabled: false,
      start: '09:00',
      end: '17:00',
      days: ['mon', 'tue', 'wed', 'thu', 'fri']
    },
    
    // Triggers
    triggers: [
      { type: 'time', value: 30, message: 'Need help finding something?' },
      { type: 'exit', value: true, message: 'Wait! Let us help you before you go!' },
      { type: 'scroll', value: 50, message: 'Have questions about our products?' }
    ],
    
    // Integrations
    analytics: true,
    crm: 'none',
    notifications: {
      desktop: true,
      sound: true,
      email: false
    }
  });

  const [activeTab, setActiveTab] = useState('design');
  const [activeSection, setActiveSection] = useState('appearance');
  const [previewDevice, setPreviewDevice] = useState('desktop');
  const [isPreviewOpen, setIsPreviewOpen] = useState(true);
  const [isPlaying, setIsPlaying] = useState(false);
  const [expandedSections, setExpandedSections] = useState({
    appearance: true,
    layout: false,
    behavior: false,
    content: false,
    features: false,
    advanced: false
  });

  useEffect(() => {
    const loadWidgetConfig = async () => {
      try {
        const response = await apiService.getWidgets();
        if (response.widgets && response.widgets.length > 0) {
          const existingWidget = response.widgets[0];
          if (existingWidget.config) {
            setWidgetConfig(existingWidget.config);
          } else {
            // Set company name from user organization
            setWidgetConfig(prev => ({
              ...prev,
              companyName: user?.organization?.name || prev.companyName
            }));
          }
        }
      } catch (error) {
        console.error('Error loading widget config:', error);
      }
    };
    
    if (user) {
      loadWidgetConfig();
    }
  }, [user]);

  const tabs = [
    { id: 'design', label: 'Design', icon: Paintbrush },
    { id: 'behavior', label: 'Behavior', icon: Zap },
    { id: 'content', label: 'Content', icon: Type },
    { id: 'triggers', label: 'Triggers', icon: Bell },
    { id: 'install', label: 'Install', icon: Code },
    { id: 'test', label: 'Test', icon: Play }
  ];

  const colorPresets = [
    { name: 'Ocean Blue', primary: '#3B82F6', secondary: '#EFF6FF', accent: '#1D4ED8' },
    { name: 'Emerald Green', primary: '#10B981', secondary: '#ECFDF5', accent: '#059669' },
    { name: 'Purple Magic', primary: '#8B5CF6', secondary: '#F3E8FF', accent: '#7C3AED' },
    { name: 'Sunset Orange', primary: '#F59E0B', secondary: '#FFFBEB', accent: '#D97706' },
    { name: 'Rose Pink', primary: '#EC4899', secondary: '#FDF2F8', accent: '#DB2777' },
    { name: 'Slate Gray', primary: '#64748B', secondary: '#F8FAFC', accent: '#475569' }
  ];

  const embedCode = `<!-- LiveChatM Widget -->
<script>
  (function() {
    window.LiveChatMConfig = {
      organizationId: '${user?.organization?.id || 'YOUR_ORG_ID'}',
      widgetId: 'widget-${Date.now()}',
      apiUrl: 'http://localhost:5000'
    };
    var s = document.createElement('script');
    s.src = window.LiveChatMConfig.apiUrl + '/api/embed/widget.js?org=' + window.LiveChatMConfig.organizationId + '&widget=' + window.LiveChatMConfig.widgetId;
    s.async = true;
    document.head.appendChild(s);
  })();
</script>`;

  const handleConfigChange = (key, value) => {
    setWidgetConfig(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const handleNestedConfigChange = (parent, key, value) => {
    setWidgetConfig(prev => ({
      ...prev,
      [parent]: {
        ...prev[parent],
        [key]: value
      }
    }));
  };

  const toggleSection = (section) => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }));
  };

  const applyPreset = (preset) => {
    handleConfigChange('primaryColor', preset.primary);
    handleConfigChange('secondaryColor', preset.secondary);
    handleConfigChange('accentColor', preset.accent);
    toast.success(`Applied ${preset.name} theme!`);
  };

  const saveConfiguration = async () => {
    setLoading(true);
    try {
      const response = await apiService.getWidgets();
      const existingWidget = response.widgets && response.widgets.length > 0 ? response.widgets[0] : null;
      
      const widgetData = {
        name: `${user?.organization?.name || 'Default'} Widget`,
        config: widgetConfig,
        allowedDomains: []
      };
      
      if (existingWidget) {
        await apiService.updateWidget(existingWidget._id, widgetData);
      } else {
        await apiService.createWidget(widgetData);
      }
      
      toast.success('Configuration saved successfully!');
    } catch (error) {
      console.error('Save error:', error);
      toast.error('Failed to save configuration');
    } finally {
      setLoading(false);
    }
  };

  const resetToDefaults = () => {
    setWidgetConfig({
      primaryColor: '#3B82F6',
      secondaryColor: '#F8FAFC',
      accentColor: '#10B981',
      textColor: '#1F2937',
      theme: 'light',
      borderRadius: 16,
      shadow: 'large',
      opacity: 100,
      position: 'bottom-right',
      size: 'medium',
      margin: 20,
      zIndex: 9999,
      animation: 'bounce',
      autoOpen: false,
      openDelay: 3000,
      minimizeAfter: 30000,
      soundEnabled: true,
      companyName: user?.organization?.name || 'Your Company',
      greeting: 'Hi! How can I help you today?',
      offlineMessage: 'We\'re currently offline. Leave us a message!',
      placeholder: 'Type your message...',
      showAvatar: true,
      showOnline: true,
      showTyping: true,
      showTimestamp: true,
      showRating: true,
      fileUpload: true,
      emojiPicker: true,
      language: 'en',
      timezone: 'UTC',
      workingHours: {
        enabled: false,
        start: '09:00',
        end: '17:00',
        days: ['mon', 'tue', 'wed', 'thu', 'fri']
      },
      triggers: [
        { type: 'time', value: 30, message: 'Need help finding something?' },
        { type: 'exit', value: true, message: 'Wait! Let us help you before you go!' },
        { type: 'scroll', value: 50, message: 'Have questions about our products?' }
      ],
      analytics: true,
      crm: 'none',
      notifications: {
        desktop: true,
        sound: true,
        email: false
      }
    });
    toast.success('Reset to default settings!');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100">
      {/* Advanced Header */}
      <header className="bg-white/80 backdrop-blur-lg border-b border-gray-200/50 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <Link to="/dashboard" className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors group">
                <ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
                <span className="hidden sm:inline font-medium">Dashboard</span>
              </Link>
              <div className="w-px h-6 bg-gray-300"></div>
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-xl flex items-center justify-center shadow-lg">
                  <Wand2 className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-gray-900">Widget Studio</h1>
                  <p className="text-xs text-gray-500">Advanced Customization</p>
                </div>
              </div>
            </div>
            
            <div className="flex items-center space-x-3">
              <button
                onClick={resetToDefaults}
                className="flex items-center space-x-2 px-3 py-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <RotateCcw className="w-4 h-4" />
                <span className="hidden sm:inline">Reset</span>
              </button>
              <button
                onClick={() => setIsPreviewOpen(!isPreviewOpen)}
                className={`flex items-center space-x-2 px-4 py-2 rounded-lg font-medium transition-all ${
                  isPreviewOpen 
                    ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/25' 
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                <Eye className="w-4 h-4" />
                <span className="hidden sm:inline">Preview</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Advanced Tab Navigation */}
        <div className="flex flex-wrap justify-center mb-8">
          <div className="flex bg-white/60 backdrop-blur-sm rounded-2xl p-2 shadow-lg border border-white/20">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center space-x-2 px-4 py-3 rounded-xl font-medium transition-all duration-300 ${
                    activeTab === tab.id
                      ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-lg shadow-blue-600/25 transform scale-105'
                      : 'text-gray-600 hover:text-gray-900 hover:bg-white/50'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span className="hidden sm:inline">{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        <div className={`grid gap-8 ${isPreviewOpen ? 'lg:grid-cols-3' : 'lg:grid-cols-2'}`}>
          {/* Main Configuration Panel */}
          <div className={`space-y-6 ${isPreviewOpen ? 'lg:col-span-2' : ''}`}>
            
            {/* Design Tab */}
            {activeTab === 'design' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-6"
              >
                {/* Color Presets */}
                <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 shadow-lg border border-white/20">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                    <Sparkles className="w-5 h-5 mr-2 text-blue-600" />
                    Color Presets
                  </h3>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                    {colorPresets.map((preset) => (
                      <button
                        key={preset.name}
                        onClick={() => applyPreset(preset)}
                        className="group p-3 rounded-xl border-2 border-gray-200 hover:border-gray-300 transition-all hover:shadow-md"
                      >
                        <div className="flex space-x-2 mb-2">
                          <div className="w-6 h-6 rounded-full" style={{ backgroundColor: preset.primary }}></div>
                          <div className="w-6 h-6 rounded-full" style={{ backgroundColor: preset.secondary }}></div>
                          <div className="w-6 h-6 rounded-full" style={{ backgroundColor: preset.accent }}></div>
                        </div>
                        <p className="text-sm font-medium text-gray-700 group-hover:text-gray-900">{preset.name}</p>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Advanced Color Controls */}
                <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 shadow-lg border border-white/20">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                    <Palette className="w-5 h-5 mr-2 text-blue-600" />
                    Custom Colors
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    {[
                      { key: 'primaryColor', label: 'Primary Color', desc: 'Main brand color' },
                      { key: 'secondaryColor', label: 'Background', desc: 'Widget background' },
                      { key: 'accentColor', label: 'Accent Color', desc: 'Highlights & buttons' },
                      { key: 'textColor', label: 'Text Color', desc: 'Main text color' }
                    ].map((color) => (
                      <div key={color.key} className="space-y-2">
                        <label className="block text-sm font-medium text-gray-700">
                          {color.label}
                          <span className="text-xs text-gray-500 block">{color.desc}</span>
                        </label>
                        <div className="flex items-center space-x-3">
                          <input
                            type="color"
                            value={widgetConfig[color.key]}
                            onChange={(e) => handleConfigChange(color.key, e.target.value)}
                            className="w-12 h-12 rounded-xl border-2 border-gray-200 cursor-pointer shadow-sm"
                          />
                          <input
                            type="text"
                            value={widgetConfig[color.key]}
                            onChange={(e) => handleConfigChange(color.key, e.target.value)}
                            className="flex-1 px-4 py-3 border border-gray-200 rounded-xl text-gray-900 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white/50"
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Layout & Styling */}
                <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 shadow-lg border border-white/20">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                    <Layout className="w-5 h-5 mr-2 text-blue-600" />
                    Layout & Styling
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Position</label>
                      <select
                        value={widgetConfig.position}
                        onChange={(e) => handleConfigChange('position', e.target.value)}
                        className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white/50"
                      >
                        <option value="bottom-right">Bottom Right</option>
                        <option value="bottom-left">Bottom Left</option>
                        <option value="top-right">Top Right</option>
                        <option value="top-left">Top Left</option>
                        <option value="center">Center</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Size</label>
                      <select
                        value={widgetConfig.size}
                        onChange={(e) => handleConfigChange('size', e.target.value)}
                        className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white/50"
                      >
                        <option value="small">Small</option>
                        <option value="medium">Medium</option>
                        <option value="large">Large</option>
                        <option value="extra-large">Extra Large</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Shadow</label>
                      <select
                        value={widgetConfig.shadow}
                        onChange={(e) => handleConfigChange('shadow', e.target.value)}
                        className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white/50"
                      >
                        <option value="none">None</option>
                        <option value="small">Small</option>
                        <option value="medium">Medium</option>
                        <option value="large">Large</option>
                        <option value="extra-large">Extra Large</option>
                      </select>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mt-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Border Radius: {widgetConfig.borderRadius}px
                      </label>
                      <input
                        type="range"
                        min="0"
                        max="32"
                        value={widgetConfig.borderRadius}
                        onChange={(e) => handleConfigChange('borderRadius', parseInt(e.target.value))}
                        className="w-full h-3 bg-gradient-to-r from-blue-200 to-blue-400 rounded-lg appearance-none cursor-pointer"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Opacity: {widgetConfig.opacity}%
                      </label>
                      <input
                        type="range"
                        min="50"
                        max="100"
                        value={widgetConfig.opacity}
                        onChange={(e) => handleConfigChange('opacity', parseInt(e.target.value))}
                        className="w-full h-3 bg-gradient-to-r from-gray-200 to-gray-400 rounded-lg appearance-none cursor-pointer"
                      />
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* Behavior Tab */}
            {activeTab === 'behavior' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-6"
              >
                <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 shadow-lg border border-white/20">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                    <Zap className="w-5 h-5 mr-2 text-blue-600" />
                    Animation & Behavior
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Animation Style</label>
                      <select
                        value={widgetConfig.animation}
                        onChange={(e) => handleConfigChange('animation', e.target.value)}
                        className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white/50"
                      >
                        <option value="none">None</option>
                        <option value="bounce">Bounce</option>
                        <option value="pulse">Pulse</option>
                        <option value="shake">Shake</option>
                        <option value="glow">Glow</option>
                        <option value="rotate">Rotate</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Auto Open Delay: {widgetConfig.openDelay / 1000}s
                      </label>
                      <input
                        type="range"
                        min="0"
                        max="30000"
                        step="1000"
                        value={widgetConfig.openDelay}
                        onChange={(e) => handleConfigChange('openDelay', parseInt(e.target.value))}
                        className="w-full h-3 bg-gradient-to-r from-green-200 to-green-400 rounded-lg appearance-none cursor-pointer"
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mt-6">
                    <div className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                      <div>
                        <span className="text-gray-900 font-medium">Auto Open</span>
                        <p className="text-sm text-gray-500">Open widget automatically</p>
                      </div>
                      <button
                        onClick={() => handleConfigChange('autoOpen', !widgetConfig.autoOpen)}
                        className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                          widgetConfig.autoOpen ? 'bg-blue-600' : 'bg-gray-300'
                        }`}
                      >
                        <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                          widgetConfig.autoOpen ? 'translate-x-6' : 'translate-x-1'
                        }`} />
                      </button>
                    </div>
                    <div className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                      <div>
                        <span className="text-gray-900 font-medium">Sound Effects</span>
                        <p className="text-sm text-gray-500">Play notification sounds</p>
                      </div>
                      <button
                        onClick={() => handleConfigChange('soundEnabled', !widgetConfig.soundEnabled)}
                        className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                          widgetConfig.soundEnabled ? 'bg-blue-600' : 'bg-gray-300'
                        }`}
                      >
                        <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                          widgetConfig.soundEnabled ? 'translate-x-6' : 'translate-x-1'
                        }`} />
                      </button>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* Content Tab */}
            {activeTab === 'content' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-6"
              >
                <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 shadow-lg border border-white/20">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                    <Type className="w-5 h-5 mr-2 text-blue-600" />
                    Messages & Content
                  </h3>
                  <div className="space-y-6">
                    {[
                      { key: 'companyName', label: 'Company Name', placeholder: 'Your Company' },
                      { key: 'greeting', label: 'Welcome Message', placeholder: 'Hi! How can I help you today?' },
                      { key: 'offlineMessage', label: 'Offline Message', placeholder: 'We\'re currently offline...' },
                      { key: 'placeholder', label: 'Input Placeholder', placeholder: 'Type your message...' }
                    ].map((field) => (
                      <div key={field.key}>
                        <label className="block text-sm font-medium text-gray-700 mb-2">{field.label}</label>
                        <textarea
                          value={widgetConfig[field.key]}
                          onChange={(e) => handleConfigChange(field.key, e.target.value)}
                          rows={field.key === 'companyName' ? 1 : 3}
                          className="w-full px-4 py-3 border border-gray-200 rounded-xl text-gray-900 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none bg-white/50"
                          placeholder={field.placeholder}
                        />
                      </div>
                    ))}
                  </div>
                </div>

                {/* Features */}
                <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 shadow-lg border border-white/20">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                    <Star className="w-5 h-5 mr-2 text-blue-600" />
                    Widget Features
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {[
                      { key: 'showAvatar', label: 'Show Avatar', desc: 'Display agent avatars' },
                      { key: 'showOnline', label: 'Online Status', desc: 'Show when agents are online' },
                      { key: 'showTyping', label: 'Typing Indicator', desc: 'Show when agent is typing' },
                      { key: 'showTimestamp', label: 'Timestamps', desc: 'Show message timestamps' },
                      { key: 'showRating', label: 'Rating System', desc: 'Allow customers to rate chats' },
                      { key: 'fileUpload', label: 'File Upload', desc: 'Allow file attachments' },
                      { key: 'emojiPicker', label: 'Emoji Picker', desc: 'Enable emoji selection' }
                    ].map((feature) => (
                      <div key={feature.key} className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                        <div>
                          <span className="text-gray-900 font-medium">{feature.label}</span>
                          <p className="text-sm text-gray-500">{feature.desc}</p>
                        </div>
                        <button
                          onClick={() => handleConfigChange(feature.key, !widgetConfig[feature.key])}
                          className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                            widgetConfig[feature.key] ? 'bg-blue-600' : 'bg-gray-300'
                          }`}
                        >
                          <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                            widgetConfig[feature.key] ? 'translate-x-6' : 'translate-x-1'
                          }`} />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              </motion.div>
            )}

            {/* Triggers Tab */}
            {activeTab === 'triggers' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-6"
              >
                <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 shadow-lg border border-white/20">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                    <Bell className="w-5 h-5 mr-2 text-blue-600" />
                    Proactive Triggers
                  </h3>
                  <div className="space-y-4">
                    {widgetConfig.triggers.map((trigger, index) => (
                      <div key={index} className="p-4 bg-gray-50 rounded-xl">
                        <div className="flex items-center justify-between mb-3">
                          <select
                            value={trigger.type}
                            onChange={(e) => {
                              const newTriggers = [...widgetConfig.triggers];
                              newTriggers[index].type = e.target.value;
                              handleConfigChange('triggers', newTriggers);
                            }}
                            className="px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                          >
                            <option value="time">Time on Page</option>
                            <option value="scroll">Scroll Percentage</option>
                            <option value="exit">Exit Intent</option>
                            <option value="pages">Page Views</option>
                          </select>
                          <button
                            onClick={() => {
                              const newTriggers = widgetConfig.triggers.filter((_, i) => i !== index);
                              handleConfigChange('triggers', newTriggers);
                            }}
                            className="text-red-600 hover:text-red-800 p-1"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                        {trigger.type !== 'exit' && (
                          <div className="mb-3">
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                              {trigger.type === 'time' ? 'Seconds' : trigger.type === 'scroll' ? 'Percentage' : 'Pages'}
                            </label>
                            <input
                              type="number"
                              value={trigger.value}
                              onChange={(e) => {
                                const newTriggers = [...widgetConfig.triggers];
                                newTriggers[index].value = parseInt(e.target.value);
                                handleConfigChange('triggers', newTriggers);
                              }}
                              className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                            />
                          </div>
                        )}
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">Message</label>
                          <textarea
                            value={trigger.message}
                            onChange={(e) => {
                              const newTriggers = [...widgetConfig.triggers];
                              newTriggers[index].message = e.target.value;
                              handleConfigChange('triggers', newTriggers);
                            }}
                            rows={2}
                            className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white resize-none"
                          />
                        </div>
                      </div>
                    ))}
                    <button
                      onClick={() => {
                        const newTriggers = [...widgetConfig.triggers, {
                          type: 'time',
                          value: 30,
                          message: 'Can I help you with anything?'
                        }];
                        handleConfigChange('triggers', newTriggers);
                      }}
                      className="w-full p-4 border-2 border-dashed border-gray-300 rounded-xl text-gray-600 hover:border-blue-400 hover:text-blue-600 transition-colors flex items-center justify-center space-x-2"
                    >
                      <Bell className="w-4 h-4" />
                      <span>Add New Trigger</span>
                    </button>
                  </div>
                </div>
              </motion.div>
            )}

            {/* Install Tab */}
            {activeTab === 'install' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-6"
              >
                <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 shadow-lg border border-white/20">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                    <Code className="w-5 h-5 mr-2 text-blue-600" />
                    Installation Code
                  </h3>
                  <div className="relative">
                    <pre className="bg-gray-900 text-green-400 p-6 rounded-xl text-sm overflow-x-auto font-mono">
                      <code>{embedCode}</code>
                    </pre>
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(embedCode);
                        toast.success('Code copied to clipboard!');
                      }}
                      className="absolute top-4 right-4 p-2 bg-blue-600 hover:bg-blue-700 rounded-lg text-white transition-colors"
                    >
                      <Copy className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </motion.div>
            )}

            {/* Test Tab */}
            {activeTab === 'test' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-6"
              >
                <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 shadow-lg border border-white/20">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                    <Play className="w-5 h-5 mr-2 text-blue-600" />
                    Widget Testing
                  </h3>
                  <div className="space-y-4">
                    <div className="p-4 bg-blue-50 rounded-xl border border-blue-200">
                      <h4 className="font-medium text-blue-900 mb-2">Test Your Widget</h4>
                      <p className="text-blue-700 text-sm mb-4">
                        Use the live preview to test your widget configuration. Try different scenarios:
                      </p>
                      <ul className="text-blue-700 text-sm space-y-1 list-disc list-inside">
                        <li>Test different device sizes (desktop/mobile)</li>
                        <li>Check animation effects</li>
                        <li>Verify color schemes and positioning</li>
                        <li>Test trigger conditions</li>
                      </ul>
                    </div>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <button
                        onClick={() => {
                          setIsPlaying(true);
                          setTimeout(() => setIsPlaying(false), 3000);
                          toast.success('Widget animation test started!');
                        }}
                        className="flex items-center justify-center space-x-2 p-4 bg-green-100 text-green-700 rounded-xl hover:bg-green-200 transition-colors"
                      >
                        <Play className="w-5 h-5" />
                        <span>Test Animation</span>
                      </button>
                      
                      <button
                        onClick={() => {
                          window.open('/widget-test', '_blank');
                        }}
                        className="flex items-center justify-center space-x-2 p-4 bg-blue-100 text-blue-700 rounded-xl hover:bg-blue-200 transition-colors"
                      >
                        <Globe className="w-5 h-5" />
                        <span>Open Test Page</span>
                      </button>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </div>

          {/* Advanced Live Preview */}
          {isPreviewOpen && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 shadow-lg border border-white/20 sticky top-24 h-fit"
            >
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-900 flex items-center">
                  <Eye className="w-5 h-5 mr-2 text-blue-600" />
                  Live Preview
                </h3>
                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => setPreviewDevice('desktop')}
                    className={`p-2 rounded-lg transition-colors ${
                      previewDevice === 'desktop' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600'
                    }`}
                  >
                    <Monitor className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setPreviewDevice('mobile')}
                    className={`p-2 rounded-lg transition-colors ${
                      previewDevice === 'mobile' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600'
                    }`}
                  >
                    <Smartphone className="w-4 h-4" />
                  </button>
                </div>
              </div>
              
              <div className={`bg-gradient-to-br from-slate-100 to-slate-200 rounded-xl p-6 relative overflow-hidden ${
                previewDevice === 'mobile' ? 'max-w-sm mx-auto' : ''
              } min-h-96`}>
                <div className="text-center py-8">
                  <h4 className="text-lg font-medium text-gray-800 mb-2">Your Website</h4>
                  <p className="text-gray-600">Live widget preview</p>
                </div>
                
                {/* Advanced Widget Preview */}
                <div className={`absolute ${
                  widgetConfig.position === 'bottom-right' ? 'bottom-6 right-6' :
                  widgetConfig.position === 'bottom-left' ? 'bottom-6 left-6' :
                  widgetConfig.position === 'top-right' ? 'top-6 right-6' :
                  widgetConfig.position === 'top-left' ? 'top-6 left-6' :
                  'bottom-1/2 right-1/2 transform translate-x-1/2 translate-y-1/2'
                }`}>
                  <AnimatePresence>
                    {isPreviewOpen && (
                      <motion.div
                        initial={{ scale: 0, opacity: 0 }}
                        animate={{
                          scale: widgetConfig.animation === 'pulse' ? [1, 1.1, 1] : 1,
                          y: widgetConfig.animation === 'bounce' ? [0, -10, 0] : 0,
                          x: widgetConfig.animation === 'shake' ? [0, -5, 5, 0] : 0,
                          rotate: widgetConfig.animation === 'rotate' ? [0, 360] : 0,
                          opacity: 1,
                          boxShadow: widgetConfig.animation === 'glow' ? [
                            `0 0 0 0 ${widgetConfig.primaryColor}40`,
                            `0 0 0 10px ${widgetConfig.primaryColor}00`,
                            `0 0 0 0 ${widgetConfig.primaryColor}40`
                          ] : undefined
                        }}
                        exit={{ scale: 0, opacity: 0 }}
                        transition={{
                          duration: widgetConfig.animation === 'rotate' ? 3 : 2,
                          repeat: widgetConfig.animation !== 'none' && isPlaying ? Infinity : 0,
                          repeatType: 'loop'
                        }}
                        onClick={() => {
                          toast.success(`Widget clicked! Position: ${widgetConfig.position}`);
                        }}
                        className={`${
                          widgetConfig.size === 'small' ? 'w-12 h-12' :
                          widgetConfig.size === 'large' ? 'w-16 h-16' :
                          widgetConfig.size === 'extra-large' ? 'w-20 h-20' : 'w-14 h-14'
                        } flex items-center justify-center text-white cursor-pointer hover:scale-110 transition-transform ${
                          widgetConfig.shadow === 'small' ? 'shadow-md' :
                          widgetConfig.shadow === 'medium' ? 'shadow-lg' :
                          widgetConfig.shadow === 'large' ? 'shadow-xl' :
                          widgetConfig.shadow === 'extra-large' ? 'shadow-2xl' : ''
                        }`}
                        style={{ 
                          backgroundColor: widgetConfig.primaryColor,
                          borderRadius: `${widgetConfig.borderRadius}px`,
                          opacity: widgetConfig.opacity / 100
                        }}
                      >
                        <MessageCircle className={`${
                          widgetConfig.size === 'small' ? 'w-5 h-5' :
                          widgetConfig.size === 'large' ? 'w-8 h-8' :
                          widgetConfig.size === 'extra-large' ? 'w-10 h-10' : 'w-6 h-6'
                        }`} />
                        
                        {/* Online indicator */}
                        {widgetConfig.showOnline && (
                          <div className="absolute -top-1 -right-1 w-3 h-3 bg-green-500 rounded-full border-2 border-white"></div>
                        )}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </div>

              {/* Quick Actions */}
              <div className="mt-6 space-y-3">
                <button 
                  onClick={saveConfiguration}
                  disabled={loading}
                  className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 text-white py-3 px-6 rounded-xl font-semibold hover:from-blue-700 hover:to-indigo-700 transition-all shadow-lg shadow-blue-600/25 flex items-center justify-center space-x-2 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <Check className="w-5 h-5" />
                  <span>{loading ? 'Saving...' : 'Save Configuration'}</span>
                </button>
                <div className="grid grid-cols-2 gap-3">
                  <button 
                    onClick={() => {
                      const config = JSON.stringify(widgetConfig, null, 2);
                      const blob = new Blob([config], { type: 'application/json' });
                      const url = URL.createObjectURL(blob);
                      const a = document.createElement('a');
                      a.href = url;
                      a.download = 'widget-config.json';
                      a.click();
                      toast.success('Configuration exported!');
                    }}
                    className="bg-gray-100 text-gray-700 py-2 px-4 rounded-xl font-medium hover:bg-gray-200 transition-colors flex items-center justify-center space-x-2"
                  >
                    <Download className="w-4 h-4" />
                    <span>Export</span>
                  </button>
                  <button 
                    onClick={() => setIsPlaying(!isPlaying)}
                    className="bg-green-100 text-green-700 py-2 px-4 rounded-xl font-medium hover:bg-green-200 transition-colors flex items-center justify-center space-x-2"
                  >
                    {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                    <span>{isPlaying ? 'Pause' : 'Test'}</span>
                  </button>
                </div>
              </div>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
};

export default WidgetSetup;
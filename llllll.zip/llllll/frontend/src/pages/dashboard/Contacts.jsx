import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Search, 
  Filter, 
  Plus, 
  Users, 
  Mail,
  Phone,
  Building,
  Calendar,
  MoreVertical,
  Edit,
  Trash2
} from 'lucide-react';
import { useApi } from '../../hooks/useApi';
import apiService from '../../services/api';

const Contacts = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedFilter, setSelectedFilter] = useState('all');
  const [contacts, setContacts] = useState([]);
  const [loading, setLoading] = useState(true);

  const { data: conversationsData, loading: conversationsLoading } = useApi('/conversations');

  useEffect(() => {
    if (conversationsData?.conversations) {
      // Extract unique visitors from conversations
      const uniqueVisitors = new Map();
      
      conversationsData.conversations.forEach(conv => {
        if (conv.visitor) {
          const visitorId = conv.visitor._id || conv.visitor.email;
          if (!uniqueVisitors.has(visitorId)) {
            uniqueVisitors.set(visitorId, {
              id: visitorId,
              name: conv.visitor.name || 'Anonymous User',
              email: conv.visitor.email || 'No email provided',
              phone: conv.visitor.phone || 'No phone provided',
              company: conv.visitor.company || 'Unknown Company',
              lastContact: new Date(conv.updatedAt).toLocaleString(),
              status: conv.visitor.isOnline ? 'active' : 'inactive',
              avatar: (conv.visitor.name || 'A').substring(0, 2).toUpperCase(),
              totalChats: 1
            });
          } else {
            // Increment chat count for existing visitor
            const existing = uniqueVisitors.get(visitorId);
            existing.totalChats += 1;
            // Update last contact if this conversation is more recent
            if (new Date(conv.updatedAt) > new Date(existing.lastContact)) {
              existing.lastContact = new Date(conv.updatedAt).toLocaleString();
            }
          }
        }
      });
      
      setContacts(Array.from(uniqueVisitors.values()));
      setLoading(false);
    } else if (!conversationsLoading) {
      setContacts([]);
      setLoading(false);
    }
  }, [conversationsData, conversationsLoading]);



  const filteredContacts = contacts.filter(contact => {
    const matchesSearch = contact.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         contact.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         contact.company.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesFilter = selectedFilter === 'all' || contact.status === selectedFilter;
    
    return matchesSearch && matchesFilter;
  });

  return (
    <div className="space-y-4 md:space-y-6 p-4 md:p-0">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-xl md:text-2xl font-bold text-gray-900">Contacts</h1>
          <p className="text-sm md:text-base text-gray-600">Manage your customer contacts</p>
        </div>
        <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2 w-fit text-sm md:text-base">
          <Plus className="w-4 h-4" />
          Add Contact
        </button>
      </div>

      {/* Filters and Search */}
      <div className="bg-white rounded-xl p-4 md:p-6 shadow-sm border border-gray-200">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Search contacts..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm md:text-base"
            />
          </div>
          
          <div className="flex items-center space-x-2">
            <Filter className="w-4 h-4 text-gray-400" />
            <select
              value={selectedFilter}
              onChange={(e) => setSelectedFilter(e.target.value)}
              className="border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm md:text-base"
            >
              <option value="all">All Contacts</option>
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
            </select>
          </div>
        </div>
      </div>

      {/* Contacts Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
        {loading ? (
          Array.from({ length: 6 }).map((_, index) => (
            <div key={index} className="bg-white rounded-xl p-4 md:p-6 shadow-sm border border-gray-200 animate-pulse">
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-12 h-12 bg-gray-200 rounded-full"></div>
                <div className="flex-1">
                  <div className="h-4 bg-gray-200 rounded mb-2"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                </div>
              </div>
              <div className="space-y-2">
                <div className="h-3 bg-gray-200 rounded"></div>
                <div className="h-3 bg-gray-200 rounded"></div>
                <div className="h-3 bg-gray-200 rounded"></div>
              </div>
            </div>
          ))
        ) : (
          filteredContacts.map((contact, index) => (
          <motion.div
            key={contact.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: index * 0.1 }}
            className="bg-white rounded-xl p-4 md:p-6 shadow-sm border border-gray-200 hover:shadow-md transition-shadow"
          >
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center space-x-2 md:space-x-3 min-w-0 flex-1">
                <div className="w-10 h-10 md:w-12 md:h-12 bg-blue-600 rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-white text-sm md:text-base font-semibold">{contact.avatar}</span>
                </div>
                <div className="min-w-0 flex-1">
                  <h3 className="text-base md:text-lg font-semibold text-gray-900 truncate">{contact.name}</h3>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    contact.status === 'active' 
                      ? 'bg-green-100 text-green-800' 
                      : 'bg-gray-100 text-gray-800'
                  }`}>
                    {contact.status}
                  </span>
                </div>
              </div>
              <div className="relative flex-shrink-0">
                <button className="p-1 text-gray-400 hover:text-gray-600 transition-colors">
                  <MoreVertical className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="space-y-2 md:space-y-3">
              <div className="flex items-center space-x-2 text-gray-600 min-w-0">
                <Mail className="w-4 h-4 flex-shrink-0" />
                <span className="text-xs md:text-sm truncate">{contact.email}</span>
              </div>
              <div className="flex items-center space-x-2 text-gray-600">
                <Phone className="w-4 h-4 flex-shrink-0" />
                <span className="text-xs md:text-sm">{contact.phone}</span>
              </div>
              <div className="flex items-center space-x-2 text-gray-600 min-w-0">
                <Building className="w-4 h-4 flex-shrink-0" />
                <span className="text-xs md:text-sm truncate">{contact.company}</span>
              </div>
              <div className="flex items-center space-x-2 text-gray-600">
                <Calendar className="w-4 h-4 flex-shrink-0" />
                <span className="text-xs md:text-sm">Last contact: {contact.lastContact}</span>
              </div>
            </div>

            <div className="mt-3 md:mt-4 pt-3 md:pt-4 border-t border-gray-200">
              <div className="flex items-center justify-between">
                <span className="text-xs md:text-sm text-gray-600">
                  {contact.totalChats} total chats
                </span>
                <div className="flex items-center space-x-1 md:space-x-2">
                  <button className="p-2 text-gray-400 hover:text-blue-600 transition-colors">
                    <Edit className="w-4 h-4" />
                  </button>
                  <button className="p-2 text-gray-400 hover:text-red-600 transition-colors">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
          ))
        )}
      </div>

      {!loading && filteredContacts.length === 0 && (
        <div className="bg-white rounded-xl p-8 md:p-12 shadow-sm border border-gray-200 text-center">
          <Users className="w-12 h-12 md:w-16 md:h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-base md:text-lg font-semibold text-gray-900 mb-2">No contacts found</h3>
          <p className="text-sm md:text-base text-gray-500 mb-4">
            {searchTerm ? 'Try adjusting your search terms' : 'No visitors have started conversations yet'}
          </p>
          <p className="text-xs md:text-sm text-gray-400">
            Contacts will appear here when visitors start chatting with your widget
          </p>
        </div>
      )}
    </div>
  );
};

export default Contacts;
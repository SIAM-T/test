import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  BarChart3,
  TrendingUp,
  TrendingDown,
  Users,
  MessageCircle,
  Clock,
  Star,
  Calendar,
  Download,
  Filter
} from 'lucide-react';
import { useApi } from '../../hooks/useApi';
import { useSocket } from '../../context/SocketContext';
import useRealTimeSync from '../../hooks/useRealTimeSync';
import apiService from '../../services/api';

const Analytics = () => {
  const [timeRange, setTimeRange] = useState('7d');
  const [analyticsData, setAnalyticsData] = useState(null);
  const [loading, setLoading] = useState(true);

  const { data: analytics, loading: analyticsLoading, refetch } = useApi('/analytics/dashboard');
  const { socket } = useSocket();
  const { registerHandler, unregisterHandler } = useRealTimeSync();

  // Real-time analytics updates
  useEffect(() => {
    const handleAnalyticsUpdate = () => {
      // Small delay to ensure backend has processed the data
      setTimeout(() => {
        refetch();
      }, 1000);
    };

    // Register handlers for events that affect analytics
    registerHandler('message', handleAnalyticsUpdate);
    registerHandler('conversation', handleAnalyticsUpdate);
    registerHandler('conversationUpdate', handleAnalyticsUpdate);
    registerHandler('agentStatus', handleAnalyticsUpdate);

    return () => {
      unregisterHandler('message', handleAnalyticsUpdate);
      unregisterHandler('conversation', handleAnalyticsUpdate);
      unregisterHandler('conversationUpdate', handleAnalyticsUpdate);
      unregisterHandler('agentStatus', handleAnalyticsUpdate);
    };
  }, [refetch, registerHandler, unregisterHandler]);

  useEffect(() => {
    setAnalyticsData(analytics);
    setLoading(analyticsLoading);
  }, [analytics, analyticsLoading]);

  const stats = [
    {
      title: 'Total Conversations',
      value: analyticsData?.metrics?.conversations?.total?.toString() || '0',
      change: '+0%',
      trend: 'up',
      icon: <MessageCircle className="w-4 h-4 md:w-5 md:h-5" />,
      color: 'text-blue-600',
      bg: 'bg-blue-50'
    },
    {
      title: 'Active Conversations',
      value: analyticsData?.metrics?.conversations?.active?.toString() || '0',
      change: '+0%',
      trend: 'up',
      icon: <Users className="w-4 h-4 md:w-5 md:h-5" />,
      color: 'text-green-600',
      bg: 'bg-green-50'
    },
    {
      title: 'Avg Rating',
      value: analyticsData?.metrics?.satisfaction?.avgRating ? `${analyticsData.metrics.satisfaction.avgRating}★` : '0★',
      change: '+0%',
      trend: 'up',
      icon: <Clock className="w-4 h-4 md:w-5 md:h-5" />,
      color: 'text-purple-600',
      bg: 'bg-purple-50'
    },
    {
      title: 'Online Agents',
      value: `${analyticsData?.metrics?.agents?.online || 0}/${analyticsData?.metrics?.agents?.total || 1}`,
      change: '+0%',
      trend: 'up',
      icon: <Star className="w-4 h-4 md:w-5 md:h-5" />,
      color: 'text-orange-600',
      bg: 'bg-orange-50'
    }
  ];

  const chartData = analyticsData?.charts?.daily?.map(day => ({
    day: new Date(day._id).toLocaleDateString('en', { weekday: 'short' }),
    conversations: day.conversations,
    users: day.closed
  })) || [
      { day: 'Mon', conversations: 0, users: 0 },
      { day: 'Tue', conversations: 0, users: 0 },
      { day: 'Wed', conversations: 0, users: 0 },
      { day: 'Thu', conversations: 0, users: 0 },
      { day: 'Fri', conversations: 0, users: 0 },
      { day: 'Sat', conversations: 0, users: 0 },
      { day: 'Sun', conversations: 0, users: 0 }
    ];

  const topPages = [];

  return (
    <div className="space-y-4 md:space-y-6 p-4 md:p-0">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-xl md:text-2xl font-bold text-gray-900">Analytics</h1>
          <p className="text-sm md:text-base text-gray-600">Track your performance and insights</p>
        </div>
        <div className="flex items-center space-x-3">
          <select
            value={timeRange}
            onChange={(e) => setTimeRange(e.target.value)}
            className="border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm md:text-base"
          >
            <option value="7d">Last 7 days</option>
            <option value="30d">Last 30 days</option>
            <option value="90d">Last 90 days</option>
          </select>
          <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2 text-sm md:text-base">
            <Download className="w-4 h-4" />
            <span className="hidden sm:inline">Export</span>
          </button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
        {loading ? (
          Array.from({ length: 4 }).map((_, index) => (
            <div key={index} className="bg-white rounded-xl p-4 md:p-6 shadow-sm border border-gray-200 animate-pulse">
              <div className="h-20 bg-gray-200 rounded"></div>
            </div>
          ))
        ) : (
          stats.map((stat, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="bg-white rounded-xl p-4 md:p-6 shadow-sm border border-gray-200"
            >
              <div className="flex items-center justify-between mb-3 md:mb-4">
                <div className={`p-2 md:p-3 rounded-lg ${stat.bg}`}>
                  <span className={stat.color}>{stat.icon}</span>
                </div>
                <div className={`flex items-center space-x-1 text-xs md:text-sm font-medium ${stat.trend === 'up' ? 'text-green-600' : 'text-red-600'
                  }`}>
                  {stat.trend === 'up' ? (
                    <TrendingUp className="w-3 h-3 md:w-4 md:h-4" />
                  ) : (
                    <TrendingDown className="w-3 h-3 md:w-4 md:h-4" />
                  )}
                  <span>{stat.change}</span>
                </div>
              </div>
              <h3 className="text-xl md:text-2xl font-bold text-gray-900 mb-1">{stat.value}</h3>
              <p className="text-gray-600 text-xs md:text-sm">{stat.title}</p>
            </motion.div>
          ))
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6">
        {/* Chart */}
        <div className="bg-white rounded-xl p-4 md:p-6 shadow-sm border border-gray-200">
          <div className="flex items-center justify-between mb-4 md:mb-6">
            <h2 className="text-base md:text-lg font-semibold text-gray-900">Conversations Overview</h2>
            <button className="p-2 text-gray-400 hover:text-gray-600 transition-colors">
              <Filter className="w-4 h-4" />
            </button>
          </div>

          <div className="space-y-3 md:space-y-4">
            {chartData.map((item, index) => (
              <div key={index} className="flex items-center space-x-3 md:space-x-4">
                <div className="w-8 md:w-12 text-xs md:text-sm text-gray-600 flex-shrink-0">{item.day}</div>
                <div className="flex-1 flex items-center space-x-2">
                  <div className="flex-1 bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-blue-600 h-2 rounded-full transition-all duration-500"
                      style={{ width: `${(item.conversations / 70) * 100}%` }}
                    ></div>
                  </div>
                  <span className="text-xs md:text-sm text-gray-600 w-6 md:w-8 text-right">{item.conversations}</span>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-4 md:mt-6 flex items-center space-x-4 md:space-x-6 text-xs md:text-sm">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-blue-600 rounded-full"></div>
              <span className="text-gray-600">Conversations</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-green-600 rounded-full"></div>
              <span className="text-gray-600">Users</span>
            </div>
          </div>
        </div>

        {/* Top Pages */}
        <div className="bg-white rounded-xl p-4 md:p-6 shadow-sm border border-gray-200">
          <h2 className="text-base md:text-lg font-semibold text-gray-900 mb-4 md:mb-6">Top Pages</h2>

          <div className="space-y-3 md:space-y-4">
            {loading ? (
              Array.from({ length: 5 }).map((_, index) => (
                <div key={index} className="flex items-center justify-between p-3 rounded-lg animate-pulse">
                  <div className="flex-1">
                    <div className="h-4 bg-gray-200 rounded mb-2"></div>
                    <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                  </div>
                  <div className="w-16 h-8 bg-gray-200 rounded"></div>
                </div>
              ))
            ) : topPages.length > 0 ? (
              topPages.map((page, index) => (
                <div key={index} className="flex items-center justify-between p-3 rounded-lg hover:bg-gray-50 transition-colors">
                  <div className="flex-1 min-w-0">
                    <p className="text-sm md:text-base text-gray-900 font-medium truncate">{page.page}</p>
                    <p className="text-xs md:text-sm text-gray-500">{page.visits} visits</p>
                  </div>
                  <div className="text-right flex-shrink-0 ml-4">
                    <p className="text-sm md:text-base text-gray-900 font-medium">{page.conversion}</p>
                    <p className="text-xs md:text-sm text-gray-500">conversion</p>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-8">
                <BarChart3 className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <p className="text-gray-500">No page data available</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Response Time Chart */}
      <div className="bg-white rounded-xl p-4 md:p-6 shadow-sm border border-gray-200">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-4 md:mb-6 gap-4">
          <h2 className="text-base md:text-lg font-semibold text-gray-900">Response Time Trends</h2>
          <div className="flex items-center space-x-2">
            <Calendar className="w-4 h-4 text-gray-400" />
            <span className="text-xs md:text-sm text-gray-600">Last 7 days</span>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 md:gap-6">
          {loading ? (
            Array.from({ length: 3 }).map((_, index) => (
              <div key={index} className="text-center p-3 md:p-4 bg-gray-50 rounded-lg animate-pulse">
                <div className="h-8 bg-gray-200 rounded mb-2"></div>
                <div className="h-4 bg-gray-200 rounded mb-1"></div>
                <div className="h-3 bg-gray-200 rounded w-1/2 mx-auto"></div>
              </div>
            ))
          ) : (
            <>
              <div className="text-center p-3 md:p-4 bg-gray-50 rounded-lg">
                <div className="text-xl md:text-2xl font-bold text-gray-900 mb-1">
                  {analyticsData?.metrics?.conversations?.total || 0}
                </div>
                <div className="text-xs md:text-sm text-gray-600">Total Conversations</div>
                <div className="text-xs text-blue-600 mt-1">All time</div>
              </div>
              <div className="text-center p-3 md:p-4 bg-gray-50 rounded-lg">
                <div className="text-xl md:text-2xl font-bold text-gray-900 mb-1">
                  {analyticsData?.metrics?.agents?.online || 0}
                </div>
                <div className="text-xs md:text-sm text-gray-600">Online Agents</div>
                <div className="text-xs text-green-600 mt-1">Currently active</div>
              </div>
              <div className="text-center p-3 md:p-4 bg-gray-50 rounded-lg">
                <div className="text-xl md:text-2xl font-bold text-gray-900 mb-1">
                  {analyticsData?.metrics?.satisfaction?.avgRating || '0'}★
                </div>
                <div className="text-xs md:text-sm text-gray-600">Avg Rating</div>
                <div className="text-xs text-orange-600 mt-1">Customer satisfaction</div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default Analytics;
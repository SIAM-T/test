import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  CreditCard, 
  Check, 
  AlertTriangle, 
  Users, 
  HardDrive,
  Crown,
  ArrowUp,
  ArrowDown
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import apiService from '../../services/api';
import toast from 'react-hot-toast';

const Billing = () => {
  const [loading, setLoading] = useState(false);
  const [planLimits, setPlanLimits] = useState(null);
  const [changingPlan, setChangingPlan] = useState(false);
  const { user } = useAuth();

  const plans = [
    {
      id: 'free',
      name: 'Free',
      price: '$0',
      period: '/month',
      description: 'Perfect for getting started',
      features: [
        '1 website integration',
        'Unlimited chats',
        '2 team members',
        '100 MB file storage',
        'Basic analytics',
        'Email support'
      ],
      limits: { agents: 2, fileStorage: 100 }
    },
    {
      id: 'starter',
      name: 'Starter',
      price: '$16',
      period: '/month',
      description: 'Perfect for small businesses',
      features: [
        '1 website integration',
        'Unlimited chats',
        '5 team members',
        '500 MB file storage',
        'Advanced analytics',
        'Email support',
        'Widget customization'
      ],
      limits: { agents: 5, fileStorage: 500 }
    },
    {
      id: 'professional',
      name: 'Professional',
      price: '$40',
      period: '/month',
      description: 'Best for growing companies',
      features: [
        '1 website integration',
        'Unlimited chats',
        '10 team members',
        '2 GB file storage',
        'Advanced analytics',
        'Priority support',
        'Custom branding',
        'API access'
      ],
      limits: { agents: 10, fileStorage: 2000 },
      popular: true
    },
    {
      id: 'enterprise',
      name: 'Enterprise',
      price: '$79',
      period: '/month',
      description: 'For large organizations',
      features: [
        'Multiple website integrations',
        'Unlimited chats',
        'Unlimited team members',
        'Unlimited file storage',
        'Advanced analytics',
        '24/7 phone support',
        'White-label solution',
        'Custom integrations',
        'SLA guarantees'
      ],
      limits: { agents: -1, fileStorage: -1 }
    }
  ];

  useEffect(() => {
    fetchPlanLimits();
  }, []);

  const fetchPlanLimits = async () => {
    try {
      const response = await apiService.request('/organizations/limits');
      setPlanLimits(response);
    } catch (error) {
      console.error('Failed to fetch plan limits:', error);
    }
  };

  const handlePlanChange = async (newPlan) => {
    if (newPlan === planLimits?.plan) return;

    setChangingPlan(true);
    try {
      await apiService.request('/organizations/update-plan', {
        method: 'PUT',
        body: JSON.stringify({ plan: newPlan })
      });
      
      toast.success(`Successfully ${getPlanChangeType(planLimits?.plan, newPlan)}d to ${newPlan} plan!`);
      await fetchPlanLimits();
    } catch (error) {
      const errorData = error.response?.data;
      if (errorData?.currentUsage && errorData?.newLimits) {
        toast.error(
          `Cannot downgrade: You have ${errorData.currentUsage.agents} members but ${newPlan} plan allows only ${errorData.newLimits.agents}. Remove ${errorData.requiredReduction} members first.`,
          { duration: 6000 }
        );
      } else {
        toast.error(errorData?.message || 'Failed to change plan');
      }
    } finally {
      setChangingPlan(false);
    }
  };

  const getPlanChangeType = (currentPlan, newPlan) => {
    const planOrder = ['free', 'starter', 'professional', 'enterprise'];
    const currentIndex = planOrder.indexOf(currentPlan);
    const newIndex = planOrder.indexOf(newPlan);
    return newIndex > currentIndex ? 'upgrade' : 'downgrade';
  };

  const getCurrentPlan = () => {
    return plans.find(plan => plan.id === planLimits?.plan) || plans[0];
  };

  const getUsagePercentage = (current, limit) => {
    if (limit === -1) return 0; // Unlimited
    return Math.min((current / limit) * 100, 100);
  };

  const getUsageColor = (percentage) => {
    if (percentage >= 90) return 'text-red-600 bg-red-100';
    if (percentage >= 70) return 'text-yellow-600 bg-yellow-100';
    return 'text-green-600 bg-green-100';
  };

  if (!planLimits) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const currentPlan = getCurrentPlan();

  return (
    <div className="space-y-6 p-4 md:p-0">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Billing & Plans</h1>
        <p className="text-gray-600">Manage your subscription and billing information</p>
      </div>

      {/* Current Plan & Usage */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Current Plan */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-gray-900">Current Plan</h2>
            <div className="flex items-center space-x-2">
              <Crown className="w-5 h-5 text-yellow-500" />
              <span className="text-sm font-medium text-gray-600">{currentPlan.name}</span>
            </div>
          </div>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-3xl font-bold text-gray-900">{currentPlan.price}</span>
              <span className="text-gray-600">{currentPlan.period}</span>
            </div>
            <p className="text-gray-600">{currentPlan.description}</p>
            
            <div className="pt-4 border-t border-gray-200">
              <h3 className="font-medium text-gray-900 mb-2">Plan Features</h3>
              <ul className="space-y-2">
                {currentPlan.features.slice(0, 4).map((feature, index) => (
                  <li key={index} className="flex items-center text-sm text-gray-600">
                    <Check className="w-4 h-4 text-green-500 mr-2 flex-shrink-0" />
                    {feature}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        {/* Usage Statistics */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Usage Statistics</h2>
          
          <div className="space-y-6">
            {/* Team Members Usage */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center space-x-2">
                  <Users className="w-4 h-4 text-blue-600" />
                  <span className="text-sm font-medium text-gray-700">Team Members</span>
                </div>
                <span className="text-sm text-gray-600">
                  {planLimits.usage.agents} / {planLimits.limits.agents === -1 ? '∞' : planLimits.limits.agents}
                </span>
              </div>
              
              {planLimits.limits.agents !== -1 && (
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className={`h-2 rounded-full transition-all duration-300 ${
                      getUsagePercentage(planLimits.usage.agents, planLimits.limits.agents) >= 90 
                        ? 'bg-red-500' 
                        : getUsagePercentage(planLimits.usage.agents, planLimits.limits.agents) >= 70 
                        ? 'bg-yellow-500' 
                        : 'bg-green-500'
                    }`}
                    style={{ 
                      width: `${getUsagePercentage(planLimits.usage.agents, planLimits.limits.agents)}%` 
                    }}
                  ></div>
                </div>
              )}
              
              {planLimits.usage.agents >= planLimits.limits.agents && planLimits.limits.agents !== -1 && (
                <div className="flex items-center space-x-2 mt-2 p-2 bg-red-50 rounded-lg">
                  <AlertTriangle className="w-4 h-4 text-red-600" />
                  <span className="text-sm text-red-600">You've reached your member limit</span>
                </div>
              )}
            </div>

            {/* File Storage Usage */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center space-x-2">
                  <HardDrive className="w-4 h-4 text-purple-600" />
                  <span className="text-sm font-medium text-gray-700">File Storage</span>
                </div>
                <span className="text-sm text-gray-600">
                  {planLimits.usage.fileStorage || 0} MB / {planLimits.limits.fileStorage === -1 ? '∞' : `${planLimits.limits.fileStorage} MB`}
                </span>
              </div>
              
              {planLimits.limits.fileStorage !== -1 && (
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className={`h-2 rounded-full transition-all duration-300 ${
                      getUsagePercentage(planLimits.usage.fileStorage || 0, planLimits.limits.fileStorage) >= 90 
                        ? 'bg-red-500' 
                        : getUsagePercentage(planLimits.usage.fileStorage || 0, planLimits.limits.fileStorage) >= 70 
                        ? 'bg-yellow-500' 
                        : 'bg-green-500'
                    }`}
                    style={{ 
                      width: `${getUsagePercentage(planLimits.usage.fileStorage || 0, planLimits.limits.fileStorage)}%` 
                    }}
                  ></div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Available Plans */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-6">Available Plans</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {plans.map((plan) => {
            const isCurrentPlan = plan.id === planLimits.plan;
            const isUpgrade = getPlanChangeType(planLimits.plan, plan.id) === 'upgrade';
            const isDowngrade = getPlanChangeType(planLimits.plan, plan.id) === 'downgrade';
            
            return (
              <motion.div
                key={plan.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className={`relative rounded-xl p-6 border-2 transition-all duration-300 ${
                  isCurrentPlan 
                    ? 'border-blue-500 bg-blue-50' 
                    : plan.popular 
                    ? 'border-purple-500 bg-purple-50' 
                    : 'border-gray-200 bg-white hover:border-gray-300'
                }`}
              >
                {plan.popular && !isCurrentPlan && (
                  <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                    <span className="bg-purple-600 text-white px-3 py-1 rounded-full text-xs font-medium">
                      Most Popular
                    </span>
                  </div>
                )}
                
                {isCurrentPlan && (
                  <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                    <span className="bg-blue-600 text-white px-3 py-1 rounded-full text-xs font-medium">
                      Current Plan
                    </span>
                  </div>
                )}

                <div className="text-center mb-4">
                  <h3 className="text-xl font-bold text-gray-900 mb-2">{plan.name}</h3>
                  <div className="flex items-baseline justify-center mb-2">
                    <span className="text-3xl font-bold text-gray-900">{plan.price}</span>
                    <span className="text-gray-600 ml-1">{plan.period}</span>
                  </div>
                  <p className="text-sm text-gray-600">{plan.description}</p>
                </div>

                <ul className="space-y-2 mb-6">
                  {plan.features.slice(0, 4).map((feature, index) => (
                    <li key={index} className="flex items-center text-sm text-gray-600">
                      <Check className="w-4 h-4 text-green-500 mr-2 flex-shrink-0" />
                      {feature}
                    </li>
                  ))}
                </ul>

                <button
                  onClick={() => handlePlanChange(plan.id)}
                  disabled={isCurrentPlan || changingPlan}
                  className={`w-full py-2 px-4 rounded-lg font-medium transition-all duration-300 flex items-center justify-center space-x-2 ${
                    isCurrentPlan
                      ? 'bg-gray-100 text-gray-500 cursor-not-allowed'
                      : isUpgrade
                      ? 'bg-green-600 text-white hover:bg-green-700'
                      : 'bg-blue-600 text-white hover:bg-blue-700'
                  }`}
                >
                  {changingPlan ? (
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                  ) : isCurrentPlan ? (
                    <span>Current Plan</span>
                  ) : (
                    <>
                      {isUpgrade ? (
                        <ArrowUp className="w-4 h-4" />
                      ) : (
                        <ArrowDown className="w-4 h-4" />
                      )}
                      <span>{isUpgrade ? 'Upgrade' : 'Downgrade'}</span>
                    </>
                  )}
                </button>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Billing Information */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Billing Information</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h3 className="font-medium text-gray-900 mb-2">Payment Method</h3>
            <div className="flex items-center space-x-3 p-3 border border-gray-200 rounded-lg">
              <CreditCard className="w-5 h-5 text-gray-400" />
              <span className="text-gray-600">No payment method added</span>
            </div>
          </div>
          
          <div>
            <h3 className="font-medium text-gray-900 mb-2">Next Billing Date</h3>
            <div className="p-3 border border-gray-200 rounded-lg">
              <span className="text-gray-600">
                {planLimits.plan === 'free' ? 'No billing required' : 'Not set'}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Billing;
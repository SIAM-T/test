import { useState, useEffect, useRef } from 'react';
import {
  Search,
  MessageCircle,
  Send,
  ArrowLeft,
  MoreVertical,

} from 'lucide-react';
import ConversationActions from '../../components/ConversationActions';
import { useApi } from '../../hooks/useApi';
import { useSocket } from '../../context/SocketContext';
import useRealTimeSync from '../../hooks/useRealTimeSync';
import apiService from '../../services/api';
import toast from 'react-hot-toast';

const Chats = () => {
  const [selectedChat, setSelectedChat] = useState(null);
  const [message, setMessage] = useState('');
  const [showChatList, setShowChatList] = useState(true);
  const [isMobile, setIsMobile] = useState(false);
  const [chats, setChats] = useState([]);
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeFilter, setActiveFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [typingUser, setTypingUser] = useState('');
  const [messagesLoading, setMessagesLoading] = useState(false);
  const [sendingMessage, setSendingMessage] = useState(false);
  const messagesEndRef = useRef(null);
  const typingTimeoutRef = useRef(null);

  const { data: conversationsData, loading: conversationsLoading } = useApi('/conversations');
  const { socket, isConnected, joinConversation, leaveConversation, sendMessage: socketSendMessage, startTyping, stopTyping } = useSocket();
  
  console.log('Socket state:', { socket: !!socket, isConnected });
  const { registerHandler, unregisterHandler } = useRealTimeSync();

  const generateVisitorName = (visitorId, conversationIndex = 0) => {
    return `Anonymous Visitor #${conversationIndex + 1}`;
  };

  useEffect(() => {
    const checkScreenSize = () => {
      setIsMobile(window.innerWidth < 1024);
      if (window.innerWidth >= 1024) {
        setShowChatList(true);
      }
    };
    checkScreenSize();
    window.addEventListener('resize', checkScreenSize);
    return () => window.removeEventListener('resize', checkScreenSize);
  }, []);

  useEffect(() => {
    if (conversationsData?.conversations) {
      const formattedChats = conversationsData.conversations.map((conv, index) => {
        const visitorName = conv.visitor?.name || generateVisitorName(conv.visitorId || conv._id, index);
        return {
          id: conv._id,
          customer: visitorName,
          email: conv.visitor?.email || 'No email',
          message: conv.lastMessage?.content || 'No messages yet',
          time: new Date(conv.updatedAt).toLocaleString(),
          status: conv.status || 'waiting',
          avatar: `A${index + 1}`,
          unread: conv.unreadCount || 0,
          lastSeen: conv.visitor?.lastSeen ? new Date(conv.visitor.lastSeen).toLocaleString() : 'Unknown'
        };
      });
      setChats(formattedChats);
      setLoading(false);
    } else if (!conversationsLoading) {
      setChats([]);
      setLoading(false);
    }
  }, [conversationsData, conversationsLoading]);

  const filteredChats = chats.filter(chat => {
    const matchesFilter = activeFilter === 'all' || chat.status === activeFilter;
    const matchesSearch = !searchTerm ||
      chat.customer.toLowerCase().includes(searchTerm.toLowerCase()) ||
      chat.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      chat.message.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const loadMessages = async (chatId) => {
    try {
      setMessagesLoading(true);
      const response = await apiService.getConversation(chatId);
      if (response?.messages && Array.isArray(response.messages)) {
        const formattedMessages = response.messages.map(msg => ({
          id: msg._id || `msg_${Date.now()}_${Math.random()}`,
          text: msg.content || '',
          sender: msg.sender?.type === 'visitor' ? 'customer' : 'agent',
          time: new Date(msg.createdAt || Date.now()).toLocaleTimeString(),
          status: msg.status || 'delivered'
        }));
        setMessages(formattedMessages);
      } else {
        setMessages([]);
      }
    } catch (error) {
      console.error('Error loading messages:', error);
      toast.error('Failed to load messages');
      setMessages([]);
    } finally {
      setMessagesLoading(false);
    }
  };

  const handleChatSelect = (chat) => {
    if (!chat?.id) return;

    if (selectedChat && socket) {
      leaveConversation(selectedChat.id);
    }
    setSelectedChat(chat);
    loadMessages(chat.id);
    if (socket) {
      joinConversation(chat.id);
    }
    if (isMobile) {
      setShowChatList(false);
    }

    // Mark chat as read
    setChats(prev => prev.map(c =>
      c.id === chat.id ? { ...c, unread: 0 } : c
    ));
  };

  const handleBackToList = () => {
    setShowChatList(true);
    if (isMobile) {
      setSelectedChat(null);
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'active': return 'bg-green-500';
      case 'waiting': return 'bg-yellow-500';
      case 'resolved': return 'bg-gray-400';
      default: return 'bg-gray-400';
    }
  };

  const getStatusText = (status) => {
    switch (status) {
      case 'active': return 'Active';
      case 'waiting': return 'Waiting';
      case 'resolved': return 'Resolved';
      default: return 'Offline';
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Real-time message handling
  useEffect(() => {
    const handleNewMessage = (data) => {
      console.log('Chats received new_message:', data);
      
      // Update messages if this is the selected chat
      if (selectedChat && data.conversationId === selectedChat.id) {
        const newMessage = {
          id: data._id,
          text: data.content,
          sender: data.sender?.type === 'visitor' ? 'customer' : 'agent',
          time: new Date(data.createdAt).toLocaleTimeString(),
          status: data.status || 'delivered'
        };
        setMessages(prev => {
          // Check for duplicates by both ID and content+time to prevent duplicates
          const isDuplicate = prev.some(msg => 
            msg.id === newMessage.id || 
            (msg.text === newMessage.text && msg.sender === newMessage.sender && Math.abs(new Date(msg.time).getTime() - new Date(newMessage.time).getTime()) < 5000)
          );
          if (isDuplicate) return prev;
          return [...prev, newMessage];
        });
      }

      // Update chat list
      setChats(prev => {
        const existingIndex = prev.findIndex(chat => chat.id === data.conversationId);
        if (existingIndex >= 0) {
          const updated = [...prev];
          const chat = updated[existingIndex];
          updated[existingIndex] = {
            ...chat,
            message: data.content,
            time: new Date(data.createdAt).toLocaleString(),
            unread: selectedChat?.id === data.conversationId ? chat.unread : (chat.unread || 0) + 1
          };
          const [updatedChat] = updated.splice(existingIndex, 1);
          return [updatedChat, ...updated];
        } else {
          return [{
            id: data.conversationId,
            customer: `Anonymous Visitor #${prev.length + 1}`,
            email: 'No email',
            message: data.content,
            time: new Date(data.createdAt).toLocaleString(),
            status: 'waiting',
            avatar: `A${prev.length + 1}`,
            unread: 1,
            lastSeen: 'Unknown'
          }, ...prev];
        }
      });
    };
    
    const handleNewConversation = (data) => {
      console.log('Chats received new_conversation:', data);
      // Refresh conversations list
      setTimeout(() => {
        window.location.reload(); // Simple refresh for now
      }, 1000);
    };
    
    const handleConversationUpdate = (data) => {
      console.log('Chats received conversation_updated:', data);
      // Update conversation status in the list
      setChats(prev => prev.map(chat => 
        chat.id === data.conversationId 
          ? { ...chat, status: data.status || chat.status }
          : chat
      ));
    };

    const handleTypingStart = (data) => {
      console.log('Typing start:', data);
      if (selectedChat && data.conversationId === selectedChat.id) {
        setIsTyping(true);
        setTypingUser(data.visitorId ? 'Visitor' : data.agentName || 'Agent');
        
        // Auto-clear typing after 5 seconds
        clearTimeout(window.typingClearTimeout);
        window.typingClearTimeout = setTimeout(() => {
          setIsTyping(false);
          setTypingUser('');
        }, 5000);
      }
    };

    const handleTypingStop = (data) => {
      console.log('Typing stop:', data);
      if (selectedChat && data.conversationId === selectedChat.id) {
        clearTimeout(window.typingClearTimeout);
        setIsTyping(false);
        setTypingUser('');
      }
    };
    
    const handleMessageStatusUpdate = (data) => {
      console.log('Message status update received:', data);
      if (selectedChat && data.conversationId === selectedChat.id) {
        setMessages(prev => prev.map(msg => 
          msg.id === data.messageId 
            ? { ...msg, status: data.status }
            : msg
        ));
      }
    };

    const handleMessageRead = (data) => {
      if (selectedChat && data.conversationId === selectedChat.id) {
        setMessages(prev => prev.map(msg => 
          msg.id === data.messageId 
            ? { ...msg, status: 'read' }
            : msg
        ));
      }
    };

    // Register socket event handlers
    if (socket) {
      socket.on('new_message', handleNewMessage);
      socket.on('new_conversation', handleNewConversation);
      socket.on('conversation_updated', handleConversationUpdate);
      socket.on('conversation_status_changed', handleConversationUpdate);
      socket.on('agent_typing', handleTypingStart);
      socket.on('visitor_typing', handleTypingStart);
      socket.on('agent_typing_stop', handleTypingStop);
      socket.on('visitor_typing_stop', handleTypingStop);
      socket.on('message_status_update', handleMessageStatusUpdate);
      socket.on('messages_marked_read', handleMessageRead);
      
      console.log('Socket events registered for chat');
    }

    return () => {
      if (socket) {
        socket.off('new_message', handleNewMessage);
        socket.off('new_conversation', handleNewConversation);
        socket.off('conversation_updated', handleConversationUpdate);
        socket.off('conversation_status_changed', handleConversationUpdate);
        socket.off('agent_typing', handleTypingStart);
        socket.off('visitor_typing', handleTypingStart);
        socket.off('agent_typing_stop', handleTypingStop);
        socket.off('visitor_typing_stop', handleTypingStop);
        socket.off('message_status_update', handleMessageStatusUpdate);
        socket.off('messages_marked_read', handleMessageRead);
      }
      clearTimeout(window.typingClearTimeout);
    };
  }, [selectedChat, registerHandler, unregisterHandler]);

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!message.trim() || !selectedChat || sendingMessage) return;

    const messageText = message.trim();
    setMessage('');
    setSendingMessage(true);

    try {
      // Use socket for real-time message sending if available
      if (socket && isConnected) {
        socketSendMessage(selectedChat.id, messageText);
      } else {
        // Fallback to API call only if socket unavailable
        const tempMessage = {
          id: `temp_${Date.now()}_${Math.random()}`,
          text: messageText,
          sender: 'agent',
          time: new Date().toLocaleTimeString(),
          status: 'sending'
        };
        setMessages(prev => [...prev, tempMessage]);

        const response = await apiService.sendMessage(selectedChat.id, {
          content: messageText,
          sender: 'agent'
        });

        if (response?.message) {
          setMessages(prev => prev.map(msg =>
            msg.id === tempMessage.id
              ? { ...msg, id: response.message._id, status: 'delivered' }
              : msg
          ));
        }
      }

    } catch (error) {
      console.error('Error sending message:', error);
      toast.error('Failed to send message');
    } finally {
      setSendingMessage(false);
    }
  };

  return (
    <div className="flex h-[calc(100vh-140px)] bg-white overflow-hidden">
      {/* Chat List */}
      <div className={`${isMobile ? (showChatList ? 'flex' : 'hidden') : 'flex'} w-full lg:w-80 xl:w-96 border-r border-gray-200 bg-white flex-col flex-shrink-0 h-full`}>
        <div className="p-3 lg:p-4 border-b border-gray-200 flex-shrink-0">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-base lg:text-lg font-semibold text-gray-900">Conversations</h2>
            <span className="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded-full">
              {filteredChats.length} total
            </span>
          </div>

          <div className="relative mb-3">
            <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Search conversations..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
            />
          </div>

          <div className="flex items-center gap-1 overflow-x-auto pb-1">
            {['all', 'active', 'waiting', 'resolved'].map(filter => (
              <button
                key={filter}
                onClick={() => setActiveFilter(filter)}
                className={`px-2 py-1 text-xs rounded-md whitespace-nowrap capitalize ${activeFilter === filter ? 'bg-blue-100 text-blue-700' : 'text-gray-600 hover:bg-gray-100'
                  }`}
              >
                {filter}
              </button>
            ))}
          </div>
        </div>

        <div className="flex-1 overflow-y-auto">
          {loading ? (
            Array.from({ length: 5 }).map((_, index) => (
              <div key={index} className="p-4 border-b border-gray-100 animate-pulse">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-gray-200 rounded-full"></div>
                  <div className="flex-1">
                    <div className="h-4 bg-gray-200 rounded mb-2"></div>
                    <div className="h-3 bg-gray-200 rounded w-3/4"></div>
                  </div>
                </div>
              </div>
            ))
          ) : filteredChats.length > 0 ? (
            filteredChats.map((chat) => (
              <div
                key={chat.id}
                className={`p-3 border-b border-gray-100 cursor-pointer hover:bg-gray-50 transition-colors ${selectedChat?.id === chat.id ? 'bg-blue-50 border-blue-200' : ''
                  }`}
                onClick={() => handleChatSelect(chat)}
              >
                <div className="flex items-center space-x-3">
                  <div className="relative flex-shrink-0">
                    <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center">
                      <span className="text-white text-xs font-semibold">{chat.avatar}</span>
                    </div>
                    <div className={`absolute -bottom-0.5 -right-0.5 w-3 h-3 ${getStatusColor(chat.status)} rounded-full border-2 border-white`}></div>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <p className="text-gray-900 font-medium truncate text-sm">{chat.customer}</p>
                      <span className="text-gray-400 text-xs flex-shrink-0">{new Date(chat.time).toLocaleTimeString()}</span>
                    </div>
                    <p className="text-gray-600 text-xs truncate mb-1">{chat.message}</p>
                    <div className="flex items-center justify-between">
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${chat.status === 'active' ? 'bg-green-100 text-green-700' :
                          chat.status === 'waiting' ? 'bg-yellow-100 text-yellow-700' :
                            'bg-gray-100 text-gray-600'
                        }`}>
                        {getStatusText(chat.status)}
                      </span>
                      {chat.unread > 0 && (
                        <span className="bg-blue-600 text-white text-xs rounded-full px-1.5 py-0.5 min-w-[18px] text-center">
                          {chat.unread}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="flex-1 flex items-center justify-center p-8">
              <div className="text-center">
                <MessageCircle className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No conversations yet</h3>
                <p className="text-gray-500">Start engaging with your website visitors</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Chat Window */}
      <div className={`${isMobile ? (showChatList ? 'hidden' : 'flex') : 'flex'} flex-1 flex-col bg-gray-50 overflow-hidden h-full min-w-0`}>
        {selectedChat ? (
          <>
            {/* Chat Header */}
            <div className="bg-white p-3 lg:p-4 border-b border-gray-200 flex-shrink-0">
              {isMobile && (
                <button
                  onClick={handleBackToList}
                  className="mb-3 text-blue-600 hover:text-blue-700 text-sm flex items-center font-medium"
                >
                  <ArrowLeft className="w-4 h-4 mr-1" />
                  Back to chats
                </button>
              )}
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3 sm:space-x-4">
                  <div className="relative flex-shrink-0">
                    <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center shadow-sm">
                      <span className="text-white text-xs sm:text-sm font-semibold">{selectedChat.avatar}</span>
                    </div>
                    <div className={`absolute -bottom-1 -right-1 w-3 h-3 sm:w-4 sm:h-4 ${isConnected && socket ? 'bg-green-500' : 'bg-red-500'} rounded-full border-2 border-white shadow-sm`}></div>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-gray-900 font-semibold text-sm sm:text-base truncate">{selectedChat.customer}</p>
                    <p className="text-gray-500 text-xs sm:text-sm truncate">{isConnected && socket ? 'Online' : 'Offline'}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <ConversationActions 
                    conversation={selectedChat} 
                    onStatusUpdate={(id, status) => {
                      setChats(prev => prev.map(chat => 
                        chat.id === id ? { ...chat, status } : chat
                      ));
                      if (status === 'closed') {
                        toast.success('Conversation closed');
                      }
                    }}
                  />
                </div>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-3 lg:p-4 space-y-3 min-h-0">
              {messagesLoading ? (
                <div className="flex items-center justify-center h-32">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                </div>
              ) : messages.length === 0 ? (
                <div className="flex items-center justify-center h-32">
                  <div className="text-center">
                    <MessageCircle className="w-12 h-12 text-gray-300 mx-auto mb-2" />
                    <p className="text-gray-500 text-sm">No messages yet</p>
                    <p className="text-gray-400 text-xs">Start the conversation</p>
                  </div>
                </div>
              ) : (
                messages.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex ${msg.sender === 'agent' ? 'justify-end' : 'justify-start'}`}
                >
                  <div className={`max-w-[85%] sm:max-w-md lg:max-w-lg break-words`}>
                    <div className={`px-3 py-2 sm:px-4 sm:py-3 rounded-2xl shadow-sm ${msg.sender === 'agent'
                        ? 'bg-blue-600 text-white rounded-br-md'
                        : 'bg-white text-gray-900 border border-gray-200 rounded-bl-md'
                      }`}>
                      <p className="text-sm leading-relaxed break-words">{msg.text}</p>
                    </div>
                    <div className={`flex items-center mt-1 space-x-1 ${msg.sender === 'agent' ? 'justify-end' : 'justify-start'
                      }`}>
                      <span className={`text-xs ${msg.sender === 'agent' ? 'text-gray-400' : 'text-gray-500'
                        }`}>
                        {msg.time}
                      </span>
                      {msg.sender === 'agent' && (
                        <span className={`text-xs flex items-center ${msg.status === 'sending' ? 'text-yellow-500' :
                            msg.status === 'read' ? 'text-green-500' : 'text-gray-400'
                          }`}>
                          {msg.status === 'sending' && (
                            <div className="animate-spin rounded-full h-2 w-2 border border-yellow-500 border-t-transparent mr-1"></div>
                          )}
                          <span className={`${msg.status === 'read' ? 'text-blue-500' : msg.status === 'delivered' ? 'text-green-500' : 'text-gray-400'}`}>
                            • {msg.status === 'sending' ? 'Sending...' : msg.status === 'read' ? 'Read' : msg.status === 'delivered' ? 'Delivered' : 'Sent'}
                          </span>
                        </span>
                      )}
                    </div>
                  </div>
                </div>
                ))
              )}

              {isTyping && (
                <div className="flex justify-start">
                  <div className="bg-white border border-gray-200 rounded-2xl rounded-bl-md px-4 py-3 shadow-sm">
                    <div className="flex items-center space-x-2">
                      <div className="flex space-x-1">
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                      </div>
                      <span className="text-xs text-gray-500">{typingUser} is typing...</span>
                    </div>
                  </div>
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>

            {/* Message Input */}
            <div className="bg-white p-3 lg:p-4 border-t border-gray-200 flex-shrink-0">
              <form onSubmit={handleSendMessage} className="flex items-end space-x-2">
                <div className="flex-1 relative">
                  <textarea
                    value={message}
                    onChange={(e) => {
                      setMessage(e.target.value);
                      if (selectedChat && socket) {
                        startTyping(selectedChat.id);
                        if (typingTimeoutRef.current) {
                          clearTimeout(typingTimeoutRef.current);
                        }
                        typingTimeoutRef.current = setTimeout(() => {
                          stopTyping(selectedChat.id);
                        }, 1000);
                      }
                    }}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        handleSendMessage(e);
                      }
                    }}
                    placeholder="Type your message..."
                    rows={1}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm resize-none bg-gray-50"
                    style={{ minHeight: '44px', maxHeight: '120px' }}
                    disabled={!selectedChat}
                  />
                </div>
                <button
                  type="submit"
                  disabled={!message.trim() || !selectedChat || sendingMessage}
                  className="bg-blue-600 text-white p-3 rounded-xl hover:bg-blue-700 transition-colors flex-shrink-0 shadow-sm disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {sendingMessage ? (
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                  ) : (
                    <Send className="w-5 h-5" />
                  )}
                </button>
              </form>
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center p-8">
            <div className="text-center max-w-md mx-auto">
              <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <MessageCircle className="w-10 h-10 text-gray-400" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Select a conversation</h3>
              <p className="text-gray-500 text-sm">Choose a conversation from the list to start chatting with your customers</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Chats;
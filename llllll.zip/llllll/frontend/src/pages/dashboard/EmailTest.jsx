import { useState } from 'react';
import { motion } from 'framer-motion';
import { Mail, Send, CheckCircle, AlertCircle, Settings, User } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import apiService from '../../services/api';
import toast from 'react-hot-toast';

const EmailTest = () => {
  const [loading, setLoading] = useState(false);
  const [configStatus, setConfigStatus] = useState(null);
  const [testResults, setTestResults] = useState([]);
  const { user } = useAuth();

  const [testEmail, setTestEmail] = useState({
    to: user?.email || '',
    subject: 'Test Email from LiveChatM',
    message: 'This is a test email to verify email functionality is working correctly.'
  });

  const testEmailConfig = async () => {
    setLoading(true);
    try {
      const result = await apiService.testEmailConfig();
      setConfigStatus(result);
      if (result.success) {
        toast.success('Email configuration is valid!');
      } else {
        toast.error(`Email config error: ${result.message}`);
      }
    } catch (error) {
      setConfigStatus({ success: false, message: error.message });
      toast.error('Failed to test email configuration');
    } finally {
      setLoading(false);
    }
  };

  const sendTestEmail = async () => {
    if (!testEmail.to || !testEmail.subject || !testEmail.message) {
      toast.error('Please fill in all fields');
      return;
    }

    setLoading(true);
    try {
      const result = await apiService.sendTestEmail(testEmail);
      const testResult = {
        type: 'Test Email',
        timestamp: new Date().toLocaleString(),
        success: result.success,
        message: result.success ? 'Email sent successfully!' : result.message,
        to: testEmail.to
      };
      setTestResults(prev => [testResult, ...prev]);
      
      if (result.success) {
        toast.success('Test email sent successfully!');
      } else {
        toast.error(`Failed to send email: ${result.message}`);
      }
    } catch (error) {
      const testResult = {
        type: 'Test Email',
        timestamp: new Date().toLocaleString(),
        success: false,
        message: error.message,
        to: testEmail.to
      };
      setTestResults(prev => [testResult, ...prev]);
      toast.error('Failed to send test email');
    } finally {
      setLoading(false);
    }
  };

  const sendWelcomeEmail = async () => {
    setLoading(true);
    try {
      const result = await apiService.sendWelcomeEmail({
        email: user.email,
        name: user.name,
        organizationName: user.organization?.name || 'Your Organization'
      });
      
      const testResult = {
        type: 'Welcome Email',
        timestamp: new Date().toLocaleString(),
        success: result.success,
        message: result.success ? 'Welcome email sent successfully!' : result.message,
        to: user.email
      };
      setTestResults(prev => [testResult, ...prev]);
      
      if (result.success) {
        toast.success('Welcome email sent successfully!');
      } else {
        toast.error(`Failed to send welcome email: ${result.message}`);
      }
    } catch (error) {
      const testResult = {
        type: 'Welcome Email',
        timestamp: new Date().toLocaleString(),
        success: false,
        message: error.message,
        to: user.email
      };
      setTestResults(prev => [testResult, ...prev]);
      toast.error('Failed to send welcome email');
    } finally {
      setLoading(false);
    }
  };

  const sendVerificationEmail = async () => {
    setLoading(true);
    try {
      const result = await apiService.sendVerificationEmail();
      const testResult = {
        type: 'Verification Email',
        timestamp: new Date().toLocaleString(),
        success: true,
        message: 'Verification email sent successfully!',
        to: user.email
      };
      setTestResults(prev => [testResult, ...prev]);
      toast.success('Verification email sent successfully!');
    } catch (error) {
      const testResult = {
        type: 'Verification Email',
        timestamp: new Date().toLocaleString(),
        success: false,
        message: error.message,
        to: user.email
      };
      setTestResults(prev => [testResult, ...prev]);
      toast.error('Failed to send verification email');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6 p-4 md:p-0">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Email Testing</h1>
        <p className="text-gray-600">Test and verify email functionality</p>
      </div>

      {/* Email Configuration Status */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-gray-900 flex items-center">
            <Settings className="w-5 h-5 mr-2 text-blue-600" />
            Email Configuration
          </h2>
          <button
            onClick={testEmailConfig}
            disabled={loading}
            className="flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 disabled:opacity-50"
          >
            <Settings className="w-4 h-4" />
            <span>{loading ? 'Testing...' : 'Test Config'}</span>
          </button>
        </div>

        {configStatus && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className={`p-4 rounded-lg flex items-center space-x-3 ${
              configStatus.success 
                ? 'bg-green-50 border border-green-200' 
                : 'bg-red-50 border border-red-200'
            }`}
          >
            {configStatus.success ? (
              <CheckCircle className="w-5 h-5 text-green-600" />
            ) : (
              <AlertCircle className="w-5 h-5 text-red-600" />
            )}
            <div>
              <p className={`font-medium ${
                configStatus.success ? 'text-green-800' : 'text-red-800'
              }`}>
                {configStatus.success ? 'Configuration Valid' : 'Configuration Error'}
              </p>
              <p className={`text-sm ${
                configStatus.success ? 'text-green-600' : 'text-red-600'
              }`}>
                {configStatus.message}
              </p>
            </div>
          </motion.div>
        )}

        <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
          <div>
            <span className="font-medium text-gray-700">SMTP Host:</span>
            <span className="ml-2 text-gray-600">smtp.gmail.com</span>
          </div>
          <div>
            <span className="font-medium text-gray-700">Port:</span>
            <span className="ml-2 text-gray-600">587</span>
          </div>
          <div>
            <span className="font-medium text-gray-700">Email:</span>
            <span className="ml-2 text-gray-600">opsiamop10@gmail.com</span>
          </div>
          <div>
            <span className="font-medium text-gray-700">Security:</span>
            <span className="ml-2 text-gray-600">TLS</span>
          </div>
        </div>
      </div>

      {/* Test Email Form */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
          <Mail className="w-5 h-5 mr-2 text-blue-600" />
          Send Test Email
        </h2>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">To Email</label>
            <input
              type="email"
              value={testEmail.to}
              onChange={(e) => setTestEmail({...testEmail, to: e.target.value})}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="recipient@example.com"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Subject</label>
            <input
              type="text"
              value={testEmail.subject}
              onChange={(e) => setTestEmail({...testEmail, subject: e.target.value})}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Email subject"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Message</label>
            <textarea
              value={testEmail.message}
              onChange={(e) => setTestEmail({...testEmail, message: e.target.value})}
              rows={4}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
              placeholder="Email message content"
            />
          </div>

          <div className="flex flex-wrap gap-3">
            <button
              onClick={sendTestEmail}
              disabled={loading}
              className="flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 disabled:opacity-50"
            >
              <Send className="w-4 h-4" />
              <span>{loading ? 'Sending...' : 'Send Test Email'}</span>
            </button>

            <button
              onClick={sendWelcomeEmail}
              disabled={loading}
              className="flex items-center space-x-2 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 disabled:opacity-50"
            >
              <User className="w-4 h-4" />
              <span>{loading ? 'Sending...' : 'Send Welcome Email'}</span>
            </button>

            <button
              onClick={sendVerificationEmail}
              disabled={loading}
              className="flex items-center space-x-2 bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 disabled:opacity-50"
            >
              <CheckCircle className="w-4 h-4" />
              <span>{loading ? 'Sending...' : 'Send Verification Email'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Test Results */}
      {testResults.length > 0 && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Test Results</h2>
          <div className="space-y-3">
            {testResults.map((result, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={`p-4 rounded-lg border ${
                  result.success 
                    ? 'bg-green-50 border-green-200' 
                    : 'bg-red-50 border-red-200'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    {result.success ? (
                      <CheckCircle className="w-5 h-5 text-green-600" />
                    ) : (
                      <AlertCircle className="w-5 h-5 text-red-600" />
                    )}
                    <div>
                      <p className={`font-medium ${
                        result.success ? 'text-green-800' : 'text-red-800'
                      }`}>
                        {result.type}
                      </p>
                      <p className={`text-sm ${
                        result.success ? 'text-green-600' : 'text-red-600'
                      }`}>
                        To: {result.to}
                      </p>
                    </div>
                  </div>
                  <span className="text-xs text-gray-500">{result.timestamp}</span>
                </div>
                <p className={`mt-2 text-sm ${
                  result.success ? 'text-green-700' : 'text-red-700'
                }`}>
                  {result.message}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default EmailTest;
import { createContext, useContext, useEffect, useState } from 'react';
import { io } from 'socket.io-client';
import { useAuth } from './AuthContext';
import toast from 'react-hot-toast';

const SocketContext = createContext();

export const useSocket = () => {
  const context = useContext(SocketContext);
  if (!context) {
    throw new Error('useSocket must be used within a SocketProvider');
  }
  return context;
};

export const SocketProvider = ({ children }) => {
  const [socket, setSocket] = useState(null);
  const [isConnected, setIsConnected] = useState(false);
  const [onlineAgents, setOnlineAgents] = useState([]);
  const [connectionAttempts, setConnectionAttempts] = useState(0);
  const [lastActivity, setLastActivity] = useState(Date.now());
  const { user, token } = useAuth();

  useEffect(() => {
    console.log('SocketProvider initializing with user:', user?.name, 'token:', !!token);
    if (user && token) {
      const newSocket = io(import.meta.env.VITE_API_URL?.replace('/api', '') || 'http://localhost:5000', {
        auth: {
          token,
          userType: 'agent'
        },
        transports: ['websocket', 'polling'],
        forceNew: true
      });

      newSocket.on('connect', () => {
        console.log('Socket connected successfully');
        console.log('Socket ID:', newSocket.id);
        console.log('User:', user.name, 'Org:', user.organizationId);
        setIsConnected(true);
        setConnectionAttempts(0);
        setLastActivity(Date.now());
        // toast.success('Connected to live chat');
      });

      newSocket.on('disconnect', (reason) => {
        console.log('Socket disconnected:', reason);
        setIsConnected(false);
        
        // Auto-reconnect on certain disconnect reasons
        if (reason === 'io server disconnect' || reason === 'transport close') {
          setConnectionAttempts(prev => prev + 1);
          if (connectionAttempts < 5) {
            setTimeout(() => {
              console.log('Attempting to reconnect...');
              newSocket.connect();
            }, Math.pow(2, connectionAttempts) * 1000); // Exponential backoff
          }
        }
      });
      
      newSocket.on('connect_error', (error) => {
        console.error('Socket connection error:', error.message);
        setConnectionAttempts(prev => prev + 1);
        
        if (error.message.includes('Authentication') || error.message.includes('User not found')) {
          console.log('Authentication failed:', error.message);
          toast.error('Authentication failed - please refresh page');
        } else {
          toast.error('Connection failed');
        }
      });

      newSocket.on('agent_online', (data) => {
        setOnlineAgents(prev => [...prev.filter(a => a.agentId !== data.agentId), data]);
      });

      newSocket.on('agent_offline', (data) => {
        setOnlineAgents(prev => prev.filter(a => a.agentId !== data.agentId));
      });

      newSocket.on('new_message', (data) => {
        console.log('SocketContext received new_message:', data);
      });

      newSocket.on('new_conversation', (data) => {
        console.log('New conversation started:', data);
        toast.success('New conversation started');
        setLastActivity(Date.now());
        // Trigger dashboard refresh
        window.dispatchEvent(new CustomEvent('conversationUpdate', { detail: data }));
      });

      newSocket.on('conversation_updated', (data) => {
        console.log('Conversation updated:', data);
        setLastActivity(Date.now());
        window.dispatchEvent(new CustomEvent('conversationUpdate', { detail: data }));
      });
      
      newSocket.on('conversation_status_changed', (data) => {
        console.log('Conversation status changed:', data);
        setLastActivity(Date.now());
        window.dispatchEvent(new CustomEvent('conversationUpdate', { detail: data }));
      });
      
      newSocket.on('agent_status_changed', (data) => {
        console.log('Agent status changed:', data);
        setLastActivity(Date.now());
        window.dispatchEvent(new CustomEvent('agentStatusUpdate', { detail: data }));
      });

      setSocket(newSocket);

      return () => {
        console.log('Cleaning up socket connection');
        newSocket.close();
        setSocket(null);
        setIsConnected(false);
      };
    } else {
      console.log('Socket not initialized - missing user or token');
      setSocket(null);
      setIsConnected(false);
    }
  }, [user, token]);

  const joinConversation = (conversationId) => {
    if (socket) {
      socket.emit('join_conversation', { conversationId });
    }
  };

  const leaveConversation = (conversationId) => {
    if (socket) {
      socket.emit('leave_conversation', { conversationId });
    }
  };

  const sendMessage = (conversationId, message) => {
    if (socket && user) {
      socket.emit('send_message', {
        conversationId,
        content: message,
        sender: {
          type: 'agent',
          id: user._id,
          name: user.name
        }
      });
    }
  };

  const startTyping = (conversationId) => {
    if (socket) {
      socket.emit('typing_start', { conversationId });
    }
  };

  const stopTyping = (conversationId) => {
    if (socket) {
      socket.emit('typing_stop', { conversationId });
    }
  };

  // Heartbeat to keep connection alive
  useEffect(() => {
    if (socket && isConnected) {
      const heartbeat = setInterval(() => {
        socket.emit('heartbeat', { timestamp: Date.now() });
      }, 30000); // Every 30 seconds
      
      return () => clearInterval(heartbeat);
    }
  }, [socket, isConnected]);

  const value = {
    socket,
    isConnected,
    onlineAgents,
    connectionAttempts,
    lastActivity,
    joinConversation,
    leaveConversation,
    sendMessage,
    startTyping,
    stopTyping
  };

  return (
    <SocketContext.Provider value={value}>
      {children}
    </SocketContext.Provider>
  );
};
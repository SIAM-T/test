import { useEffect, useRef, useState, useCallback } from 'react';
import { io } from 'socket.io-client';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';

export const useEnhancedSocket = () => {
  const [socket, setSocket] = useState(null);
  const [isConnected, setIsConnected] = useState(false);
  const [connectionAttempts, setConnectionAttempts] = useState(0);
  const [lastActivity, setLastActivity] = useState(Date.now());
  const { user, token } = useAuth();
  
  const reconnectTimeoutRef = useRef(null);
  const heartbeatIntervalRef = useRef(null);
  const messageQueueRef = useRef([]);
  const eventHandlersRef = useRef(new Map());

  // Enhanced connection with retry logic
  const connect = useCallback(() => {
    if (!user || !token) return;

    const newSocket = io(import.meta.env.VITE_API_URL?.replace('/api', '') || 'http://localhost:5000', {
      auth: {
        token,
        userType: 'agent'
      },
      transports: ['websocket', 'polling'],
      forceNew: true,
      timeout: 10000,
      reconnection: false // Handle reconnection manually
    });

    // Connection events
    newSocket.on('connect', () => {
      console.log('Socket connected:', newSocket.id);
      setIsConnected(true);
      setConnectionAttempts(0);
      setLastActivity(Date.now());
      
      // Process queued messages
      processMessageQueue(newSocket);
      
      // Start heartbeat
      startHeartbeat(newSocket);
    });

    newSocket.on('disconnect', (reason) => {
      console.log('Socket disconnected:', reason);
      setIsConnected(false);
      stopHeartbeat();
      
      // Auto-reconnect with exponential backoff
      if (reason !== 'io client disconnect') {
        scheduleReconnect();
      }
    });

    newSocket.on('connect_error', (error) => {
      console.error('Connection error:', error.message);
      setConnectionAttempts(prev => prev + 1);
      
      if (error.message.includes('Authentication')) {
        toast.error('Authentication failed - please refresh');
        return;
      }
      
      scheduleReconnect();
    });

    // Message events with deduplication
    const messageIds = new Set();
    
    newSocket.on('new_message', (data) => {
      if (messageIds.has(data._id)) {
        console.log('Duplicate message ignored:', data._id);
        return;
      }
      
      messageIds.add(data._id);
      setTimeout(() => messageIds.delete(data._id), 300000); // Clean up after 5 minutes
      
      setLastActivity(Date.now());
      triggerEvent('message', data);
    });

    newSocket.on('new_conversation', (data) => {
      setLastActivity(Date.now());
      triggerEvent('conversation', data);
      toast.success('New conversation started');
    });

    newSocket.on('agent_typing', (data) => {
      triggerEvent('typingStart', data);
    });

    newSocket.on('agent_typing_stop', (data) => {
      triggerEvent('typingStop', data);
    });

    newSocket.on('visitor_typing', (data) => {
      triggerEvent('typingStart', data);
    });

    newSocket.on('visitor_typing_stop', (data) => {
      triggerEvent('typingStop', data);
    });

    newSocket.on('heartbeat_ack', () => {
      setLastActivity(Date.now());
    });

    setSocket(newSocket);
    return newSocket;
  }, [user, token]);

  // Reconnection with exponential backoff
  const scheduleReconnect = useCallback(() => {
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
    }

    const delay = Math.min(1000 * Math.pow(2, connectionAttempts), 30000); // Max 30 seconds
    
    reconnectTimeoutRef.current = setTimeout(() => {
      if (connectionAttempts < 10) {
        console.log(`Reconnecting... (attempt ${connectionAttempts + 1})`);
        connect();
      } else {
        toast.error('Connection failed. Please refresh the page.');
      }
    }, delay);
  }, [connectionAttempts, connect]);

  // Heartbeat to maintain connection
  const startHeartbeat = useCallback((socket) => {
    if (heartbeatIntervalRef.current) {
      clearInterval(heartbeatIntervalRef.current);
    }

    heartbeatIntervalRef.current = setInterval(() => {
      if (socket && socket.connected) {
        socket.emit('heartbeat', { timestamp: Date.now() });
      }
    }, 30000);
  }, []);

  const stopHeartbeat = useCallback(() => {
    if (heartbeatIntervalRef.current) {
      clearInterval(heartbeatIntervalRef.current);
      heartbeatIntervalRef.current = null;
    }
  }, []);

  // Message queue for offline scenarios
  const queueMessage = useCallback((event, data) => {
    messageQueueRef.current.push({ event, data, timestamp: Date.now() });
    
    // Limit queue size
    if (messageQueueRef.current.length > 50) {
      messageQueueRef.current = messageQueueRef.current.slice(-50);
    }
  }, []);

  const processMessageQueue = useCallback((socket) => {
    const queue = messageQueueRef.current;
    messageQueueRef.current = [];
    
    queue.forEach(({ event, data }) => {
      if (socket && socket.connected) {
        socket.emit(event, data);
      }
    });
  }, []);

  // Event handler management
  const registerHandler = useCallback((event, handler) => {
    if (!eventHandlersRef.current.has(event)) {
      eventHandlersRef.current.set(event, new Set());
    }
    eventHandlersRef.current.get(event).add(handler);
  }, []);

  const unregisterHandler = useCallback((event, handler) => {
    const handlers = eventHandlersRef.current.get(event);
    if (handlers) {
      handlers.delete(handler);
    }
  }, []);

  const triggerEvent = useCallback((event, data) => {
    const handlers = eventHandlersRef.current.get(event);
    if (handlers) {
      handlers.forEach(handler => {
        try {
          handler(data);
        } catch (error) {
          console.error('Event handler error:', error);
        }
      });
    }
  }, []);

  // Socket actions with offline support
  const joinConversation = useCallback((conversationId) => {
    if (socket && isConnected) {
      socket.emit('join_conversation', { conversationId });
    } else {
      queueMessage('join_conversation', { conversationId });
    }
  }, [socket, isConnected, queueMessage]);

  const leaveConversation = useCallback((conversationId) => {
    if (socket && isConnected) {
      socket.emit('leave_conversation', { conversationId });
    }
  }, [socket, isConnected]);

  const sendMessage = useCallback((conversationId, content) => {
    if (socket && isConnected) {
      socket.emit('send_message', { conversationId, content });
    } else {
      queueMessage('send_message', { conversationId, content });
      toast.error('Message queued - connection lost');
    }
  }, [socket, isConnected, queueMessage]);

  const startTyping = useCallback((conversationId) => {
    if (socket && isConnected) {
      socket.emit('typing_start', { conversationId });
    }
  }, [socket, isConnected]);

  const stopTyping = useCallback((conversationId) => {
    if (socket && isConnected) {
      socket.emit('typing_stop', { conversationId });
    }
  }, [socket, isConnected]);

  // Initialize connection
  useEffect(() => {
    if (user && token) {
      connect();
    }

    return () => {
      if (socket) {
        socket.close();
      }
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
      stopHeartbeat();
    };
  }, [user, token, connect]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      eventHandlersRef.current.clear();
      messageQueueRef.current = [];
    };
  }, []);

  return {
    socket,
    isConnected,
    connectionAttempts,
    lastActivity,
    joinConversation,
    leaveConversation,
    sendMessage,
    startTyping,
    stopTyping,
    registerHandler,
    unregisterHandler,
    connect,
    queuedMessages: messageQueueRef.current.length
  };
};
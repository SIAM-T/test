import { useEffect, useRef } from 'react';
import { useSocket } from '../context/SocketContext';
import toast from 'react-hot-toast';
import soundNotification from '../utils/soundNotification';

const useRealTimeSync = () => {
  const { socket, isConnected } = useSocket();
  const eventHandlers = useRef(new Map());
  const lastEventTime = useRef(Date.now());

  // Register event handler
  const registerHandler = (eventName, handler) => {
    if (!eventHandlers.current.has(eventName)) {
      eventHandlers.current.set(eventName, new Set());
    }
    eventHandlers.current.get(eventName).add(handler);
  };

  // Unregister event handler
  const unregisterHandler = (eventName, handler) => {
    if (eventHandlers.current.has(eventName)) {
      eventHandlers.current.get(eventName).delete(handler);
    }
  };

  // Emit custom events to registered handlers
  const emitToHandlers = (eventName, data) => {
    if (eventHandlers.current.has(eventName)) {
      eventHandlers.current.get(eventName).forEach(handler => {
        try {
          handler(data);
        } catch (error) {
          console.error(`Error in event handler for ${eventName}:`, error);
        }
      });
    }
  };

  useEffect(() => {
    if (!socket) return;

    // Real-time event listeners
    const handleNewMessage = (data) => {
      console.log('RealTimeSync: New message received', data);
      lastEventTime.current = Date.now();
      emitToHandlers('message', data);
      
      // Play sound for visitor messages
      if (data.sender?.type === 'visitor') {
        soundNotification.playMessageSound();
      }
    };

    const handleNewConversation = (data) => {
      console.log('RealTimeSync: New conversation started', data);
      lastEventTime.current = Date.now();
      emitToHandlers('conversation', data);
      soundNotification.playMessageSound();
      toast.success('New conversation started');
    };

    const handleConversationUpdate = (data) => {
      console.log('RealTimeSync: Conversation updated', data);
      lastEventTime.current = Date.now();
      emitToHandlers('conversationUpdate', data);
    };

    const handleAgentStatusChange = (data) => {
      console.log('RealTimeSync: Agent status changed', data);
      lastEventTime.current = Date.now();
      emitToHandlers('agentStatus', data);
    };

    const handleTypingStart = (data) => {
      emitToHandlers('typingStart', data);
    };

    const handleTypingStop = (data) => {
      emitToHandlers('typingStop', data);
    };

    const handleMessageRead = (data) => {
      emitToHandlers('messageRead', data);
    };

    const handleError = (data) => {
      console.error('Socket error:', data);
      toast.error(data.message || 'Connection error occurred');
    };

    // Register socket event listeners
    socket.on('new_message', handleNewMessage);
    socket.on('new_conversation', handleNewConversation);
    socket.on('conversation_updated', handleConversationUpdate);
    socket.on('conversation_status_changed', handleConversationUpdate);
    socket.on('agent_online', handleAgentStatusChange);
    socket.on('agent_offline', handleAgentStatusChange);
    socket.on('agent_status_changed', handleAgentStatusChange);
    socket.on('visitor_typing', handleTypingStart);
    socket.on('visitor_typing_stop', handleTypingStop);
    socket.on('agent_typing', handleTypingStart);
    socket.on('agent_typing_stop', handleTypingStop);
    socket.on('message_read', handleMessageRead);
    socket.on('messages_marked_read', handleMessageRead);
    socket.on('error', handleError);

    return () => {
      socket.off('new_message', handleNewMessage);
      socket.off('new_conversation', handleNewConversation);
      socket.off('conversation_updated', handleConversationUpdate);
      socket.off('conversation_status_changed', handleConversationUpdate);
      socket.off('agent_online', handleAgentStatusChange);
      socket.off('agent_offline', handleAgentStatusChange);
      socket.off('agent_status_changed', handleAgentStatusChange);
      socket.off('visitor_typing', handleTypingStart);
      socket.off('visitor_typing_stop', handleTypingStop);
      socket.off('agent_typing', handleTypingStart);
      socket.off('agent_typing_stop', handleTypingStop);
      socket.off('message_read', handleMessageRead);
      socket.off('messages_marked_read', handleMessageRead);
      socket.off('error', handleError);
    };
  }, [socket]);

  // // Connection status monitoring
  // useEffect(() => {
  //   if (isConnected) {
  //     toast.success('Connected to live chat', { duration: 2000 });
  //   } else {
  //     toast.error('Disconnected from live chat', { duration: 3000 });
  //   }
  // }, [isConnected]);

  return {
    registerHandler,
    unregisterHandler,
    isConnected,
    lastEventTime: lastEventTime.current
  };
};

export default useRealTimeSync;
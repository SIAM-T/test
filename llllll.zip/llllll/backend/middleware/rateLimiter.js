const rateLimit = require('express-rate-limit');
const RedisStore = require('rate-limit-redis');
const Redis = require('redis');

// Create Redis client for rate limiting
let redisClient;
try {
  redisClient = Redis.createClient({
    host: process.env.REDIS_HOST || 'localhost',
    port: process.env.REDIS_PORT || 6379
  });
} catch (error) {
  console.warn('Redis not available for rate limiting, using memory store');
}

// Message sending rate limiter
const messageRateLimit = rateLimit({
  store: redisClient ? new RedisStore({
    client: redisClient,
    prefix: 'msg_limit:'
  }) : undefined,
  windowMs: 60 * 1000, // 1 minute
  max: 30, // 30 messages per minute per user
  message: {
    error: 'Too many messages sent. Please slow down.',
    retryAfter: 60
  },
  keyGenerator: (req) => {
    return req.user ? req.user._id.toString() : req.ip;
  },
  skip: (req) => {
    // Skip rate limiting for admins
    return req.user && req.user.role === 'admin';
  }
});

// API rate limiter
const apiRateLimit = rateLimit({
  store: redisClient ? new RedisStore({
    client: redisClient,
    prefix: 'api_limit:'
  }) : undefined,
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 1000, // 1000 requests per 15 minutes
  message: {
    error: 'Too many requests. Please try again later.',
    retryAfter: 900
  },
  keyGenerator: (req) => {
    return req.user ? req.user._id.toString() : req.ip;
  }
});

// Widget rate limiter (more restrictive for public endpoints)
const widgetRateLimit = rateLimit({
  store: redisClient ? new RedisStore({
    client: redisClient,
    prefix: 'widget_limit:'
  }) : undefined,
  windowMs: 60 * 1000, // 1 minute
  max: 10, // 10 requests per minute per IP
  message: {
    error: 'Too many requests from this IP. Please try again later.',
    retryAfter: 60
  },
  keyGenerator: (req) => req.ip
});

// File upload rate limiter
const fileUploadRateLimit = rateLimit({
  store: redisClient ? new RedisStore({
    client: redisClient,
    prefix: 'file_limit:'
  }) : undefined,
  windowMs: 60 * 1000, // 1 minute
  max: 5, // 5 file uploads per minute
  message: {
    error: 'Too many file uploads. Please wait before uploading again.',
    retryAfter: 60
  },
  keyGenerator: (req) => {
    return req.user ? req.user._id.toString() : req.ip;
  }
});

// Socket connection rate limiter
class SocketRateLimiter {
  constructor() {
    this.connections = new Map();
    this.cleanup();
  }

  checkConnection(ip, userId = null) {
    const key = userId || ip;
    const now = Date.now();
    const windowMs = 60 * 1000; // 1 minute
    const maxConnections = 10;

    if (!this.connections.has(key)) {
      this.connections.set(key, []);
    }

    const attempts = this.connections.get(key);
    
    // Remove old attempts
    const validAttempts = attempts.filter(time => now - time < windowMs);
    
    if (validAttempts.length >= maxConnections) {
      return false;
    }

    validAttempts.push(now);
    this.connections.set(key, validAttempts);
    return true;
  }

  cleanup() {
    // Clean up old entries every 5 minutes
    setInterval(() => {
      const now = Date.now();
      const windowMs = 60 * 1000;

      for (const [key, attempts] of this.connections.entries()) {
        const validAttempts = attempts.filter(time => now - time < windowMs);
        if (validAttempts.length === 0) {
          this.connections.delete(key);
        } else {
          this.connections.set(key, validAttempts);
        }
      }
    }, 5 * 60 * 1000);
  }
}

const socketRateLimiter = new SocketRateLimiter();

module.exports = {
  messageRateLimit,
  apiRateLimit,
  widgetRateLimit,
  fileUploadRateLimit,
  socketRateLimiter
};
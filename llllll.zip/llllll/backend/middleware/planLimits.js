const User = require('../models/User');
const Organization = require('../models/Organization');

// Middleware to check plan limits before adding members
const checkMemberLimit = async (req, res, next) => {
  try {
    const organization = await Organization.findById(req.user.organizationId._id);
    const currentAgents = await User.countDocuments({ 
      organizationId: organization._id, 
      isActive: true 
    });

    // Check if adding a new member would exceed the limit
    if (organization.limits.agents !== -1 && currentAgents >= organization.limits.agents) {
      return res.status(400).json({ 
        message: `Cannot add more members. Your ${organization.plan} plan allows only ${organization.limits.agents} members. Please upgrade your plan or remove inactive members.`,
        currentUsage: currentAgents,
        planLimit: organization.limits.agents,
        planName: organization.plan
      });
    }

    next();
  } catch (error) {
    console.error('Plan limit check error:', error);
    res.status(500).json({ message: 'Server error checking plan limits' });
  }
};

// Middleware to validate plan downgrade
const validatePlanDowngrade = async (req, res, next) => {
  try {
    const { plan } = req.body;
    
    if (!plan) {
      return next();
    }

    const organization = await Organization.findById(req.user.organizationId._id);
    const currentAgents = await User.countDocuments({ 
      organizationId: organization._id, 
      isActive: true 
    });

    // Get new plan limits
    const newLimits = organization.planLimits[plan];
    
    if (!newLimits) {
      return res.status(400).json({ message: 'Invalid plan selected' });
    }

    // Check if current usage exceeds new plan limits
    if (newLimits.agents !== -1 && currentAgents > newLimits.agents) {
      return res.status(400).json({ 
        message: `Cannot downgrade to ${plan} plan. You have ${currentAgents} active members but ${plan} plan allows only ${newLimits.agents} members. Please remove ${currentAgents - newLimits.agents} members first.`,
        currentUsage: { agents: currentAgents },
        newLimits: newLimits,
        requiredReduction: currentAgents - newLimits.agents
      });
    }

    next();
  } catch (error) {
    console.error('Plan downgrade validation error:', error);
    res.status(500).json({ message: 'Server error validating plan change' });
  }
};

module.exports = {
  checkMemberLimit,
  validatePlanDowngrade
};
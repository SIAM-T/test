const mongoose = require('mongoose');

const organizationSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    trim: true
  },
  domain: {
    type: String,
    required: true,
    unique: true,
    lowercase: true
  },
  logo: {
    type: String,
    default: null
  },
  plan: {
    type: String,
    enum: ['free', 'starter', 'professional', 'enterprise'],
    default: 'free'
  },
  limits: {
    agents: { type: Number, default: 2 },
    fileStorage: { type: Number, default: 100 } // MB
  },
  planLimits: {
    free: { type: Number, agents: 2, fileStorage: 100 },
    starter: { type: Number,  agents: 5, fileStorage: 500 },
    professional: { type: Number,  agents: 10, fileStorage: 2000 },
    enterprise: { type: Number,  agents: -1, fileStorage: -1 } // unlimited
  },
  settings: {
    workingHours: {
      enabled: { type: Boolean, default: false },
      timezone: { type: String, default: 'UTC' },
      schedule: {
        monday: { start: { type: String, default: '09:00' }, end: { type: String, default: '17:00' }, enabled: { type: Boolean, default: true } },
        tuesday: { start: { type: String, default: '09:00' }, end: { type: String, default: '17:00' }, enabled: { type: Boolean, default: true } },
        wednesday: { start: { type: String, default: '09:00' }, end: { type: String, default: '17:00' }, enabled: { type: Boolean, default: true } },
        thursday: { start: { type: String, default: '09:00' }, end: { type: String, default: '17:00' }, enabled: { type: Boolean, default: true } },
        friday: { start: { type: String, default: '09:00' }, end: { type: String, default: '17:00' }, enabled: { type: Boolean, default: true } },
        saturday: { start: { type: String, default: '09:00' }, end: { type: String, default: '17:00' }, enabled: { type: Boolean, default: false } },
        sunday: { start: { type: String, default: '09:00' }, end: { type: String, default: '17:00' }, enabled: { type: Boolean, default: false } }
      }
    },
    autoAssignment: { type: Boolean, default: true },
    offlineMessage: { type: String, default: 'We are currently offline. Please leave a message!' }
  },
  allowedDomains: {
    type: [String],
    default: ['*'] // Allow all domains by default
  },
  isActive: {
    type: Boolean,
    default: true
  }
}, {
  timestamps: true
});

// Index for performance
organizationSchema.index({ domain: 1 });

module.exports = mongoose.model('Organization', organizationSchema);
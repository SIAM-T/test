const mongoose = require('mongoose');

const widgetSchema = new mongoose.Schema({
  organizationId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Organization',
    required: true
  },
  name: {
    type: String,
    required: true,
    trim: true
  },
  widgetId: {
    type: String,
    required: true,
    unique: true
  },
  config: {
    // Appearance
    primaryColor: { type: String, default: '#3B82F6' },
    secondaryColor: { type: String, default: '#F8FAFC' },
    accentColor: { type: String, default: '#10B981' },
    textColor: { type: String, default: '#1F2937' },
    theme: { type: String, enum: ['light', 'dark'], default: 'light' },
    borderRadius: { type: Number, default: 16 },
    shadow: { type: String, enum: ['none', 'small', 'medium', 'large'], default: 'large' },
    opacity: { type: Number, default: 100 },
    
    // Layout & Position
    position: { type: String, enum: ['bottom-right', 'bottom-left', 'top-right', 'top-left'], default: 'bottom-right' },
    size: { type: String, enum: ['small', 'medium', 'large'], default: 'medium' },
    margin: { type: Number, default: 20 },
    zIndex: { type: Number, default: 9999 },
    
    // Behavior
    animation: { type: String, enum: ['none', 'bounce', 'pulse', 'shake'], default: 'bounce' },
    autoOpen: { type: Boolean, default: false },
    openDelay: { type: Number, default: 3000 },
    minimizeAfter: { type: Number, default: 30000 },
    soundEnabled: { type: Boolean, default: true },
    
    // Content
    companyName: { type: String, default: 'Your Company' },
    greeting: { type: String, default: 'Hi! How can I help you today?' },
    offlineMessage: { type: String, default: 'We\'re currently offline. Leave us a message!' },
    placeholder: { type: String, default: 'Type your message...' },
    
    // Features
    showAvatar: { type: Boolean, default: true },
    showOnline: { type: Boolean, default: true },
    showTyping: { type: Boolean, default: true },
    showTimestamp: { type: Boolean, default: true },
    showRating: { type: Boolean, default: true },
    fileUpload: { type: Boolean, default: true },
    emojiPicker: { type: Boolean, default: true },
    
    // Advanced
    language: { type: String, default: 'en' },
    timezone: { type: String, default: 'UTC' },
    workingHours: {
      enabled: { type: Boolean, default: false },
      start: { type: String, default: '09:00' },
      end: { type: String, default: '17:00' },
      days: [{ type: String, enum: ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun'] }]
    },
    
    // Triggers
    triggers: [{
      type: { type: String, enum: ['time', 'exit', 'scroll', 'page'] },
      value: mongoose.Schema.Types.Mixed,
      message: String,
      enabled: { type: Boolean, default: true }
    }],
    
    // Integrations
    analytics: { type: Boolean, default: true },
    crm: { type: String, enum: ['none', 'hubspot', 'salesforce', 'pipedrive'], default: 'none' },
    notifications: {
      desktop: { type: Boolean, default: true },
      sound: { type: Boolean, default: true },
      email: { type: Boolean, default: false }
    }
  },
  allowedDomains: [{
    type: String,
    lowercase: true
  }],
  isActive: {
    type: Boolean,
    default: true
  },
  stats: {
    totalViews: { type: Number, default: 0 },
    totalConversations: { type: Number, default: 0 },
    lastUsed: Date
  }
}, {
  timestamps: true
});

// Index for performance
widgetSchema.index({ organizationId: 1 });
widgetSchema.index({ widgetId: 1 });

// Generate unique widget ID before saving
widgetSchema.pre('save', function(next) {
  if (!this.widgetId) {
    this.widgetId = `widget_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }
  next();
});

module.exports = mongoose.model('Widget', widgetSchema);
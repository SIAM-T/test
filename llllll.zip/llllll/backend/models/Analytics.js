const mongoose = require('mongoose');

const analyticsSchema = new mongoose.Schema({
  organizationId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Organization',
    required: true
  },
  date: {
    type: Date,
    required: true
  },
  metrics: {
    // Conversations
    totalConversations: { type: Number, default: 0 },
    activeConversations: { type: Number, default: 0 },
    closedConversations: { type: Number, default: 0 },
    avgConversationDuration: { type: Number, default: 0 }, // seconds
    
    // Messages
    totalMessages: { type: Number, default: 0 },
    agentMessages: { type: Number, default: 0 },
    visitorMessages: { type: Number, default: 0 },
    
    // Response Times
    avgFirstResponseTime: { type: Number, default: 0 }, // seconds
    avgResponseTime: { type: Number, default: 0 },
    
    // Visitors
    totalVisitors: { type: Number, default: 0 },
    uniqueVisitors: { type: Number, default: 0 },
    returningVisitors: { type: Number, default: 0 },
    
    // Satisfaction
    avgRating: { type: Number, default: 0 },
    totalRatings: { type: Number, default: 0 },
    
    // Agents
    activeAgents: { type: Number, default: 0 },
    avgAgentLoad: { type: Number, default: 0 }, // conversations per agent
    
    // Widget Performance
    widgetViews: { type: Number, default: 0 },
    conversionRate: { type: Number, default: 0 } // conversations / views
  },
  hourlyBreakdown: [{
    hour: { type: Number, min: 0, max: 23 },
    conversations: { type: Number, default: 0 },
    messages: { type: Number, default: 0 },
    visitors: { type: Number, default: 0 }
  }],
  agentPerformance: [{
    agentId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    conversations: { type: Number, default: 0 },
    messages: { type: Number, default: 0 },
    avgResponseTime: { type: Number, default: 0 },
    avgRating: { type: Number, default: 0 }
  }],
  widgetPerformance: [{
    widgetId: String,
    views: { type: Number, default: 0 },
    conversations: { type: Number, default: 0 },
    conversionRate: { type: Number, default: 0 }
  }]
}, {
  timestamps: true
});

// Indexes for performance
analyticsSchema.index({ organizationId: 1, date: -1 });
analyticsSchema.index({ date: -1 });

module.exports = mongoose.model('Analytics', analyticsSchema);
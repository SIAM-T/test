const mongoose = require('mongoose');

const messageSchema = new mongoose.Schema({
  conversationId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Conversation',
    required: true
  },
  sender: {
    type: {
      type: String,
      enum: ['visitor', 'agent', 'system'],
      required: true
    },
    id: String, // visitorId or userId
    name: String,
    avatar: String
  },
  content: {
    type: String,
    required: true,
    trim: true
  },
  messageType: {
    type: String,
    enum: ['text', 'file', 'image', 'system'],
    default: 'text'
  },
  file: {
    url: String,
    name: String,
    size: Number,
    type: String,
    publicId: String // for Cloudinary
  },
  isRead: {
    type: Boolean,
    default: false
  },
  readAt: Date,
  editedAt: Date,
  isDeleted: {
    type: Boolean,
    default: false
  },
  metadata: {
    ip: String,
    userAgent: String,
    platform: String
  }
}, {
  timestamps: true
});

// Indexes for performance
messageSchema.index({ conversationId: 1, createdAt: -1 });
messageSchema.index({ 'sender.type': 1, 'sender.id': 1 });

module.exports = mongoose.model('Message', messageSchema);
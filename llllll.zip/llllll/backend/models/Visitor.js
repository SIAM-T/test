const mongoose = require('mongoose');

const visitorSchema = new mongoose.Schema({
  visitorId: {
    type: String,
    required: true,
    unique: true
  },
  organizationId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Organization',
    required: true
  },
  widgetId: {
    type: String,
    required: true
  },
  info: {
    name: String,
    email: String,
    phone: String
  },
  location: {
    country: String,
    city: String,
    region: String,
    ip: String,
    timezone: String
  },
  browser: {
    name: String,
    version: String,
    os: String,
    language: String
  },
  sessions: [{
    startTime: { type: Date, default: Date.now },
    endTime: Date,
    pages: [{
      url: String,
      title: String,
      visitTime: { type: Date, default: Date.now },
      duration: Number // seconds
    }],
    referrer: String,
    duration: Number // total session duration in seconds
  }],
  totalVisits: {
    type: Number,
    default: 1
  },
  totalConversations: {
    type: Number,
    default: 0
  },
  lastSeen: {
    type: Date,
    default: Date.now
  },
  isOnline: {
    type: Boolean,
    default: true
  },
  tags: [String],
  notes: String
}, {
  timestamps: true
});

// Indexes for performance
visitorSchema.index({ visitorId: 1 });
visitorSchema.index({ organizationId: 1, widgetId: 1 });
visitorSchema.index({ lastSeen: -1 });

module.exports = mongoose.model('Visitor', visitorSchema);
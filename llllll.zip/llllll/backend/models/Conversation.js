const mongoose = require('mongoose');

const conversationSchema = new mongoose.Schema({
  organizationId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Organization',
    required: true
  },
  widgetId: {
    type: String,
    required: true
  },
  visitorId: {
    type: String,
    required: true
  },
  assignedAgent: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    default: null
  },
  status: {
    type: String,
    enum: ['active', 'waiting', 'closed', 'archived'],
    default: 'waiting'
  },
  priority: {
    type: String,
    enum: ['low', 'normal', 'high', 'urgent'],
    default: 'normal'
  },
  visitor: {
    name: String,
    email: String,
    phone: String,
    location: {
      country: String,
      city: String,
      ip: String
    },
    browser: {
      name: String,
      version: String,
      os: String
    },
    page: {
      url: String,
      title: String,
      referrer: String
    }
  },
  tags: [String],
  rating: {
    score: { type: Number, min: 1, max: 5 },
    comment: String,
    ratedAt: Date
  },
  metadata: {
    firstResponseTime: Number, // seconds
    avgResponseTime: Number,
    totalMessages: { type: Number, default: 0 },
    duration: Number // seconds
  },
  closedAt: Date,
  closedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  closeReason: String
}, {
  timestamps: true
});

// Indexes for performance
conversationSchema.index({ organizationId: 1, status: 1 });
conversationSchema.index({ assignedAgent: 1, status: 1 });
conversationSchema.index({ widgetId: 1 });
conversationSchema.index({ visitorId: 1 });
conversationSchema.index({ createdAt: -1 });

module.exports = mongoose.model('Conversation', conversationSchema);
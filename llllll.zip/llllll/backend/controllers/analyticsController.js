const Conversation = require('../models/Conversation');
const Message = require('../models/Message');
const User = require('../models/User');

const analyticsController = {
  // Get analytics data
  getAnalytics: async (req, res) => {
    try {
      const organizationId = req.user.organizationId._id;
      const { period = '7d' } = req.query;

      // Calculate date range
      const now = new Date();
      let startDate;
      
      switch (period) {
        case '24h':
          startDate = new Date(now.getTime() - 24 * 60 * 60 * 1000);
          break;
        case '7d':
          startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
          break;
        case '30d':
          startDate = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
          break;
        default:
          startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
      }

      // Get analytics data
      const [
        totalConversations,
        activeConversations,
        totalMessages,
        avgResponseTime,
        satisfactionRating,
        conversationsByDay
      ] = await Promise.all([
        Conversation.countDocuments({ 
          organizationId,
          createdAt: { $gte: startDate }
        }),
        Conversation.countDocuments({ 
          organizationId,
          status: 'active'
        }),
        Message.countDocuments({
          conversationId: { $in: await Conversation.find({ organizationId }).distinct('_id') },
          createdAt: { $gte: startDate }
        }),
        // Mock response time for now
        Promise.resolve(2.5),
        // Get satisfaction rating
        Conversation.aggregate([
          { $match: { organizationId, 'rating.score': { $exists: true } } },
          { $group: { _id: null, avgRating: { $avg: '$rating.score' } } }
        ]),
        // Get conversations by day
        Conversation.aggregate([
          { 
            $match: { 
              organizationId,
              createdAt: { $gte: startDate }
            }
          },
          {
            $group: {
              _id: { $dateToString: { format: "%Y-%m-%d", date: "$createdAt" } },
              count: { $sum: 1 }
            }
          },
          { $sort: { _id: 1 } }
        ])
      ]);

      const avgRating = satisfactionRating.length > 0 ? satisfactionRating[0].avgRating : 0;

      res.json({
        metrics: {
          conversations: {
            total: totalConversations,
            active: activeConversations
          },
          satisfaction: {
            avgRating: Math.round(avgRating * 10) / 10
          },
          agents: {
            online: await User.countDocuments({ organizationId, isActive: true, isOnline: true }),
            total: await User.countDocuments({ organizationId, isActive: true })
          }
        },
        charts: {
          daily: conversationsByDay.map(item => ({
            _id: item.date,
            conversations: item.count,
            closed: Math.floor(item.count * 0.8)
          }))
        }
      });
    } catch (error) {
      console.error('Analytics error:', error);
      res.status(500).json({ message: 'Server error' });
    }
  }
};

module.exports = analyticsController;
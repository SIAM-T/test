const Widget = require('../models/Widget');
const Visitor = require('../models/Visitor');
const Conversation = require('../models/Conversation');
const Organization = require('../models/Organization');
const Message = require('../models/Message');

const embedController = {
  // Get widget configuration for embedding
  getWidgetConfig: async (req, res) => {
    try {
      const { widgetId } = req.params;
      const origin = req.get('Origin') || req.get('Referer');

      const widget = await Widget.findOne({ 
        widgetId, 
        isActive: true 
      }).populate('organizationId');

      if (!widget) {
        return res.status(404).json({ message: 'Widget not found' });
      }

      // Check if domain is allowed
      if (widget.allowedDomains.length > 0 && origin) {
        const isAllowed = widget.allowedDomains.some(domain => 
          origin.includes(domain.replace('https://', '').replace('http://', ''))
        );
        
        if (!isAllowed) {
          return res.status(403).json({ message: 'Domain not allowed' });
        }
      }

      // Check organization working hours
      const now = new Date();
      const organization = widget.organizationId;
      let isOnline = true;

      if (organization.settings.workingHours.enabled) {
        const currentDay = now.toLocaleDateString('en-US', { weekday: 'long' }).toLowerCase();
        const currentTime = now.toTimeString().slice(0, 5);
        
        const daySchedule = organization.settings.workingHours.schedule[currentDay];
        if (daySchedule && daySchedule.enabled) {
          isOnline = currentTime >= daySchedule.start && currentTime <= daySchedule.end;
        } else {
          isOnline = false;
        }
      }

      // Update widget stats
      await Widget.findByIdAndUpdate(widget._id, {
        $inc: { 'stats.totalViews': 1 },
        'stats.lastUsed': new Date()
      });

      res.json({
        widgetId: widget.widgetId,
        organizationId: widget.organizationId._id,
        config: widget.config,
        isOnline,
        organization: {
          name: organization.name,
          logo: organization.logo
        }
      });
    } catch (error) {
      console.error('Widget config error:', error);
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Track visitor
  trackVisitor: async (req, res) => {
    try {
      const {
        widgetId,
        visitorId,
        info,
        location,
        browser,
        page
      } = req.body;

      const widget = await Widget.findOne({ widgetId, isActive: true });
      if (!widget) {
        return res.status(404).json({ message: 'Widget not found' });
      }

      // Find or create visitor
      let visitor = await Visitor.findOne({ visitorId });
      
      if (visitor) {
        // Update existing visitor
        visitor.lastSeen = new Date();
        visitor.isOnline = true;
        visitor.totalVisits += 1;
        
        // Add new session
        visitor.sessions.push({
          startTime: new Date(),
          pages: [page],
          referrer: page.referrer
        });
        
        // Update info if provided
        if (info) {
          visitor.info = { ...visitor.info, ...info };
        }
      } else {
        // Create new visitor
        visitor = new Visitor({
          visitorId,
          organizationId: widget.organizationId,
          widgetId,
          info: info || {},
          location: location || {},
          browser: browser || {},
          sessions: [{
            startTime: new Date(),
            pages: [page],
            referrer: page.referrer
          }]
        });
      }

      await visitor.save();

      res.json({ 
        message: 'Visitor tracked successfully',
        visitorId: visitor.visitorId
      });
    } catch (error) {
      console.error('Visitor tracking error:', error);
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Get organization online status
  getStatus: async (req, res) => {
    try {
      const { organizationId } = req.params;

      const organization = await Organization.findById(organizationId);
      if (!organization) {
        return res.status(404).json({ message: 'Organization not found' });
      }

      // Check working hours
      const now = new Date();
      let isOnline = true;

      if (organization.settings.workingHours.enabled) {
        const currentDay = now.toLocaleDateString('en-US', { weekday: 'long' }).toLowerCase();
        const currentTime = now.toTimeString().slice(0, 5);
        
        const daySchedule = organization.settings.workingHours.schedule[currentDay];
        if (daySchedule && daySchedule.enabled) {
          isOnline = currentTime >= daySchedule.start && currentTime <= daySchedule.end;
        } else {
          isOnline = false;
        }
      }

      // Check if any agents are online
      const User = require('../models/User');
      const onlineAgents = await User.countDocuments({
        organizationId,
        isOnline: true,
        isActive: true
      });

      res.json({
        isOnline: isOnline && onlineAgents > 0,
        onlineAgents,
        workingHours: organization.settings.workingHours,
        offlineMessage: organization.settings.offlineMessage
      });
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Start conversation from widget
  startConversation: async (req, res) => {
    try {
      const {
        widgetId,
        visitorId,
        visitorInfo,
        initialMessage
      } = req.body;

      const widget = await Widget.findOne({ widgetId, isActive: true });
      if (!widget) {
        return res.status(404).json({ message: 'Widget not found' });
      }

      // Check if visitor already has an active conversation
      let conversation = await Conversation.findOne({
        widgetId,
        visitorId,
        status: { $in: ['active', 'waiting'] }
      });

      if (!conversation) {
        // Create new conversation
        conversation = new Conversation({
          organizationId: widget.organizationId,
          widgetId,
          visitorId,
          visitor: visitorInfo,
          status: 'waiting'
        });
        await conversation.save();

        // Update widget stats
        await Widget.findByIdAndUpdate(widget._id, {
          $inc: { 'stats.totalConversations': 1 }
        });
      }

      // Create initial message if provided
      if (initialMessage) {
        const message = new Message({
          conversationId: conversation._id,
          sender: {
            type: 'visitor',
            id: visitorId,
            name: visitorInfo.name || 'Visitor'
          },
          content: initialMessage,
          metadata: {
            ip: req.ip,
            userAgent: req.get('User-Agent')
          }
        });
        await message.save();

        // Update conversation message count
        await Conversation.findByIdAndUpdate(conversation._id, {
          $inc: { 'metadata.totalMessages': 1 }
        });
      }

      res.json({
        conversationId: conversation._id,
        status: conversation.status,
        message: 'Conversation started successfully'
      });
    } catch (error) {
      console.error('Conversation creation error:', error);
      res.status(500).json({ message: 'Server error' });
    }
  }
};

module.exports = embedController;
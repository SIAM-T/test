const bcrypt = require('bcryptjs');
const { generateTokens, verifyToken } = require('../config/jwt');
const User = require('../models/User');
const Organization = require('../models/Organization');
const crypto = require('crypto');

const authController = {
  // Register new organization and owner
  register: async (req, res) => {
    try {
      const { name, email, password, organizationName, domain } = req.body;

      // Check if user already exists
      const existingUser = await User.findOne({ email });
      if (existingUser) {
        return res.status(400).json({ message: 'User already exists' });
      }

      // Check if organization domain already exists
      const existingOrg = await Organization.findOne({ domain });
      if (existingOrg) {
        return res.status(400).json({ message: 'Organization domain already exists' });
      }

      // Create organization
      const organization = new Organization({
        name: organizationName,
        domain,
        allowedDomains: [`https://${domain}.com`, `https://www.${domain}.com`]
      });
      await organization.save();

      // Generate email verification token
      const emailVerificationToken = Math.random().toString(36).substr(2, 15) + Date.now().toString(36);
      
      // Create owner user
      const user = new User({
        name,
        email,
        password,
        role: 'owner',
        organizationId: organization._id,
        isEmailVerified: false,
        emailVerificationToken
      });
      await user.save();

      // Send email verification
      const { sendEmail, emailTemplates } = require('../utils/emailService');
      const verificationEmail = emailTemplates.emailVerification(name, emailVerificationToken);
      await sendEmail(email, 'Verify Your Email - LiveChatM', verificationEmail);

      await user.save();

      res.status(201).json({
        message: 'Registration successful! Please check your email to verify your account.',
        requiresVerification: true,
        user: {
          id: user._id,
          name: user.name,
          email: user.email,
          role: user.role,
          organizationId: user.organizationId
        },
        organization: {
          id: organization._id,
          name: organization.name,
          domain: organization.domain
        }
      });
    } catch (error) {
      console.error('Registration error:', error);
      res.status(500).json({ message: 'Server error during registration' });
    }
  },

  // Login
  login: async (req, res) => {
    try {
      const { email, password } = req.body;

      // Find user and populate organization
      const user = await User.findOne({ email }).populate('organizationId');
      if (!user) {
        return res.status(400).json({ message: 'Invalid credentials' });
      }

      // Check password
      const isMatch = await user.comparePassword(password);
      if (!isMatch) {
        return res.status(400).json({ message: 'Invalid credentials' });
      }

      // Check if user is active
      if (!user.isActive) {
        return res.status(400).json({ message: 'Account is deactivated' });
      }

      // Check if email is verified
      if (!user.isEmailVerified) {
        return res.status(403).json({ 
          message: 'Please verify your email address before signing in. Check your inbox for the verification link.',
          requiresVerification: true
        });
      }

      // Update last seen and online status
      user.lastSeen = new Date();
      user.isOnline = true;
      
      // Generate tokens
      const { accessToken, refreshToken } = generateTokens(user._id);
      user.refreshToken = refreshToken;
      await user.save();

      res.json({
        message: 'Login successful',
        user: {
          id: user._id,
          name: user.name,
          email: user.email,
          role: user.role,
          avatar: user.avatar,
          organizationId: user.organizationId._id,
          organization: {
            name: user.organizationId.name,
            domain: user.organizationId.domain,
            plan: user.organizationId.plan
          }
        },
        tokens: {
          accessToken,
          refreshToken
        }
      });
    } catch (error) {
      console.error('Login error:', error);
      res.status(500).json({ message: 'Server error during login' });
    }
  },

  // Refresh token
  refreshToken: async (req, res) => {
    try {
      const { refreshToken } = req.body;
      
      if (!refreshToken) {
        return res.status(401).json({ message: 'Refresh token required' });
      }

      // Verify refresh token
      const decoded = verifyToken(refreshToken, process.env.JWT_REFRESH_SECRET);
      const user = await User.findById(decoded.userId);
      
      if (!user || user.refreshToken !== refreshToken) {
        return res.status(401).json({ message: 'Invalid refresh token' });
      }

      // Generate new tokens
      const { accessToken, refreshToken: newRefreshToken } = generateTokens(user._id);
      user.refreshToken = newRefreshToken;
      await user.save();

      res.json({
        tokens: {
          accessToken,
          refreshToken: newRefreshToken
        }
      });
    } catch (error) {
      res.status(401).json({ message: 'Invalid refresh token' });
    }
  },

  // Logout
  logout: async (req, res) => {
    try {
      const user = await User.findById(req.user._id);
      user.refreshToken = null;
      user.isOnline = false;
      user.lastSeen = new Date();
      await user.save();

      res.json({ message: 'Logout successful' });
    } catch (error) {
      res.status(500).json({ message: 'Server error during logout' });
    }
  },

  // Get current user
  getMe: async (req, res) => {
    try {
      const user = await User.findById(req.user._id)
        .populate('organizationId')
        .select('-password -refreshToken');

      res.json({
        user: {
          id: user._id,
          name: user.name,
          email: user.email,
          role: user.role,
          avatar: user.avatar,
          isOnline: user.isOnline,
          lastSeen: user.lastSeen,
          isEmailVerified: user.isEmailVerified,
          settings: user.settings,
          organization: {
            id: user.organizationId._id,
            name: user.organizationId.name,
            domain: user.organizationId.domain,
            plan: user.organizationId.plan
          }
        }
      });
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Forgot password
  forgotPassword: async (req, res) => {
    try {
      const { email } = req.body;
      
      const user = await User.findOne({ email });
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }

      // Generate reset token
      const resetToken = Math.random().toString(36).substr(2, 15) + Date.now().toString(36);
      user.resetPasswordToken = resetToken;
      user.resetPasswordExpires = Date.now() + 3600000; // 1 hour
      await user.save();

      // Send password reset email
      const { sendEmail, emailTemplates } = require('../utils/emailService');
      const resetEmail = emailTemplates.passwordReset(user.name, resetToken);
      await sendEmail(user.email, 'Reset Your Password - LiveChatM', resetEmail);

      res.json({ 
        message: 'Password reset email sent successfully'
      });
    } catch (error) {
      console.error('Forgot password error:', error);
      res.status(500).json({ message: 'Failed to send password reset email' });
    }
  },

  // Reset password
  resetPassword: async (req, res) => {
    try {
      const { token, newPassword } = req.body;
      
      const user = await User.findOne({
        resetPasswordToken: token,
        resetPasswordExpires: { $gt: Date.now() }
      });

      if (!user) {
        return res.status(400).json({ message: 'Invalid or expired reset token' });
      }

      user.password = newPassword;
      user.resetPasswordToken = undefined;
      user.resetPasswordExpires = undefined;
      await user.save();

      res.json({ message: 'Password reset successful' });
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Send verification email
  sendVerificationEmail: async (req, res) => {
    try {
      const user = await User.findById(req.user._id);
      
      if (user.isEmailVerified) {
        return res.status(400).json({ message: 'Email already verified' });
      }

      // Generate verification token
      const verificationToken = Math.random().toString(36).substr(2, 15) + Date.now().toString(36);
      user.emailVerificationToken = verificationToken;
      await user.save();

      // Send verification email
      const { sendEmail, emailTemplates } = require('../utils/emailService');
      const verificationEmail = emailTemplates.emailVerification(user.name, verificationToken);
      await sendEmail(user.email, 'Verify Your Email - LiveChatM', verificationEmail);

      res.json({ 
        message: 'Verification email sent successfully'
      });
    } catch (error) {
      console.error('Send verification error:', error);
      res.status(500).json({ message: 'Failed to send verification email' });
    }
  },

  // Verify email
  verifyEmail: async (req, res) => {
    try {
      const { token } = req.body;
      
      const user = await User.findOne({ emailVerificationToken: token }).populate('organizationId');
      if (!user) {
        return res.status(400).json({ message: 'Invalid or expired verification token' });
      }

      user.isEmailVerified = true;
      user.emailVerificationToken = undefined;
      await user.save();

      // Send welcome email after verification
      const { sendEmail, emailTemplates } = require('../utils/emailService');
      const welcomeEmail = emailTemplates.welcome(user.name, user.organizationId.name);
      await sendEmail(user.email, 'Welcome to LiveChatM!', welcomeEmail);

      res.json({ message: 'Email verified successfully! Welcome email sent.' });
    } catch (error) {
      console.error('Email verification error:', error);
      res.status(500).json({ message: 'Server error during verification' });
    }
  }
};

module.exports = authController;
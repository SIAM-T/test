const Message = require('../models/Message');
const Conversation = require('../models/Conversation');

const messageController = {
  // Send message from agent
  sendMessage: async (req, res) => {
    try {
      const { conversationId, content, messageType = 'text' } = req.body;

      // Verify conversation belongs to user's organization
      const conversation = await Conversation.findOne({
        _id: conversationId,
        organizationId: req.user.organizationId._id
      });

      if (!conversation) {
        return res.status(404).json({ message: 'Conversation not found' });
      }

      // Create message
      const message = new Message({
        conversationId,
        sender: {
          type: 'agent',
          id: req.user._id.toString(),
          name: req.user.name,
          avatar: req.user.avatar
        },
        content,
        messageType,
        metadata: {
          ip: req.ip,
          userAgent: req.get('User-Agent')
        }
      });

      await message.save();

      // Update conversation
      await Conversation.findByIdAndUpdate(conversationId, {
        $inc: { 'metadata.totalMessages': 1 },
        updatedAt: new Date(),
        status: conversation.status === 'waiting' ? 'active' : conversation.status,
        assignedAgent: conversation.assignedAgent || req.user._id
      });

      res.status(201).json({
        message: 'Message sent successfully',
        data: message
      });
    } catch (error) {
      console.error('Message send error:', error);
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Send message from visitor
  sendVisitorMessage: async (req, res) => {
    try {
      const { conversationId, visitorId, content, visitorInfo } = req.body;

      if (!conversationId || !visitorId || !content) {
        return res.status(400).json({ message: 'Missing required fields' });
      }

      // Verify conversation exists and belongs to visitor
      const conversation = await Conversation.findOne({
        _id: conversationId,
        visitorId
      });

      if (!conversation) {
        return res.status(404).json({ message: 'Conversation not found' });
      }

      // Create message
      const message = new Message({
        conversationId,
        sender: {
          type: 'visitor',
          id: visitorId,
          name: visitorInfo?.name || 'Visitor',
          avatar: visitorInfo?.avatar
        },
        content: content.trim(),
        messageType: 'text',
        metadata: {
          ip: req.ip,
          userAgent: req.get('User-Agent')
        }
      });

      await message.save();

      // Update conversation
      const updateData = {
        $inc: { 'metadata.totalMessages': 1 },
        updatedAt: new Date()
      };

      // Calculate first response time if this is the first visitor message
      if (conversation.metadata.totalMessages === 0) {
        updateData['metadata.firstResponseTime'] = null;
      }

      await Conversation.findByIdAndUpdate(conversationId, updateData);

      res.status(201).json({
        message: 'Message sent successfully',
        data: message
      });
    } catch (error) {
      console.error('Visitor message error:', error);
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Get messages for conversation
  getMessages: async (req, res) => {
    try {
      const { conversationId } = req.params;
      const { page = 1, limit = 50 } = req.query;
      const skip = (page - 1) * limit;

      // Verify conversation belongs to user's organization
      const conversation = await Conversation.findOne({
        _id: conversationId,
        organizationId: req.user.organizationId._id
      });

      if (!conversation) {
        return res.status(404).json({ message: 'Conversation not found' });
      }

      const messages = await Message.find({
        conversationId,
        isDeleted: false
      })
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit));

      const total = await Message.countDocuments({
        conversationId,
        isDeleted: false
      });

      res.json({
        messages: messages.reverse(),
        pagination: {
          current: parseInt(page),
          pages: Math.ceil(total / limit),
          total
        }
      });
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Mark messages as read
  markAsRead: async (req, res) => {
    try {
      const { messageIds } = req.body;

      if (!Array.isArray(messageIds)) {
        return res.status(400).json({ message: 'messageIds must be an array' });
      }

      await Message.updateMany(
        {
          _id: { $in: messageIds },
          isRead: false
        },
        {
          isRead: true,
          readAt: new Date()
        }
      );

      res.json({ message: 'Messages marked as read' });
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Delete message
  deleteMessage: async (req, res) => {
    try {
      const message = await Message.findById(req.params.id);
      
      if (!message) {
        return res.status(404).json({ message: 'Message not found' });
      }

      // Verify message belongs to user's organization
      const conversation = await Conversation.findOne({
        _id: message.conversationId,
        organizationId: req.user.organizationId._id
      });

      if (!conversation) {
        return res.status(404).json({ message: 'Conversation not found' });
      }

      // Only allow deletion of own messages or if admin
      if (message.sender.id !== req.user._id.toString() && 
          req.user.role !== 'admin' && req.user.role !== 'owner') {
        return res.status(403).json({ message: 'Not authorized to delete this message' });
      }

      await Message.findByIdAndUpdate(req.params.id, {
        isDeleted: true,
        content: '[Message deleted]',
        updatedAt: new Date()
      });

      res.json({ message: 'Message deleted successfully' });
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Get unread message count for agent
  getUnreadCount: async (req, res) => {
    try {
      // Get conversations assigned to this agent
      const conversations = await Conversation.find({
        organizationId: req.user.organizationId._id,
        assignedAgent: req.user._id,
        status: 'active'
      }).select('_id');

      const conversationIds = conversations.map(c => c._id);

      const unreadCount = await Message.countDocuments({
        conversationId: { $in: conversationIds },
        'sender.type': 'visitor',
        isRead: false,
        isDeleted: false
      });

      res.json({ unreadCount });
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  }
};

module.exports = messageController;
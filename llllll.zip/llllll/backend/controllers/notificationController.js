const Notification = require('../models/Notification');

const notificationController = {
  // Get notifications for user
  getNotifications: async (req, res) => {
    try {
      const { page = 1, limit = 20, unreadOnly = false } = req.query;
      const skip = (page - 1) * limit;

      let query = { userId: req.user._id };
      if (unreadOnly === 'true') {
        query.isRead = false;
      }

      const notifications = await Notification.find(query)
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(parseInt(limit))
        .populate('data.conversationId', 'visitor.name status')
        .populate('data.messageId', 'content sender');

      const total = await Notification.countDocuments(query);
      const unreadCount = await Notification.countDocuments({
        userId: req.user._id,
        isRead: false
      });

      res.json({
        notifications,
        pagination: {
          current: parseInt(page),
          pages: Math.ceil(total / limit),
          total
        },
        unreadCount
      });
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Mark notification as read
  markAsRead: async (req, res) => {
    try {
      const notification = await Notification.findOneAndUpdate(
        {
          _id: req.params.id,
          userId: req.user._id
        },
        {
          isRead: true,
          readAt: new Date()
        },
        { new: true }
      );

      if (!notification) {
        return res.status(404).json({ message: 'Notification not found' });
      }

      res.json({
        message: 'Notification marked as read',
        notification
      });
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Mark all notifications as read
  markAllAsRead: async (req, res) => {
    try {
      await Notification.updateMany(
        {
          userId: req.user._id,
          isRead: false
        },
        {
          isRead: true,
          readAt: new Date()
        }
      );

      res.json({ message: 'All notifications marked as read' });
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Delete notification
  deleteNotification: async (req, res) => {
    try {
      const notification = await Notification.findOneAndDelete({
        _id: req.params.id,
        userId: req.user._id
      });

      if (!notification) {
        return res.status(404).json({ message: 'Notification not found' });
      }

      res.json({ message: 'Notification deleted successfully' });
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Get notification settings
  getSettings: async (req, res) => {
    try {
      const user = await req.user.populate('organizationId');
      
      res.json({
        settings: user.settings.notifications
      });
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Update notification settings
  updateSettings: async (req, res) => {
    try {
      const { email, desktop, sound } = req.body;
      
      const User = require('../models/User');
      const user = await User.findByIdAndUpdate(
        req.user._id,
        {
          'settings.notifications': {
            email: typeof email === 'boolean' ? email : req.user.settings.notifications.email,
            desktop: typeof desktop === 'boolean' ? desktop : req.user.settings.notifications.desktop,
            sound: typeof sound === 'boolean' ? sound : req.user.settings.notifications.sound
          }
        },
        { new: true }
      ).select('settings.notifications');

      res.json({
        message: 'Notification settings updated',
        settings: user.settings.notifications
      });
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  }
};

// Create notification helper
const createNotification = async (data) => {
  try {
    const notification = new Notification(data);
    await notification.save();
    return notification;
  } catch (error) {
    console.error('Notification creation error:', error);
  }
};

// Notification helpers
const notificationHelpers = {
  newConversation: async (organizationId, conversation) => {
    const User = require('../models/User');
    const agents = await User.find({
      organizationId,
      role: { $in: ['agent', 'admin', 'owner'] },
      isActive: true,
      'settings.notifications.desktop': true
    });

    const notifications = agents.map(agent => ({
      organizationId,
      userId: agent._id,
      type: 'new_conversation',
      title: 'New Conversation',
      message: `New conversation from ${conversation.visitor.name || 'Visitor'}`,
      data: {
        conversationId: conversation._id,
        visitorName: conversation.visitor.name || 'Visitor'
      },
      priority: 'normal'
    }));

    await Promise.all(notifications.map(createNotification));
  },

  newMessage: async (organizationId, message, conversation) => {
    if (message.sender.type === 'visitor' && conversation.assignedAgent) {
      await createNotification({
        organizationId,
        userId: conversation.assignedAgent,
        type: 'new_message',
        title: 'New Message',
        message: `New message from ${conversation.visitor.name || 'Visitor'}`,
        data: {
          conversationId: conversation._id,
          messageId: message._id,
          visitorName: conversation.visitor.name || 'Visitor'
        },
        priority: 'high'
      });
    }
  },

  conversationAssigned: async (organizationId, conversation, agent) => {
    await createNotification({
      organizationId,
      userId: agent._id,
      type: 'conversation_assigned',
      title: 'Conversation Assigned',
      message: `You have been assigned a conversation with ${conversation.visitor.name || 'Visitor'}`,
      data: {
        conversationId: conversation._id,
        visitorName: conversation.visitor.name || 'Visitor'
      },
      priority: 'high'
    });
  },

  conversationClosed: async (organizationId, conversation, closedBy) => {
    if (conversation.assignedAgent && conversation.assignedAgent.toString() !== closedBy.toString()) {
      await createNotification({
        organizationId,
        userId: conversation.assignedAgent,
        type: 'conversation_closed',
        title: 'Conversation Closed',
        message: `Conversation with ${conversation.visitor.name || 'Visitor'} was closed`,
        data: {
          conversationId: conversation._id,
          visitorName: conversation.visitor.name || 'Visitor'
        },
        priority: 'low'
      });
    }
  }
};

module.exports = { 
  notificationController, 
  createNotification, 
  notificationHelpers 
};
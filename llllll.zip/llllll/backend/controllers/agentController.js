const User = require('../models/User');
const Conversation = require('../models/Conversation');
const Message = require('../models/Message');

const agentController = {
  // Get all agents in organization
  getAgents: async (req, res) => {
    try {
      const agents = await User.find({
        organizationId: req.user.organizationId._id,
        role: { $in: ['agent', 'admin'] },
        isActive: true
      })
      .select('name email avatar role isOnline lastSeen settings createdAt')
      .sort({ isOnline: -1, lastSeen: -1 });

      res.json({ agents });
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Get agent performance statistics
  getAgentStats: async (req, res) => {
    try {
      const agentId = req.params.id;
      const { period = '30' } = req.query;
      
      const agent = await User.findOne({
        _id: agentId,
        organizationId: req.user.organizationId._id,
        isActive: true
      });

      if (!agent) {
        return res.status(404).json({ message: 'Agent not found' });
      }

      const startDate = new Date();
      startDate.setDate(startDate.getDate() - parseInt(period));

      const conversationStats = await Conversation.aggregate([
        {
          $match: {
            assignedAgent: agent._id,
            createdAt: { $gte: startDate }
          }
        },
        {
          $group: {
            _id: null,
            totalConversations: { $sum: 1 },
            closedConversations: { $sum: { $cond: [{ $eq: ['$status', 'closed'] }, 1, 0] } },
            avgDuration: { $avg: '$metadata.duration' },
            avgRating: { $avg: '$rating.score' },
            totalRatings: { $sum: { $cond: [{ $ne: ['$rating.score', null] }, 1, 0] } }
          }
        }
      ]);

      const messageStats = await Message.aggregate([
        {
          $lookup: {
            from: 'conversations',
            localField: 'conversationId',
            foreignField: '_id',
            as: 'conversation'
          }
        },
        {
          $match: {
            'conversation.assignedAgent': agent._id,
            'sender.type': 'agent',
            'sender.id': agentId,
            createdAt: { $gte: startDate }
          }
        },
        {
          $group: {
            _id: null,
            totalMessages: { $sum: 1 },
            avgResponseTime: { $avg: '$metadata.responseTime' }
          }
        }
      ]);

      const stats = conversationStats[0] || {};
      const msgStats = messageStats[0] || {};

      res.json({
        agent: {
          id: agent._id,
          name: agent.name,
          avatar: agent.avatar,
          isOnline: agent.isOnline,
          lastSeen: agent.lastSeen
        },
        period: parseInt(period),
        stats: {
          conversations: {
            total: stats.totalConversations || 0,
            closed: stats.closedConversations || 0,
            active: (stats.totalConversations || 0) - (stats.closedConversations || 0)
          },
          messages: {
            total: msgStats.totalMessages || 0,
            avgResponseTime: Math.round(msgStats.avgResponseTime || 0)
          },
          performance: {
            avgDuration: Math.round(stats.avgDuration || 0),
            avgRating: Math.round((stats.avgRating || 0) * 10) / 10,
            totalRatings: stats.totalRatings || 0,
            resolutionRate: stats.totalConversations > 0 
              ? Math.round((stats.closedConversations / stats.totalConversations) * 100)
              : 0
          }
        }
      });
    } catch (error) {
      console.error('Agent stats error:', error);
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Get agent's conversations
  getAgentConversations: async (req, res) => {
    try {
      const agentId = req.params.id;
      const { status = 'active', page = 1, limit = 20 } = req.query;
      const skip = (page - 1) * limit;

      const agent = await User.findOne({
        _id: agentId,
        organizationId: req.user.organizationId._id,
        isActive: true
      });

      if (!agent) {
        return res.status(404).json({ message: 'Agent not found' });
      }

      let query = { assignedAgent: agent._id };
      if (status !== 'all') {
        query.status = status;
      }

      const conversations = await Conversation.find(query)
        .sort({ updatedAt: -1 })
        .skip(skip)
        .limit(parseInt(limit))
        .populate('assignedAgent', 'name avatar');

      const total = await Conversation.countDocuments(query);

      res.json({
        conversations,
        pagination: {
          current: parseInt(page),
          pages: Math.ceil(total / limit),
          total
        }
      });
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Update agent availability
  updateAvailability: async (req, res) => {
    try {
      const { isOnline, maxChats } = req.body;
      
      const updateData = {};
      if (typeof isOnline === 'boolean') {
        updateData.isOnline = isOnline;
        updateData.lastSeen = new Date();
      }
      if (maxChats && maxChats > 0) {
        updateData['settings.maxChats'] = maxChats;
      }

      const user = await User.findByIdAndUpdate(
        req.user._id,
        updateData,
        { new: true }
      ).select('-password -refreshToken');

      res.json({
        message: 'Availability updated successfully',
        user
      });
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Get agent workload
  getWorkload: async (req, res) => {
    try {
      const agents = await User.find({
        organizationId: req.user.organizationId._id,
        role: { $in: ['agent', 'admin'] },
        isActive: true,
        isOnline: true
      }).select('name avatar settings.maxChats');

      const workload = await Promise.all(
        agents.map(async (agent) => {
          const activeConversations = await Conversation.countDocuments({
            assignedAgent: agent._id,
            status: 'active'
          });

          return {
            agentId: agent._id,
            name: agent.name,
            avatar: agent.avatar,
            activeConversations,
            maxChats: agent.settings.maxChats || 5,
            availability: activeConversations < (agent.settings.maxChats || 5)
          };
        })
      );

      res.json({ workload });
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Auto-assign conversation
  autoAssign: async (req, res) => {
    try {
      const { conversationId } = req.params;

      const conversation = await Conversation.findOne({
        _id: conversationId,
        organizationId: req.user.organizationId._id,
        status: 'waiting'
      });

      if (!conversation) {
        return res.status(404).json({ message: 'Conversation not found or already assigned' });
      }

      const availableAgents = await User.find({
        organizationId: req.user.organizationId._id,
        role: { $in: ['agent', 'admin'] },
        isActive: true,
        isOnline: true,
        'settings.autoAssign': true
      });

      if (availableAgents.length === 0) {
        return res.status(400).json({ message: 'No available agents' });
      }

      let selectedAgent = null;
      let minWorkload = Infinity;

      for (const agent of availableAgents) {
        const activeConversations = await Conversation.countDocuments({
          assignedAgent: agent._id,
          status: 'active'
        });

        const maxChats = agent.settings.maxChats || 5;
        
        if (activeConversations < maxChats && activeConversations < minWorkload) {
          minWorkload = activeConversations;
          selectedAgent = agent;
        }
      }

      if (!selectedAgent) {
        return res.status(400).json({ message: 'All agents are at capacity' });
      }

      const updatedConversation = await Conversation.findByIdAndUpdate(
        conversationId,
        {
          assignedAgent: selectedAgent._id,
          status: 'active',
          updatedAt: new Date()
        },
        { new: true }
      ).populate('assignedAgent', 'name avatar');

      const systemMessage = new Message({
        conversationId,
        sender: {
          type: 'system',
          name: 'System'
        },
        content: `Conversation automatically assigned to ${selectedAgent.name}`,
        messageType: 'system'
      });
      await systemMessage.save();

      res.json({
        message: 'Conversation assigned successfully',
        conversation: updatedConversation,
        assignedAgent: selectedAgent
      });
    } catch (error) {
      console.error('Auto-assign error:', error);
      res.status(500).json({ message: 'Server error' });
    }
  }
};

module.exports = agentController;
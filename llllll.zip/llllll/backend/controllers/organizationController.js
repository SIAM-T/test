const Organization = require('../models/Organization');
const User = require('../models/User');
const Widget = require('../models/Widget');
const Conversation = require('../models/Conversation');
const Message = require('../models/Message');
const { uploadFile } = require('../config/cloudinary');
const bcrypt = require('bcryptjs');

const organizationController = {
  // Get organization details
  getOrganization: async (req, res) => {
    try {
      const organization = await Organization.findById(req.user.organizationId._id);
      
      if (!organization) {
        return res.status(404).json({ message: 'Organization not found' });
      }

      res.json({ organization });
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Update organization
  updateOrganization: async (req, res) => {
    try {
      const { name, allowedDomains, settings } = req.body;
      
      const updateData = {};
      if (name) updateData.name = name;
      if (allowedDomains) updateData.allowedDomains = allowedDomains;
      if (settings) updateData.settings = { ...req.user.organizationId.settings, ...settings };

      const organization = await Organization.findByIdAndUpdate(
        req.user.organizationId._id,
        updateData,
        { new: true }
      );

      res.json({
        message: 'Organization updated successfully',
        organization
      });
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Update plan
  updatePlan: async (req, res) => {
    try {
      const { plan } = req.body;
      
      const validPlans = ['free', 'starter', 'professional', 'enterprise'];
      if (!validPlans.includes(plan)) {
        return res.status(400).json({ message: 'Invalid plan selected' });
      }

      const organization = await Organization.findById(req.user.organizationId._id);
      const currentAgents = await User.countDocuments({ 
        organizationId: organization._id, 
        isActive: true 
      });

      // Check if downgrading and current usage exceeds new limits
      const newLimits = organization.planLimits[plan];
      if (newLimits.agents !== -1 && currentAgents > newLimits.agents) {
        return res.status(400).json({ 
          message: `Cannot downgrade to ${plan} plan. You have ${currentAgents} active members but ${plan} plan allows only ${newLimits.agents} members. Please remove ${currentAgents - newLimits.agents} members first.`,
          currentUsage: { agents: currentAgents },
          newLimits: newLimits
        });
      }

      // Update plan and limits
      const updatedOrganization = await Organization.findByIdAndUpdate(
        req.user.organizationId._id,
        { 
          plan,
          limits: {
            agents: newLimits.agents,
            fileStorage: newLimits.fileStorage
          }
        },
        { new: true }
      );

      res.json({ 
        message: 'Plan updated successfully',
        organization: updatedOrganization
      });
    } catch (error) {
      console.error('Plan update error:', error);
      res.status(500).json({ message: 'Failed to update plan' });
    }
  },

  // Upload organization logo
  uploadLogo: async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: 'No file uploaded' });
      }

      // Upload to Cloudinary
      const result = await uploadFile(req.file, 'logos');
      
      // Update organization logo
      const organization = await Organization.findByIdAndUpdate(
        req.user.organizationId._id,
        { logo: result.secure_url },
        { new: true }
      );

      res.json({
        message: 'Logo updated successfully',
        logo: result.secure_url,
        organization
      });
    } catch (error) {
      console.error('Logo upload error:', error);
      res.status(500).json({ message: 'Logo upload failed' });
    }
  },

  // Get organization statistics
  getStats: async (req, res) => {
    try {
      const organizationId = req.user.organizationId._id;
      
      // Get various counts
      const [
        totalAgents,
        activeAgents,
        totalWidgets,
        totalConversations,
        activeConversations,
        totalMessages,
        todayConversations,
        todayMessages
      ] = await Promise.all([
        User.countDocuments({ organizationId, isActive: true }),
        User.countDocuments({ organizationId, isActive: true, isOnline: true, role: { $in: ['agent', 'admin', 'owner'] } }),
        Widget.countDocuments({ organizationId, isActive: true }),
        Conversation.countDocuments({ organizationId }),
        Conversation.countDocuments({ organizationId, status: 'active' }),
        Message.countDocuments({ 
          conversationId: { $in: await Conversation.find({ organizationId }).distinct('_id') }
        }),
        Conversation.countDocuments({
          organizationId,
          createdAt: { $gte: new Date().setHours(0, 0, 0, 0) }
        }),
        Message.countDocuments({
          conversationId: { $in: await Conversation.find({ organizationId }).distinct('_id') },
          createdAt: { $gte: new Date().setHours(0, 0, 0, 0) }
        })
      ]);

      // Get average rating
      const ratingStats = await Conversation.aggregate([
        { $match: { organizationId, 'rating.score': { $exists: true } } },
        { $group: { _id: null, avgRating: { $avg: '$rating.score' }, totalRatings: { $sum: 1 } } }
      ]);

      const avgRating = ratingStats.length > 0 ? ratingStats[0].avgRating : 0;
      const totalRatings = ratingStats.length > 0 ? ratingStats[0].totalRatings : 0;

      res.json({
        stats: {
          agents: {
            total: totalAgents,
            active: activeAgents
          },
          widgets: {
            total: totalWidgets
          },
          conversations: {
            total: totalConversations,
            active: activeConversations,
            today: todayConversations
          },
          messages: {
            total: totalMessages,
            today: todayMessages
          },
          satisfaction: {
            avgRating: Math.round(avgRating * 10) / 10,
            totalRatings
          }
        }
      });
    } catch (error) {
      console.error('Stats error:', error);
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Update working hours
  updateWorkingHours: async (req, res) => {
    try {
      const { workingHours } = req.body;

      const organization = await Organization.findByIdAndUpdate(
        req.user.organizationId._id,
        {
          'settings.workingHours': workingHours
        },
        { new: true }
      );

      res.json({
        message: 'Working hours updated successfully',
        workingHours: organization.settings.workingHours
      });
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Get plan limits and usage
  getLimits: async (req, res) => {
    try {
      const organization = await Organization.findById(req.user.organizationId._id);
      
      // Get current usage
      const [currentAgents, currentWidgets] = await Promise.all([
        User.countDocuments({ organizationId: organization._id, isActive: true }),
        Widget.countDocuments({ organizationId: organization._id, isActive: true })
      ]);

      res.json({
        plan: organization.plan,
        limits: organization.limits,
        usage: {
          agents: currentAgents,
          widgets: currentWidgets
        }
      });
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Get organization members
  getMembers: async (req, res) => {
    try {
      const members = await User.find({ 
        organizationId: req.user.organizationId._id,
        isActive: true 
      }).select('-password').sort({ createdAt: -1 });

      res.json({ members });
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Invite member
  inviteMember: async (req, res) => {
    try {
      const { email, role = 'agent' } = req.body;
      
      // Check if user already exists
      const existingUser = await User.findOne({ email });
      if (existingUser) {
        return res.status(400).json({ message: 'User already exists' });
      }

      // Check plan limits
      const organization = await Organization.findById(req.user.organizationId._id);
      const currentAgents = await User.countDocuments({ 
        organizationId: organization._id, 
        isActive: true 
      });

      if (organization.limits.agents !== -1 && currentAgents >= organization.limits.agents) {
        return res.status(400).json({ 
          message: `Cannot add more members. Your ${organization.plan} plan allows only ${organization.limits.agents} members. Please upgrade your plan or remove inactive members.`,
          currentUsage: currentAgents,
          planLimit: organization.limits.agents
        });
      }

      // Generate secure temporary password
      const tempPassword = Math.random().toString(36).slice(-8) + Math.random().toString(36).slice(-8).toUpperCase();
      
      const newUser = new User({
        name: email.split('@')[0],
        email,
        password: tempPassword,
        role,
        organizationId: req.user.organizationId._id,
        isActive: true,
        isEmailVerified: true // Invited users are pre-verified
      });

      await newUser.save();

      // Send invitation email
      const { sendEmail } = require('../utils/emailService');
      const inviteEmailHtml = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #2563eb;">Welcome to ${organization.name}!</h2>
          <p>You've been invited to join <strong>${organization.name}</strong> on LiveChatM.</p>
          <div style="background: #f3f4f6; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <p><strong>Your login credentials:</strong></p>
            <p>Email: ${email}</p>
            <p>Temporary Password: <code style="background: #e5e7eb; padding: 2px 4px; border-radius: 4px;">${tempPassword}</code></p>
          </div>
          <p>Please log in and change your password immediately.</p>
          <a href="${process.env.FRONTEND_URL || 'http://localhost:5173'}/login" 
             style="background: #2563eb; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block; margin: 20px 0;">
            Login to LiveChatM
          </a>
          <p style="color: #6b7280; font-size: 14px;">If you didn't expect this invitation, please ignore this email.</p>
        </div>
      `;

      await sendEmail(email, `Invitation to join ${organization.name} on LiveChatM`, inviteEmailHtml);

      res.json({ 
        message: 'Member invited successfully. Invitation email sent.',
        user: {
          id: newUser._id,
          name: newUser.name,
          email: newUser.email,
          role: newUser.role
        }
      });
    } catch (error) {
      console.error('Invite member error:', error);
      res.status(500).json({ message: 'Failed to invite member' });
    }
  },

  // Remove member
  removeMember: async (req, res) => {
    try {
      const { userId } = req.params;
      
      // Don't allow removing self
      if (userId === req.user._id.toString()) {
        return res.status(400).json({ message: 'Cannot remove yourself' });
      }

      await User.findByIdAndUpdate(userId, { isActive: false });

      res.json({ message: 'Member removed successfully' });
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Leave organization (for invited users)
  leaveOrganization: async (req, res) => {
    try {
      // Only agents can leave, not owners
      if (req.user.role === 'owner') {
        return res.status(400).json({ message: 'Organization owners cannot leave' });
      }

      await User.findByIdAndUpdate(req.user._id, { isActive: false });

      res.json({ message: 'Successfully left the organization' });
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  }
};

module.exports = organizationController;
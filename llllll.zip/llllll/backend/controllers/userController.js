const User = require('../models/User');
const bcrypt = require('bcryptjs');

const userController = {
  // Get all users in organization
  getUsers: async (req, res) => {
    try {
      const users = await User.find({ 
        organizationId: req.user.organizationId._id,
        isActive: true 
      }).select('-password -refreshToken').sort({ createdAt: -1 });

      res.json({ users });
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Get user profile
  getProfile: async (req, res) => {
    try {
      const user = await User.findById(req.user._id)
        .populate('organizationId')
        .select('-password -refreshToken');

      res.json({ user });
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Update user profile
  updateProfile: async (req, res) => {
    try {
      const { name, email, phone, settings } = req.body;
      
      const updateData = {};
      if (name) updateData.name = name;
      if (email) updateData.email = email;
      if (phone) updateData.phone = phone;
      if (settings) updateData.settings = { ...req.user.settings, ...settings };

      const user = await User.findByIdAndUpdate(
        req.user._id,
        updateData,
        { new: true }
      ).select('-password -refreshToken');

      res.json({
        message: 'Profile updated successfully',
        user
      });
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Upload avatar
  uploadAvatar: async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: 'No file uploaded' });
      }

      // In production, upload to Cloudinary
      const avatarUrl = `/uploads/avatars/${req.file.filename}`;
      
      const user = await User.findByIdAndUpdate(
        req.user._id,
        { avatar: avatarUrl },
        { new: true }
      ).select('-password -refreshToken');

      res.json({
        message: 'Avatar updated successfully',
        avatar: avatarUrl,
        user
      });
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Create new user (admin only)
  createUser: async (req, res) => {
    try {
      const { name, email, role = 'agent' } = req.body;
      
      const existingUser = await User.findOne({ email });
      if (existingUser) {
        return res.status(400).json({ message: 'User already exists' });
      }

      const tempPassword = Math.random().toString(36).slice(-8);
      const user = new User({
        name,
        email,
        password: tempPassword,
        role,
        organizationId: req.user.organizationId._id
      });

      await user.save();

      res.status(201).json({ 
        message: 'User created successfully',
        tempPassword
      });
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Update user (admin only)
  updateUser: async (req, res) => {
    try {
      const { name, email, role, isActive } = req.body;
      
      const user = await User.findByIdAndUpdate(
        req.params.id,
        { name, email, role, isActive },
        { new: true }
      ).select('-password -refreshToken');

      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }

      res.json({
        message: 'User updated successfully',
        user
      });
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Delete user (admin only)
  deleteUser: async (req, res) => {
    try {
      await User.findByIdAndUpdate(
        req.params.id,
        { isActive: false }
      );

      res.json({ message: 'User deleted successfully' });
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Get online agents
  getOnlineAgents: async (req, res) => {
    try {
      const agents = await User.find({ 
        organizationId: req.user.organizationId._id,
        isActive: true,
        isOnline: true
      }).select('-password -refreshToken');

      res.json({ agents });
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Change password
  changePassword: async (req, res) => {
    try {
      const { currentPassword, newPassword } = req.body;
      
      const user = await User.findById(req.user._id);
      
      // Check current password
      const isMatch = await user.comparePassword(currentPassword);
      if (!isMatch) {
        return res.status(400).json({ message: 'Current password is incorrect' });
      }

      // Update password
      user.password = newPassword;
      await user.save();

      res.json({ message: 'Password changed successfully' });
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Update user settings
  updateSettings: async (req, res) => {
    try {
      const { settings } = req.body;
      
      const user = await User.findByIdAndUpdate(
        req.user._id,
        { settings: { ...req.user.settings, ...settings } },
        { new: true }
      ).select('-password -refreshToken');

      res.json({
        message: 'Settings updated successfully',
        settings: user.settings
      });
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  }
};

module.exports = userController;
const Message = require('../models/Message');
const Conversation = require('../models/Conversation');
const { uploadFile, deleteFile } = require('../config/cloudinary');

const fileController = {
  // Upload file for conversation
  uploadFile: async (req, res) => {
    try {
      const { conversationId } = req.body;

      if (!req.file) {
        return res.status(400).json({ message: 'No file uploaded' });
      }

      const conversation = await Conversation.findOne({
        _id: conversationId,
        organizationId: req.user.organizationId._id
      });

      if (!conversation) {
        return res.status(404).json({ message: 'Conversation not found' });
      }

      const result = await uploadFile(req.file, 'chat-files');
      
      const message = new Message({
        conversationId,
        sender: {
          type: 'agent',
          id: req.user._id.toString(),
          name: req.user.name,
          avatar: req.user.avatar
        },
        content: `Shared a file: ${req.file.originalname}`,
        messageType: req.file.mimetype.startsWith('image/') ? 'image' : 'file',
        file: {
          url: result.secure_url,
          name: req.file.originalname,
          size: req.file.size,
          type: req.file.mimetype,
          publicId: result.public_id
        },
        metadata: {
          ip: req.ip,
          userAgent: req.get('User-Agent')
        }
      });

      await message.save();

      await Conversation.findByIdAndUpdate(conversationId, {
        $inc: { 'metadata.totalMessages': 1 },
        updatedAt: new Date()
      });

      res.status(201).json({
        message: 'File uploaded successfully',
        data: message
      });
    } catch (error) {
      console.error('File upload error:', error);
      res.status(500).json({ message: 'File upload failed' });
    }
  },

  // Upload file from visitor
  uploadVisitorFile: async (req, res) => {
    try {
      const { conversationId, visitorId, visitorInfo } = req.body;

      if (!req.file) {
        return res.status(400).json({ message: 'No file uploaded' });
      }

      const conversation = await Conversation.findOne({
        _id: conversationId,
        visitorId
      });

      if (!conversation) {
        return res.status(404).json({ message: 'Conversation not found' });
      }

      const result = await uploadFile(req.file, 'visitor-files');
      
      const message = new Message({
        conversationId,
        sender: {
          type: 'visitor',
          id: visitorId,
          name: visitorInfo?.name || 'Visitor',
          avatar: visitorInfo?.avatar
        },
        content: `Shared a file: ${req.file.originalname}`,
        messageType: req.file.mimetype.startsWith('image/') ? 'image' : 'file',
        file: {
          url: result.secure_url,
          name: req.file.originalname,
          size: req.file.size,
          type: req.file.mimetype,
          publicId: result.public_id
        },
        metadata: {
          ip: req.ip,
          userAgent: req.get('User-Agent')
        }
      });

      await message.save();

      await Conversation.findByIdAndUpdate(conversationId, {
        $inc: { 'metadata.totalMessages': 1 },
        updatedAt: new Date()
      });

      res.status(201).json({
        message: 'File uploaded successfully',
        data: message
      });
    } catch (error) {
      console.error('Visitor file upload error:', error);
      res.status(500).json({ message: 'File upload failed' });
    }
  },

  // Get file by message ID
  getFile: async (req, res) => {
    try {
      const { messageId } = req.params;

      const message = await Message.findById(messageId);
      if (!message || !message.file) {
        return res.status(404).json({ message: 'File not found' });
      }

      const conversation = await Conversation.findOne({
        _id: message.conversationId,
        organizationId: req.user.organizationId._id
      });

      if (!conversation) {
        return res.status(403).json({ message: 'Access denied' });
      }

      res.json({
        file: message.file,
        message: {
          id: message._id,
          content: message.content,
          sender: message.sender,
          createdAt: message.createdAt
        }
      });
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Delete file
  deleteFile: async (req, res) => {
    try {
      const { messageId } = req.params;

      const message = await Message.findById(messageId);
      if (!message || !message.file) {
        return res.status(404).json({ message: 'File not found' });
      }

      const conversation = await Conversation.findOne({
        _id: message.conversationId,
        organizationId: req.user.organizationId._id
      });

      if (!conversation) {
        return res.status(403).json({ message: 'Access denied' });
      }

      if (message.sender.id !== req.user._id.toString() && 
          req.user.role !== 'admin' && req.user.role !== 'owner') {
        return res.status(403).json({ message: 'Not authorized to delete this file' });
      }

      if (message.file.publicId) {
        await deleteFile(message.file.publicId);
      }

      await Message.findByIdAndUpdate(messageId, {
        content: '[File deleted]',
        file: null,
        isDeleted: true,
        updatedAt: new Date()
      });

      res.json({ message: 'File deleted successfully' });
    } catch (error) {
      console.error('File deletion error:', error);
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Get file usage statistics
  getUsageStats: async (req, res) => {
    try {
      const organizationId = req.user.organizationId._id;

      const conversations = await Conversation.find({ organizationId }).distinct('_id');

      const fileStats = await Message.aggregate([
        {
          $match: {
            conversationId: { $in: conversations },
            file: { $exists: true },
            isDeleted: false
          }
        },
        {
          $group: {
            _id: null,
            totalFiles: { $sum: 1 },
            totalSize: { $sum: '$file.size' },
            imageFiles: {
              $sum: { $cond: [{ $eq: ['$messageType', 'image'] }, 1, 0] }
            },
            documentFiles: {
              $sum: { $cond: [{ $eq: ['$messageType', 'file'] }, 1, 0] }
            }
          }
        }
      ]);

      const stats = fileStats[0] || {
        totalFiles: 0,
        totalSize: 0,
        imageFiles: 0,
        documentFiles: 0
      };

      const organization = await req.user.organizationId;
      const storageLimit = organization.limits.fileStorage * 1024 * 1024;

      res.json({
        usage: {
          totalFiles: stats.totalFiles,
          totalSize: stats.totalSize,
          totalSizeMB: Math.round(stats.totalSize / (1024 * 1024) * 100) / 100,
          imageFiles: stats.imageFiles,
          documentFiles: stats.documentFiles
        },
        limits: {
          storageLimitMB: organization.limits.fileStorage,
          storageUsedPercent: Math.round((stats.totalSize / storageLimit) * 100)
        }
      });
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Get recent files
  getRecentFiles: async (req, res) => {
    try {
      const { limit = 20 } = req.query;
      const organizationId = req.user.organizationId._id;

      const conversations = await Conversation.find({ organizationId }).distinct('_id');

      const recentFiles = await Message.find({
        conversationId: { $in: conversations },
        file: { $exists: true },
        isDeleted: false
      })
      .sort({ createdAt: -1 })
      .limit(parseInt(limit))
      .populate('conversationId', 'visitor.name')
      .select('file sender createdAt conversationId');

      res.json({ files: recentFiles });
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  }
};

module.exports = fileController;
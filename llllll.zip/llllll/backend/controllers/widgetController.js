const Widget = require('../models/Widget');
const Organization = require('../models/Organization');
const Conversation = require('../models/Conversation');

const widgetController = {
  // Get all widgets for organization
  getWidgets: async (req, res) => {
    try {
      const widgets = await Widget.find({ 
        organizationId: req.user.organizationId._id,
        isActive: true 
      }).sort({ createdAt: -1 });

      res.json({ widgets });
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Get widget by ID
  getWidget: async (req, res) => {
    try {
      const widget = await Widget.findOne({
        _id: req.params.id,
        organizationId: req.user.organizationId._id
      });

      if (!widget) {
        return res.status(404).json({ message: 'Widget not found' });
      }

      res.json({ widget });
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Create new widget
  createWidget: async (req, res) => {
    try {
      const { name, config, allowedDomains } = req.body;

      const organization = await Organization.findById(req.user.organizationId._id);

      const widget = new Widget({
        organizationId: req.user.organizationId._id,
        name,
        widgetId: `widget_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        config: {
          ...config,
          companyName: config.companyName || organization.name
        },
        allowedDomains: ['*'] // Allow all domains
      });

      await widget.save();

      res.status(201).json({ 
        message: 'Widget created successfully',
        widget 
      });
    } catch (error) {
      console.error('Widget creation error:', error);
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Update widget
  updateWidget: async (req, res) => {
    try {
      const { name, config, allowedDomains } = req.body;

      const widget = await Widget.findOneAndUpdate(
        {
          _id: req.params.id,
          organizationId: req.user.organizationId._id
        },
        {
          name,
          config,
          allowedDomains,
          updatedAt: new Date()
        },
        { new: true }
      );

      if (!widget) {
        return res.status(404).json({ message: 'Widget not found' });
      }

      res.json({ 
        message: 'Widget updated successfully',
        widget 
      });
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Delete widget
  deleteWidget: async (req, res) => {
    try {
      const widget = await Widget.findOneAndUpdate(
        {
          _id: req.params.id,
          organizationId: req.user.organizationId._id
        },
        { isActive: false },
        { new: true }
      );

      if (!widget) {
        return res.status(404).json({ message: 'Widget not found' });
      }

      res.json({ message: 'Widget deleted successfully' });
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Get widget embed code
  getEmbedCode: async (req, res) => {
    try {
      const widget = await Widget.findOne({
        _id: req.params.id,
        organizationId: req.user.organizationId._id
      });

      if (!widget) {
        return res.status(404).json({ message: 'Widget not found' });
      }

      const embedCode = `<!-- LiveChatM Widget -->
<script>
  window.LiveChatMConfig = {
    widgetId: "${widget.widgetId}",
    organizationId: "${widget.organizationId}",
    config: ${JSON.stringify(widget.config, null, 2)}
  };
  (function() {
    var script = document.createElement('script');
    script.src = '${process.env.WIDGET_CDN_URL}/widget.min.js';
    script.async = true;
    script.onload = function() {
      if (typeof LiveChatM !== 'undefined') {
        LiveChatM.init(window.LiveChatMConfig);
      }
    };
    document.head.appendChild(script);
  })();
</script>`;

      res.json({ embedCode });
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Get widget statistics
  getWidgetStats: async (req, res) => {
    try {
      const widget = await Widget.findOne({
        _id: req.params.id,
        organizationId: req.user.organizationId._id
      });

      if (!widget) {
        return res.status(404).json({ message: 'Widget not found' });
      }

      // Get conversation count for this widget
      const totalConversations = await Conversation.countDocuments({ 
        widgetId: widget.widgetId 
      });

      const activeConversations = await Conversation.countDocuments({ 
        widgetId: widget.widgetId,
        status: 'active'
      });

      res.json({
        stats: {
          ...widget.stats,
          totalConversations,
          activeConversations,
          conversionRate: widget.stats.totalViews > 0 
            ? ((totalConversations / widget.stats.totalViews) * 100).toFixed(2)
            : 0
        }
      });
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  }
};

module.exports = widgetController;
const Conversation = require('../models/Conversation');
const Message = require('../models/Message');
const User = require('../models/User');

const conversationController = {
  // Get all conversations for organization
  getConversations: async (req, res) => {
    try {
      const { status, page = 1, limit = 50, search } = req.query;
      const skip = (page - 1) * limit;

      let query = { organizationId: req.user.organizationId._id };

      if (status && status !== 'all') {
        query.status = status;
      }

      if (search) {
        query.$or = [
          { 'visitor.name': { $regex: search, $options: 'i' } },
          { 'visitor.email': { $regex: search, $options: 'i' } },
          { tags: { $in: [new RegExp(search, 'i')] } }
        ];
      }

      const conversations = await Conversation.find(query)
        .populate('assignedAgent', 'name avatar')
        .sort({ updatedAt: -1 })
        .skip(skip)
        .limit(parseInt(limit));

      // Add lastMessage content and unread count with unique visitor names
      const conversationsWithMessages = await Promise.all(
        conversations.map(async (conv, index) => {
          const lastMessage = await Message.findOne({
            conversationId: conv._id
          }).sort({ createdAt: -1 });

          const unreadCount = await Message.countDocuments({
            conversationId: conv._id,
            'sender.type': 'visitor',
            isRead: false
          });

          // Generate unique visitor name
          const visitorName = `Visitor #${index + 1}`;

          return {
            ...conv.toObject(),
            visitor: {
              ...conv.visitor,
              name: visitorName
            },
            lastMessage: lastMessage ? {
              content: lastMessage.content,
              timestamp: lastMessage.createdAt,
              status: lastMessage.isRead ? 'read' : 'delivered'
            } : null,
            unreadCount
          };
        })
      );

      const total = await Conversation.countDocuments(query);

      res.json({
        conversations: conversationsWithMessages,
        pagination: {
          current: parseInt(page),
          pages: Math.ceil(total / limit),
          total
        }
      });
    } catch (error) {
      console.error('Get conversations error:', error);
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Get conversation by ID with messages
  getConversation: async (req, res) => {
    try {
      const conversation = await Conversation.findOne({
        _id: req.params.id,
        organizationId: req.user.organizationId._id
      }).populate('assignedAgent', 'name avatar email');

      if (!conversation) {
        return res.status(404).json({ message: 'Conversation not found' });
      }

      // Generate visitor name
      const visitorName = `Visitor #${Math.floor(Math.random() * 1000) + 1}`;

      // Get messages for this conversation with status
      const messages = await Message.find({
        conversationId: conversation._id,
        isDeleted: { $ne: true }
      }).sort({ createdAt: 1 });

      // Mark visitor messages as read
      await Message.updateMany(
        {
          conversationId: conversation._id,
          'sender.type': 'visitor',
          isRead: false
        },
        {
          isRead: true,
          readAt: new Date()
        }
      );

      // Add message status
      const messagesWithStatus = messages.map(msg => ({
        ...msg.toObject(),
        status: msg.isRead ? 'read' : 'delivered'
      }));

      res.json({
        conversation: {
          ...conversation.toObject(),
          visitor: {
            ...conversation.visitor,
            name: visitorName
          }
        },
        messages: messagesWithStatus
      });
    } catch (error) {
      console.error('Get conversation error:', error);
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Update conversation status
  updateStatus: async (req, res) => {
    try {
      console.log('Update status request:', req.params.id, req.body);
      const { status, reason } = req.body;
      
      if (!['active', 'waiting', 'closed', 'archived'].includes(status)) {
        return res.status(400).json({ message: 'Invalid status' });
      }

      const updateData = {
        status,
        updatedAt: new Date()
      };

      if (status === 'closed') {
        updateData.closedAt = new Date();
        updateData.closedBy = req.user._id;
        if (reason) updateData.closeReason = reason;
      }

      const conversation = await Conversation.findOneAndUpdate(
        {
          _id: req.params.id,
          organizationId: req.user.organizationId._id
        },
        updateData,
        { new: true }
      );

      if (!conversation) {
        return res.status(404).json({ message: 'Conversation not found' });
      }

      console.log('Status updated successfully:', conversation._id, status);

      // Emit real-time update
      const io = req.app.get('io');
      if (io) {
        io.to(`org_${req.user.organizationId._id}`).emit('conversation_status_changed', {
          conversationId: conversation._id,
          status,
          updatedBy: req.user.name,
          timestamp: new Date()
        });
      }

      res.json({
        message: `Conversation ${status} successfully`,
        conversation
      });
    } catch (error) {
      console.error('Update status error:', error);
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Assign conversation to agent
  assignConversation: async (req, res) => {
    try {
      const { agentId } = req.body;

      // Verify agent belongs to same organization
      const agent = await User.findOne({
        _id: agentId,
        organizationId: req.user.organizationId._id,
        isActive: true
      });

      if (!agent) {
        return res.status(400).json({ message: 'Invalid agent' });
      }

      const conversation = await Conversation.findOneAndUpdate(
        {
          _id: req.params.id,
          organizationId: req.user.organizationId._id
        },
        {
          assignedAgent: agentId,
          status: 'active',
          updatedAt: new Date()
        },
        { new: true }
      ).populate('assignedAgent', 'name avatar');

      if (!conversation) {
        return res.status(404).json({ message: 'Conversation not found' });
      }

      // Create system message
      const systemMessage = new Message({
        conversationId: conversation._id,
        sender: {
          type: 'system',
          name: 'System'
        },
        content: `Conversation assigned to ${agent.name}`,
        messageType: 'system'
      });
      await systemMessage.save();

      res.json({
        message: 'Conversation assigned successfully',
        conversation
      });
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Add tags to conversation
  updateTags: async (req, res) => {
    try {
      const { tags } = req.body;

      const conversation = await Conversation.findOneAndUpdate(
        {
          _id: req.params.id,
          organizationId: req.user.organizationId._id
        },
        {
          tags: Array.isArray(tags) ? tags : [tags],
          updatedAt: new Date()
        },
        { new: true }
      );

      if (!conversation) {
        return res.status(404).json({ message: 'Conversation not found' });
      }

      res.json({
        message: 'Tags updated successfully',
        conversation
      });
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Rate conversation
  rateConversation: async (req, res) => {
    try {
      const { score, comment, visitorId } = req.body;

      // Verify this is the correct visitor
      const conversation = await Conversation.findOne({
        _id: req.params.id,
        visitorId
      });

      if (!conversation) {
        return res.status(404).json({ message: 'Conversation not found' });
      }

      if (conversation.rating && conversation.rating.score) {
        return res.status(400).json({ message: 'Conversation already rated' });
      }

      await Conversation.findByIdAndUpdate(req.params.id, {
        rating: {
          score: parseInt(score),
          comment,
          ratedAt: new Date()
        },
        updatedAt: new Date()
      });

      res.json({ message: 'Rating submitted successfully' });
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Get conversation statistics
  getStats: async (req, res) => {
    try {
      const organizationId = req.user.organizationId._id;

      const stats = await Conversation.aggregate([
        { $match: { organizationId } },
        {
          $group: {
            _id: '$status',
            count: { $sum: 1 },
            avgDuration: { $avg: '$metadata.duration' },
            avgRating: { $avg: '$rating.score' }
          }
        }
      ]);

      const totalConversations = await Conversation.countDocuments({ organizationId });
      const todayConversations = await Conversation.countDocuments({
        organizationId,
        createdAt: { $gte: new Date().setHours(0, 0, 0, 0) }
      });

      res.json({
        totalConversations,
        todayConversations,
        statusBreakdown: stats,
        avgRating: stats.reduce((acc, stat) => acc + (stat.avgRating || 0), 0) / stats.length || 0
      });
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Send message in conversation
  sendMessage: async (req, res) => {
    try {
      const { content, sender = 'agent' } = req.body;
      const conversationId = req.params.id;

      // Verify conversation belongs to organization
      const conversation = await Conversation.findOne({
        _id: conversationId,
        organizationId: req.user.organizationId._id
      });

      if (!conversation) {
        return res.status(404).json({ message: 'Conversation not found' });
      }

      // Create message
      const message = new Message({
        conversationId,
        sender: {
          type: sender,
          id: req.user._id,
          name: req.user.name
        },
        content,
        messageType: 'text'
      });
      await message.save();

      // Update conversation
      conversation.lastMessage = {
        content,
        timestamp: new Date()
      };
      conversation.updatedAt = new Date();
      if (conversation.status === 'waiting') {
        conversation.status = 'active';
        conversation.assignedAgent = req.user._id;
      }
      await conversation.save();

      // Emit to socket for real-time updates
      const io = req.app.get('io');
      if (io) {
        // Emit to conversation room
        io.to(`conversation_${conversationId}`).emit('new_message', {
          _id: message._id,
          conversationId,
          content,
          sender: {
            type: sender,
            id: req.user._id,
            name: req.user.name
          },
          createdAt: message.createdAt,
          status: 'sent'
        });

        // Emit to organization room for dashboard updates
        io.to(`org_${req.user.organizationId._id}`).emit('conversation_updated', {
          conversationId,
          lastMessage: { content, timestamp: new Date() },
          updatedAt: new Date()
        });
      }

      res.json({
        message: message,
        conversation
      });
    } catch (error) {
      console.error('Send message error:', error);
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Get conversation for widget (no auth required)
  getConversationPublic: async (req, res) => {
    try {
      const conversation = await Conversation.findById(req.params.id);
      if (!conversation) {
        return res.status(404).json({ message: 'Conversation not found' });
      }

      const messages = await Message.find({
        conversationId: conversation._id,
        isDeleted: { $ne: true }
      }).sort({ createdAt: 1 });

      res.json({ conversation, messages });
    } catch (error) {
      console.error('Get public conversation error:', error);
      res.status(500).json({ message: 'Server error' });
    }
  },

  // Handle widget message (no auth required)
  handleWidgetMessage: async (req, res) => {
    try {
      const { organizationId, widgetId, message, visitorInfo, visitorId } = req.body;

      if (!organizationId || !message || !visitorId) {
        return res.status(400).json({ message: 'Missing required fields' });
      }

      console.log('Received widget message:', { organizationId, widgetId, message, visitorId });

      // Find existing conversation by visitorId
      let conversation = await Conversation.findOne({
        organizationId,
        visitorId,
        status: { $in: ['waiting', 'active'] }
      });

      console.log('Found existing conversation:', conversation ? conversation._id : 'none');

      if (!conversation) {
        conversation = new Conversation({
          organizationId,
          widgetId: widgetId || 'default',
          visitorId,
          visitor: {
            name: visitorInfo?.name || 'Anonymous Visitor',
            email: visitorInfo?.email || null,
            location: {
              ip: req.ip || req.connection?.remoteAddress || 'unknown'
            },
            page: {
              url: visitorInfo?.url || 'unknown',
              title: visitorInfo?.title || 'unknown',
              referrer: visitorInfo?.referrer || 'unknown'
            },
            browser: {
              name: visitorInfo?.browser || 'unknown',
              os: visitorInfo?.os || 'unknown'
            }
          },
          status: 'waiting',
          metadata: {
            totalMessages: 0
          }
        });
        await conversation.save();
        console.log('Created new conversation:', conversation._id);
      }

      // Create message
      const newMessage = new Message({
        conversationId: conversation._id,
        sender: {
          type: 'visitor',
          name: 'Visitor'
        },
        content: message,
        messageType: 'text'
      });
      await newMessage.save();

      // Update conversation metadata
      conversation.lastMessage = {
        content: message,
        timestamp: new Date()
      };
      conversation.metadata = conversation.metadata || {};
      conversation.metadata.totalMessages = (conversation.metadata.totalMessages || 0) + 1;
      conversation.updatedAt = new Date();
      await conversation.save();

      // Emit to socket for real-time updates
      const io = req.app.get('io');
      if (io) {
        console.log('Emitting widget message to dashboard, org:', organizationId);

        const messageData = {
          _id: newMessage._id,
          conversationId: conversation._id,
          content: message,
          sender: {
            type: 'visitor',
            name: 'Visitor'
          },
          createdAt: newMessage.createdAt,
          status: 'delivered'
        };

        // Emit to conversation room (for open chat window)
        io.to(`conversation_${conversation._id}`).emit('new_message', messageData);

        // Emit to organization room (for chat list updates)
        // We emit both conversation_updated and new_message to ensure all listeners catch it
        io.to(`org_${organizationId}`).emit('new_message', messageData);
        io.to(`org_${organizationId}`).emit('conversation_updated', {
          conversationId: conversation._id,
          lastMessage: {
            content: message,
            timestamp: new Date()
          },
          unreadCount: 1, // Increment unread count logic handled by frontend or full fetch
          updatedAt: new Date()
        });
      }

      // Test broadcast
      if (io) {
        io.emit('test', { message: 'Test from widget message' });
      }

      res.json({
        success: true,
        conversationId: conversation._id,
        messageId: newMessage._id,
        visitorId: conversation.visitorId
      });
    } catch (error) {
      console.error('Widget message error:', error);
      res.status(500).json({ message: 'Server error' });
    }
  }
};

module.exports = conversationController;
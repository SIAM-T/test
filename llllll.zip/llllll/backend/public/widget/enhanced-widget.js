/**
 * LiveChatM Enhanced Widget v2.1.0
 * Advanced Chat Widget with Offline Support & Better Error Handling
 */
(function() {
  'use strict';

  // Widget state management
  class WidgetState {
    constructor() {
      this.config = window.LiveChatMConfig || {};
      this.socket = null;
      this.isConnected = false;
      this.isOnline = navigator.onLine;
      this.visitorId = null;
      this.conversationId = null;
      this.isMinimized = true;
      this.messageQueue = [];
      this.retryAttempts = 0;
      this.maxRetries = 5;
      this.reconnectDelay = 1000;
      
      this.initializeConfig();
      this.setupOfflineHandling();
    }

    initializeConfig() {
      const defaultConfig = {
        widgetId: '',
        organizationId: '',
        config: {
          primaryColor: '#3B82F6',
          secondaryColor: '#F8FAFC',
          accentColor: '#10B981',
          textColor: '#1F2937',
          theme: 'light',
          borderRadius: 16,
          position: 'bottom-right',
          size: 'medium',
          margin: 20,
          zIndex: 9999,
          animation: 'bounce',
          autoOpen: false,
          openDelay: 3000,
          soundEnabled: true,
          companyName: 'Support',
          greeting: 'Hi! How can I help you today?',
          placeholder: 'Type your message...',
          showAvatar: true,
          showOnline: true,
          showTyping: true,
          fileUpload: true,
          emojiPicker: false,
          offlineMessage: 'We are currently offline. Your message will be sent when we are back online.'
        }
      };

      this.config = Object.assign({}, defaultConfig, this.config);
    }

    setupOfflineHandling() {
      window.addEventListener('online', () => {
        this.isOnline = true;
        this.updateConnectionStatus();
        this.processMessageQueue();
      });

      window.addEventListener('offline', () => {
        this.isOnline = false;
        this.updateConnectionStatus();
      });
    }

    updateConnectionStatus() {
      const statusEl = document.querySelector('.livechatm-status');
      const onlineIndicator = document.querySelector('.livechatm-online-indicator');
      
      if (statusEl) {
        statusEl.textContent = this.isOnline && this.isConnected ? 'Online' : 'Offline';
      }
      
      if (onlineIndicator) {
        onlineIndicator.style.background = this.isOnline && this.isConnected ? '#10b981' : '#ef4444';
      }
    }

    queueMessage(message) {
      this.messageQueue.push({
        ...message,
        timestamp: Date.now(),
        id: 'queued_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9)
      });
      
      // Limit queue size
      if (this.messageQueue.length > 50) {
        this.messageQueue = this.messageQueue.slice(-50);
      }
      
      this.saveToLocalStorage();
    }

    async processMessageQueue() {
      if (!this.isOnline || !this.isConnected || this.messageQueue.length === 0) {
        return;
      }

      const queue = [...this.messageQueue];
      this.messageQueue = [];
      
      for (const message of queue) {
        try {
          await this.sendQueuedMessage(message);
        } catch (error) {
          console.error('Failed to send queued message:', error);
          // Re-queue failed messages
          this.messageQueue.push(message);
        }
      }
      
      this.saveToLocalStorage();
    }

    async sendQueuedMessage(message) {
      if (message.type === 'text') {
        await this.sendMessage(message.content, false); // Don't queue again
      }
    }

    saveToLocalStorage() {
      try {
        localStorage.setItem('livechatm_message_queue', JSON.stringify(this.messageQueue));
      } catch (error) {
        console.warn('Could not save message queue to localStorage');
      }
    }

    loadFromLocalStorage() {
      try {
        const saved = localStorage.getItem('livechatm_message_queue');
        if (saved) {
          this.messageQueue = JSON.parse(saved);
        }
      } catch (error) {
        console.warn('Could not load message queue from localStorage');
        this.messageQueue = [];
      }
    }
  }

  // Enhanced Widget class
  class EnhancedWidget {
    constructor() {
      this.state = new WidgetState();
      this.messageDeduplication = new Set();
      this.typingTimeout = null;
      this.heartbeatInterval = null;
      this.reconnectTimeout = null;
      
      this.init();
    }

    async init() {
      if (!this.state.config.widgetId || !this.state.config.organizationId) {
        console.error('LiveChatM: Widget ID and Organization ID are required');
        return;
      }

      this.state.visitorId = this.getVisitorId();
      this.state.loadFromLocalStorage();

      try {
        await this.loadWidgetConfig();
        this.createWidget();
        this.setupEventListeners();
        this.connectSocket();
        this.trackVisitor();
        this.setupAutoOpen();
      } catch (error) {
        console.error('Widget initialization failed:', error);
        this.showError('Failed to initialize chat widget');
      }
    }

    getVisitorId() {
      let id = localStorage.getItem('livechatm_visitor_id');
      if (!id) {
        id = 'visitor_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
        localStorage.setItem('livechatm_visitor_id', id);
      }
      return id;
    }

    async loadWidgetConfig() {
      try {
        const response = await fetch(`/api/embed/config/${this.state.config.widgetId}`);
        if (response.ok) {
          const data = await response.json();
          this.state.config = Object.assign({}, this.state.config, data);
        }
      } catch (error) {
        console.warn('Could not load widget configuration:', error);
      }
    }

    createWidget() {
      // Add CSS
      const style = document.createElement('style');
      style.textContent = this.generateCSS();
      document.head.appendChild(style);

      // Add HTML
      const widgetContainer = document.createElement('div');
      widgetContainer.innerHTML = this.generateHTML();
      document.body.appendChild(widgetContainer.firstElementChild);

      // Show widget
      document.getElementById('livechatm-widget').style.display = 'block';
    }

    generateHTML() {
      return `
        <div id="livechatm-widget" class="livechatm-widget" style="display: none;">
          <!-- Widget Button -->
          <div id="livechatm-button" class="livechatm-button">
            <div class="livechatm-button-icon">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
              </svg>
            </div>
            <div class="livechatm-button-close" style="display: none;">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <line x1="18" y1="6" x2="6" y2="18"></line>
                <line x1="6" y1="6" x2="18" y2="18"></line>
              </svg>
            </div>
            <div class="livechatm-notification-badge" style="display: none;">1</div>
            <div class="livechatm-offline-indicator" style="display: none;" title="Offline">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <line x1="1" y1="1" x2="23" y2="23"></line>
                <path d="M16.72 11.06A10.94 10.94 0 0 1 19 12.55"></path>
                <path d="M5 12.55a10.94 10.94 0 0 1 5.17-2.39"></path>
                <path d="M10.71 5.05A16 16 0 0 1 22.58 9"></path>
                <path d="M1.42 9a15.91 15.91 0 0 1 4.7-2.88"></path>
                <path d="M8.53 16.11a6 6 0 0 1 6.95 0"></path>
                <line x1="12" y1="20" x2="12.01" y2="20"></line>
              </svg>
            </div>
          </div>

          <!-- Chat Window -->
          <div id="livechatm-window" class="livechatm-window" style="display: none;">
            <!-- Header -->
            <div class="livechatm-header">
              <div class="livechatm-header-info">
                <div class="livechatm-avatar">
                  <div class="livechatm-avatar-img"></div>
                  <div class="livechatm-online-indicator"></div>
                </div>
                <div class="livechatm-header-text">
                  <div class="livechatm-company-name">${this.state.config.config.companyName}</div>
                  <div class="livechatm-status">Connecting...</div>
                </div>
              </div>
              <div class="livechatm-header-actions">
                <button id="livechatm-minimize" class="livechatm-action-btn">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <line x1="5" y1="12" x2="19" y2="12"></line>
                  </svg>
                </button>
              </div>
            </div>

            <!-- Connection Status -->
            <div id="livechatm-connection-status" class="livechatm-connection-status" style="display: none;">
              <div class="livechatm-status-content">
                <div class="livechatm-status-icon">⚠️</div>
                <div class="livechatm-status-text">Connection lost. Trying to reconnect...</div>
              </div>
            </div>

            <!-- Messages -->
            <div id="livechatm-messages" class="livechatm-messages">
              <div class="livechatm-welcome-message">
                <div class="livechatm-message livechatm-message-agent">
                  <div class="livechatm-message-content">
                    <div class="livechatm-message-text">${this.state.config.config.greeting}</div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Typing Indicator -->
            <div id="livechatm-typing" class="livechatm-typing" style="display: none;">
              <div class="livechatm-typing-dots">
                <span></span><span></span><span></span>
              </div>
              <span class="livechatm-typing-text">Agent is typing...</span>
            </div>

            <!-- Input Area -->
            <div class="livechatm-input-area">
              <div class="livechatm-input-container">
                <textarea 
                  id="livechatm-input" 
                  class="livechatm-input" 
                  placeholder="${this.state.config.config.placeholder}"
                  rows="1"
                ></textarea>
                <div class="livechatm-input-actions">
                  ${this.state.config.config.fileUpload ? `
                    <button id="livechatm-file-btn" class="livechatm-file-btn" title="Attach file">
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66L9.64 16.2a2 2 0 0 1-2.83-2.83l8.49-8.49"></path>
                      </svg>
                    </button>
                  ` : ''}
                  <button id="livechatm-send-btn" class="livechatm-send-btn" disabled>
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                      <line x1="22" y1="2" x2="11" y2="13"></line>
                      <polygon points="22,2 15,22 11,13 2,9 22,2"></polygon>
                    </svg>
                  </button>
                </div>
              </div>
            </div>

            <!-- File Input -->
            <input type="file" id="livechatm-file-input" style="display: none;" accept="image/*,.pdf,.doc,.docx,.txt">
            
            <!-- Error Display -->
            <div id="livechatm-error" class="livechatm-error" style="display: none;">
              <div class="livechatm-error-content">
                <span class="livechatm-error-text"></span>
                <button class="livechatm-error-close">×</button>
              </div>
            </div>
          </div>
        </div>
      `;
    }

    generateCSS() {
      return `
        .livechatm-widget {
          position: fixed;
          ${this.state.config.config.position.includes('right') ? 'right' : 'left'}: ${this.state.config.config.margin}px;
          ${this.state.config.config.position.includes('bottom') ? 'bottom' : 'top'}: ${this.state.config.config.margin}px;
          z-index: ${this.state.config.config.zIndex};
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
          font-size: 14px;
          line-height: 1.4;
        }

        .livechatm-button {
          width: 60px;
          height: 60px;
          background: ${this.state.config.config.primaryColor};
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          box-shadow: 0 4px 12px rgba(0,0,0,0.15);
          transition: all 0.3s ease;
          position: relative;
          color: white;
        }

        .livechatm-button:hover {
          transform: scale(1.05);
          box-shadow: 0 6px 20px rgba(0,0,0,0.2);
        }

        .livechatm-offline-indicator {
          position: absolute;
          top: -2px;
          right: -2px;
          background: #ef4444;
          color: white;
          border-radius: 50%;
          width: 16px;
          height: 16px;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .livechatm-connection-status {
          background: #fef3c7;
          border-bottom: 1px solid #f59e0b;
          padding: 8px 16px;
          font-size: 12px;
        }

        .livechatm-status-content {
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .livechatm-error {
          position: absolute;
          bottom: 0;
          left: 0;
          right: 0;
          background: #fef2f2;
          border-top: 1px solid #fca5a5;
          padding: 12px 16px;
          font-size: 12px;
        }

        .livechatm-error-content {
          display: flex;
          align-items: center;
          justify-content: space-between;
          color: #dc2626;
        }

        .livechatm-error-close {
          background: none;
          border: none;
          color: #dc2626;
          cursor: pointer;
          font-size: 16px;
          padding: 0;
          margin-left: 8px;
        }

        .livechatm-message-queued {
          opacity: 0.7;
          position: relative;
        }

        .livechatm-message-queued::after {
          content: "⏳";
          position: absolute;
          right: -20px;
          top: 50%;
          transform: translateY(-50%);
          font-size: 12px;
        }

        /* Rest of the existing CSS... */
        .livechatm-window {
          width: 380px;
          height: 500px;
          background: white;
          border-radius: ${this.state.config.config.borderRadius}px;
          box-shadow: 0 10px 40px rgba(0,0,0,0.15);
          display: flex;
          flex-direction: column;
          overflow: hidden;
          margin-bottom: 20px;
          opacity: 0;
          transform: translateY(20px) scale(0.95);
          transition: all 0.3s ease;
        }

        .livechatm-window.show {
          opacity: 1;
          transform: translateY(0) scale(1);
        }

        /* Mobile responsive */
        @media (max-width: 480px) {
          .livechatm-window {
            width: calc(100vw - 40px);
            height: calc(100vh - 40px);
            max-height: 600px;
          }
        }
      `;
    }

    setupEventListeners() {
      const button = document.getElementById('livechatm-button');
      const minimizeBtn = document.getElementById('livechatm-minimize');
      const input = document.getElementById('livechatm-input');
      const sendBtn = document.getElementById('livechatm-send-btn');
      const fileBtn = document.getElementById('livechatm-file-btn');
      const fileInput = document.getElementById('livechatm-file-input');
      const errorClose = document.querySelector('.livechatm-error-close');

      button?.addEventListener('click', () => this.toggleWidget());
      minimizeBtn?.addEventListener('click', () => this.closeWidget());
      input?.addEventListener('input', (e) => this.handleInputChange(e));
      input?.addEventListener('keydown', (e) => this.handleKeyDown(e));
      sendBtn?.addEventListener('click', () => this.sendMessage());
      fileBtn?.addEventListener('click', () => fileInput?.click());
      fileInput?.addEventListener('change', (e) => this.handleFileUpload(e));
      errorClose?.addEventListener('click', () => this.hideError());
    }

    connectSocket() {
      if (typeof io === 'undefined') {
        this.loadSocketIO().then(() => this.connectSocket());
        return;
      }

      this.state.socket = io({
        auth: {
          userType: 'visitor',
          visitorId: this.state.visitorId,
          widgetId: this.state.config.widgetId
        },
        transports: ['websocket', 'polling'],
        timeout: 10000
      });

      this.setupSocketEvents();
    }

    setupSocketEvents() {
      const socket = this.state.socket;

      socket.on('connect', () => {
        console.log('Connected to server');
        this.state.isConnected = true;
        this.state.retryAttempts = 0;
        this.state.updateConnectionStatus();
        this.hideConnectionStatus();
        this.state.processMessageQueue();
        this.startHeartbeat();
      });

      socket.on('disconnect', (reason) => {
        console.log('Disconnected:', reason);
        this.state.isConnected = false;
        this.state.updateConnectionStatus();
        this.showConnectionStatus('Connection lost. Trying to reconnect...');
        this.stopHeartbeat();
        
        if (reason !== 'io client disconnect') {
          this.scheduleReconnect();
        }
      });

      socket.on('connect_error', (error) => {
        console.error('Connection error:', error);
        this.showConnectionStatus('Connection failed. Retrying...');
        this.scheduleReconnect();
      });

      socket.on('agent_message', (data) => {
        this.displayMessage(data.message);
        this.showNotification();
        this.playMessageSound();
      });

      socket.on('agent_typing', () => {
        this.showTypingIndicator();
      });

      socket.on('agent_typing_stop', () => {
        this.hideTypingIndicator();
      });
    }

    scheduleReconnect() {
      if (this.reconnectTimeout) {
        clearTimeout(this.reconnectTimeout);
      }

      if (this.state.retryAttempts >= this.state.maxRetries) {
        this.showError('Connection failed. Please refresh the page.');
        return;
      }

      const delay = Math.min(this.state.reconnectDelay * Math.pow(2, this.state.retryAttempts), 30000);
      this.state.retryAttempts++;

      this.reconnectTimeout = setTimeout(() => {
        if (this.state.socket) {
          this.state.socket.connect();
        }
      }, delay);
    }

    async sendMessage(content = null, shouldQueue = true) {
      const input = document.getElementById('livechatm-input');
      const message = content || input?.value?.trim();
      
      if (!message) return;

      // Display message immediately
      this.displayMessage({
        sender: { type: 'visitor', name: 'You' },
        content: message,
        createdAt: new Date(),
        isQueued: !this.state.isConnected || !this.state.isOnline
      });

      // Clear input
      if (input) {
        input.value = '';
        input.style.height = 'auto';
        document.getElementById('livechatm-send-btn').disabled = true;
      }

      // Handle offline or disconnected state
      if (!this.state.isOnline || !this.state.isConnected) {
        if (shouldQueue) {
          this.state.queueMessage({
            type: 'text',
            content: message
          });
          this.showError(this.state.config.config.offlineMessage);
        }
        return;
      }

      try {
        if (!this.state.conversationId) {
          await this.startConversation(message);
        } else {
          await this.sendMessageToServer(message);
        }
      } catch (error) {
        console.error('Failed to send message:', error);
        if (shouldQueue) {
          this.state.queueMessage({
            type: 'text',
            content: message
          });
        }
        this.showError('Failed to send message. It has been queued for retry.');
      }
    }

    async startConversation(initialMessage) {
      const response = await fetch('/api/embed/conversation', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          widgetId: this.state.config.widgetId,
          visitorId: this.state.visitorId,
          visitorInfo: { name: 'Visitor' },
          initialMessage
        })
      });

      if (response.ok) {
        const data = await response.json();
        this.state.conversationId = data.conversationId;
        
        if (this.state.socket) {
          this.state.socket.emit('join_conversation', { 
            conversationId: this.state.conversationId 
          });
        }
      } else {
        throw new Error('Failed to start conversation');
      }
    }

    async sendMessageToServer(message) {
      const response = await fetch('/api/embed/message', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          conversationId: this.state.conversationId,
          visitorId: this.state.visitorId,
          content: message,
          visitorInfo: { name: 'Visitor' }
        })
      });

      if (!response.ok) {
        throw new Error('Failed to send message to server');
      }
    }

    displayMessage(message) {
      const messagesContainer = document.getElementById('livechatm-messages');
      const messageEl = document.createElement('div');
      
      // Prevent duplicate messages
      const messageId = message._id || `${message.content}_${message.sender.type}_${Date.now()}`;
      if (this.messageDeduplication.has(messageId)) {
        return;
      }
      this.messageDeduplication.add(messageId);
      
      // Clean up old message IDs
      setTimeout(() => this.messageDeduplication.delete(messageId), 300000);
      
      messageEl.className = `livechatm-message livechatm-message-${message.sender.type}${message.isQueued ? ' livechatm-message-queued' : ''}`;
      messageEl.innerHTML = `
        <div class="livechatm-message-content">
          <div class="livechatm-message-text">${this.escapeHtml(message.content)}</div>
          <div class="livechatm-message-time">${this.formatTime(new Date(message.createdAt))}</div>
        </div>
      `;

      messagesContainer.appendChild(messageEl);
      messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }

    showError(message) {
      const errorEl = document.getElementById('livechatm-error');
      const errorText = document.querySelector('.livechatm-error-text');
      
      if (errorEl && errorText) {
        errorText.textContent = message;
        errorEl.style.display = 'block';
        
        // Auto-hide after 5 seconds
        setTimeout(() => this.hideError(), 5000);
      }
    }

    hideError() {
      const errorEl = document.getElementById('livechatm-error');
      if (errorEl) {
        errorEl.style.display = 'none';
      }
    }

    showConnectionStatus(message) {
      const statusEl = document.getElementById('livechatm-connection-status');
      const statusText = document.querySelector('.livechatm-status-text');
      
      if (statusEl && statusText) {
        statusText.textContent = message;
        statusEl.style.display = 'block';
      }
    }

    hideConnectionStatus() {
      const statusEl = document.getElementById('livechatm-connection-status');
      if (statusEl) {
        statusEl.style.display = 'none';
      }
    }

    // Utility methods
    escapeHtml(text) {
      const div = document.createElement('div');
      div.textContent = text;
      return div.innerHTML;
    }

    formatTime(date) {
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    }

    async loadSocketIO() {
      return new Promise((resolve, reject) => {
        const script = document.createElement('script');
        script.src = '/socket.io/socket.io.js';
        script.onload = resolve;
        script.onerror = reject;
        document.head.appendChild(script);
      });
    }

    startHeartbeat() {
      if (this.heartbeatInterval) {
        clearInterval(this.heartbeatInterval);
      }

      this.heartbeatInterval = setInterval(() => {
        if (this.state.socket && this.state.socket.connected) {
          this.state.socket.emit('heartbeat', { timestamp: Date.now() });
        }
      }, 30000);
    }

    stopHeartbeat() {
      if (this.heartbeatInterval) {
        clearInterval(this.heartbeatInterval);
        this.heartbeatInterval = null;
      }
    }

    // Widget interaction methods
    toggleWidget() {
      if (this.state.isMinimized) {
        this.openWidget();
      } else {
        this.closeWidget();
      }
    }

    openWidget() {
      const window = document.getElementById('livechatm-window');
      const button = document.getElementById('livechatm-button');
      const buttonIcon = button?.querySelector('.livechatm-button-icon');
      const buttonClose = button?.querySelector('.livechatm-button-close');

      if (window) {
        window.style.display = 'flex';
        setTimeout(() => window.classList.add('show'), 10);
      }
      
      if (buttonIcon) buttonIcon.style.display = 'none';
      if (buttonClose) buttonClose.style.display = 'block';
      
      this.state.isMinimized = false;
      this.hideNotification();

      // Focus input
      const input = document.getElementById('livechatm-input');
      if (input) input.focus();
    }

    closeWidget() {
      const window = document.getElementById('livechatm-window');
      const button = document.getElementById('livechatm-button');
      const buttonIcon = button?.querySelector('.livechatm-button-icon');
      const buttonClose = button?.querySelector('.livechatm-button-close');

      if (window) {
        window.classList.remove('show');
        setTimeout(() => window.style.display = 'none', 300);
      }
      
      if (buttonIcon) buttonIcon.style.display = 'block';
      if (buttonClose) buttonClose.style.display = 'none';
      
      this.state.isMinimized = true;
    }

    showNotification() {
      if (this.state.isMinimized) {
        const badge = document.querySelector('.livechatm-notification-badge');
        if (badge) badge.style.display = 'flex';
      }
    }

    hideNotification() {
      const badge = document.querySelector('.livechatm-notification-badge');
      if (badge) badge.style.display = 'none';
    }

    showTypingIndicator() {
      const typing = document.getElementById('livechatm-typing');
      if (typing) typing.style.display = 'flex';
    }

    hideTypingIndicator() {
      const typing = document.getElementById('livechatm-typing');
      if (typing) typing.style.display = 'none';
    }

    handleInputChange(e) {
      const sendBtn = document.getElementById('livechatm-send-btn');
      if (sendBtn) {
        sendBtn.disabled = !e.target.value.trim();
      }

      // Auto-resize textarea
      e.target.style.height = 'auto';
      e.target.style.height = e.target.scrollHeight + 'px';

      // Typing indicator
      if (this.state.socket && this.state.conversationId && this.state.isConnected) {
        this.state.socket.emit('typing_start', { 
          conversationId: this.state.conversationId 
        });

        clearTimeout(this.typingTimeout);
        this.typingTimeout = setTimeout(() => {
          if (this.state.socket && this.state.conversationId) {
            this.state.socket.emit('typing_stop', { 
              conversationId: this.state.conversationId 
            });
          }
        }, 1000);
      }
    }

    handleKeyDown(e) {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        this.sendMessage();
      }
    }

    async handleFileUpload(e) {
      const file = e.target.files[0];
      if (!file) return;

      // Validate file size (10MB limit)
      if (file.size > 10 * 1024 * 1024) {
        this.showError('File size must be less than 10MB');
        return;
      }

      if (!this.state.isOnline || !this.state.isConnected) {
        this.showError('Cannot upload files while offline');
        return;
      }

      try {
        const formData = new FormData();
        formData.append('file', file);
        formData.append('conversationId', this.state.conversationId);
        formData.append('visitorId', this.state.visitorId);
        formData.append('visitorInfo', JSON.stringify({ name: 'Visitor' }));

        const response = await fetch('/api/files/visitor-upload', {
          method: 'POST',
          body: formData
        });

        if (response.ok) {
          const data = await response.json();
          this.displayMessage(data.data);
        } else {
          throw new Error('Upload failed');
        }
      } catch (error) {
        console.error('File upload failed:', error);
        this.showError('File upload failed. Please try again.');
      }

      // Clear file input
      e.target.value = '';
    }

    async trackVisitor() {
      try {
        const visitorInfo = {
          location: await this.getLocationInfo(),
          browser: this.getBrowserInfo(),
          page: this.getPageInfo()
        };

        await fetch('/api/embed/visitor', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            widgetId: this.state.config.widgetId,
            visitorId: this.state.visitorId,
            info: visitorInfo
          })
        });
      } catch (error) {
        console.warn('Visitor tracking failed:', error);
      }
    }

    async getLocationInfo() {
      try {
        const response = await fetch('https://ipapi.co/json/');
        return await response.json();
      } catch {
        return {};
      }
    }

    getBrowserInfo() {
      const ua = navigator.userAgent;
      return {
        name: this.getBrowserName(ua),
        version: this.getBrowserVersion(ua),
        os: this.getOS(ua),
        language: navigator.language
      };
    }

    getPageInfo() {
      return {
        url: window.location.href,
        title: document.title,
        referrer: document.referrer
      };
    }

    getBrowserName(ua) {
      if (ua.includes('Chrome')) return 'Chrome';
      if (ua.includes('Firefox')) return 'Firefox';
      if (ua.includes('Safari')) return 'Safari';
      if (ua.includes('Edge')) return 'Edge';
      return 'Unknown';
    }

    getBrowserVersion(ua) {
      const match = ua.match(/(Chrome|Firefox|Safari|Edge)\/([0-9.]+)/);
      return match ? match[2] : 'Unknown';
    }

    getOS(ua) {
      if (ua.includes('Windows')) return 'Windows';
      if (ua.includes('Mac')) return 'macOS';
      if (ua.includes('Linux')) return 'Linux';
      if (ua.includes('Android')) return 'Android';
      if (ua.includes('iOS')) return 'iOS';
      return 'Unknown';
    }

    setupAutoOpen() {
      if (this.state.config.config.autoOpen) {
        setTimeout(() => {
          this.openWidget();
        }, this.state.config.config.openDelay);
      }

      // Add bounce animation
      if (this.state.config.config.animation === 'bounce') {
        setTimeout(() => {
          const button = document.getElementById('livechatm-button');
          if (button) button.classList.add('animate-bounce');
        }, 2000);
      }
    }

    playMessageSound() {
      if (!this.state.config.config.soundEnabled) return;
      
      try {
        const audioContext = new (window.AudioContext || window.webkitAudioContext)();
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();

        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);

        oscillator.frequency.setValueAtTime(523, audioContext.currentTime);
        oscillator.frequency.setValueAtTime(659, audioContext.currentTime + 0.1);

        gainNode.gain.setValueAtTime(0.2, audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.4);

        oscillator.start(audioContext.currentTime);
        oscillator.stop(audioContext.currentTime + 0.4);
      } catch (error) {
        console.warn('Could not play notification sound:', error);
      }
    }
  }

  // Initialize widget
  const widget = new EnhancedWidget();

  // Public API
  window.LiveChatM = {
    init: () => widget.init(),
    open: () => widget.openWidget(),
    close: () => widget.closeWidget(),
    toggle: () => widget.toggleWidget(),
    sendMessage: (message) => widget.sendMessage(message),
    getState: () => ({
      isConnected: widget.state.isConnected,
      isOnline: widget.state.isOnline,
      queuedMessages: widget.state.messageQueue.length
    })
  };

})();
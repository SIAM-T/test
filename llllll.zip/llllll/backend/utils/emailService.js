const nodemailer = require('nodemailer');

// Create transporter
const createTransporter = () => {
  // Check if email configuration exists
  if (!process.env.EMAIL_HOST || !process.env.EMAIL_USER || !process.env.EMAIL_PASS) {
    console.warn('Email configuration missing. Emails will not be sent.');
    return null;
  }

  return nodemailer.createTransport({
    host: process.env.EMAIL_HOST,
    port: parseInt(process.env.EMAIL_PORT) || 587,
    secure: process.env.EMAIL_PORT === '465', // true for 465, false for other ports
    auth: {
      user: process.env.EMAIL_USER,
      pass: process.env.EMAIL_PASS
    },
    tls: {
      rejectUnauthorized: false // For development
    }
  });
};

// Send email
const sendEmail = async (to, subject, html) => {
  try {
    const transporter = createTransporter();
    
    if (!transporter) {
      console.log(`Email would be sent to ${to}: ${subject}`);
      console.log('HTML Content:', html);
      return { success: false, message: 'Email configuration not available' };
    }
    
    const mailOptions = {
      from: `"LiveChatM" <${process.env.EMAIL_USER}>`,
      to,
      subject,
      html
    };

    const result = await transporter.sendMail(mailOptions);
    console.log(`Email sent successfully to ${to}`);
    return { success: true, messageId: result.messageId };
  } catch (error) {
    console.error('Email send error:', error);
    return { success: false, error: error.message };
  }
};

// Email templates
const emailTemplates = {
  emailVerification: (userName, token) => `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
      <div style="text-align: center; margin-bottom: 30px;">
        <h1 style="color: #2563eb; margin: 0;">Verify Your Email</h1>
      </div>
      <p style="font-size: 16px; color: #374151;">Hi ${userName},</p>
      <p style="font-size: 16px; color: #374151;">Thank you for signing up for LiveChatM! Please verify your email address to complete your registration.</p>
      <div style="background: #f3f4f6; padding: 20px; border-radius: 8px; margin: 20px 0;">
        <p style="margin: 0; color: #374151;">Click the button below to verify your email address:</p>
      </div>
      <div style="text-align: center; margin: 30px 0;">
        <a href="${process.env.FRONTEND_URL || 'http://localhost:5173'}/verify-email?token=${token}" 
           style="background: #2563eb; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">
          Verify Email Address
        </a>
      </div>
      <p style="color: #6b7280; font-size: 14px;">If you didn't create an account, please ignore this email.</p>
      <p style="color: #6b7280; font-size: 14px;">Best regards,<br>The LiveChatM Team</p>
    </div>
  `,
  
  welcome: (userName, organizationName) => `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
      <div style="text-align: center; margin-bottom: 30px;">
        <h1 style="color: #2563eb; margin: 0;">Welcome to LiveChatM!</h1>
      </div>
      <p style="font-size: 16px; color: #374151;">Hi ${userName},</p>
      <p style="font-size: 16px; color: #374151;">Welcome to <strong>${organizationName}</strong>! Your email has been verified and your account is now active.</p>
      <div style="background: #f3f4f6; padding: 20px; border-radius: 8px; margin: 20px 0;">
        <p style="margin: 0; color: #374151;">You can now start using LiveChatM to engage with your customers and grow your business.</p>
      </div>
      <div style="text-align: center; margin: 30px 0;">
        <a href="${process.env.FRONTEND_URL || 'http://localhost:5173'}/dashboard" 
           style="background: #2563eb; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">
          Go to Dashboard
        </a>
      </div>
      <p style="color: #6b7280; font-size: 14px;">Best regards,<br>The LiveChatM Team</p>
    </div>
  `,
  
  newConversation: (agentName, visitorName) => `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
      <h2 style="color: #2563eb;">New Conversation Alert</h2>
      <p>Hi ${agentName},</p>
      <p>You have a new conversation from <strong>${visitorName}</strong>.</p>
      <p>Please log in to your dashboard to respond.</p>
      <a href="${process.env.FRONTEND_URL || 'http://localhost:5173'}/dashboard" 
         style="background: #2563eb; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block; margin: 20px 0;">
        View Conversation
      </a>
    </div>
  `,
  
  conversationAssigned: (agentName, visitorName) => `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
      <h2 style="color: #2563eb;">Conversation Assigned</h2>
      <p>Hi ${agentName},</p>
      <p>A conversation with <strong>${visitorName}</strong> has been assigned to you.</p>
      <p>Please log in to your dashboard to respond.</p>
      <a href="${process.env.FRONTEND_URL || 'http://localhost:5173'}/dashboard" 
         style="background: #2563eb; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block; margin: 20px 0;">
        View Conversation
      </a>
    </div>
  `,
  
  passwordReset: (userName, resetToken) => `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
      <div style="text-align: center; margin-bottom: 30px;">
        <h1 style="color: #2563eb; margin: 0;">Reset Your Password</h1>
      </div>
      <p style="font-size: 16px; color: #374151;">Hi ${userName},</p>
      <p style="font-size: 16px; color: #374151;">You requested to reset your password for your LiveChatM account.</p>
      <div style="background: #f3f4f6; padding: 20px; border-radius: 8px; margin: 20px 0;">
        <p style="margin: 0; color: #374151;">Click the button below to reset your password. This link will expire in 1 hour.</p>
      </div>
      <div style="text-align: center; margin: 30px 0;">
        <a href="${process.env.FRONTEND_URL || 'http://localhost:5173'}/reset-password?token=${resetToken}" 
           style="background: #2563eb; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">
          Reset Password
        </a>
      </div>
      <p style="color: #6b7280; font-size: 14px;">If you didn't request this, please ignore this email.</p>
      <p style="color: #6b7280; font-size: 14px;">Best regards,<br>The LiveChatM Team</p>
    </div>
  `
};

// Test email configuration
const testEmailConfig = async () => {
  try {
    const transporter = createTransporter();
    if (!transporter) {
      return { success: false, message: 'Email configuration not available' };
    }
    
    await transporter.verify();
    return { success: true, message: 'Email configuration is valid' };
  } catch (error) {
    return { success: false, message: error.message };
  }
};

module.exports = {
  sendEmail,
  emailTemplates,
  testEmailConfig
};
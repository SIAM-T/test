const Visitor = require('../models/Visitor');

class VisitorNamingService {
  static async generateUniqueVisitorName(organizationId, widgetId) {
    try {
      // Get count of visitors for this organization
      const visitorCount = await Visitor.countDocuments({ 
        organizationId,
        widgetId 
      });
      
      return `Visitor #${visitorCount + 1}`;
    } catch (error) {
      console.error('Error generating visitor name:', error);
      return `Visitor #${Date.now()}`;
    }
  }

  static async getOrCreateVisitorName(visitorId, organizationId, widgetId) {
    try {
      let visitor = await Visitor.findOne({ visitorId });
      
      if (!visitor) {
        const name = await this.generateUniqueVisitorName(organizationId, widgetId);
        visitor = new Visitor({
          visitorId,
          organizationId,
          widgetId,
          info: { name },
          totalConversations: 1
        });
        await visitor.save();
        return name;
      }
      
      return visitor.info?.name || `Visitor #${visitor._id.toString().slice(-4)}`;
    } catch (error) {
      console.error('Error getting visitor name:', error);
      return `Visitor #${Date.now()}`;
    }
  }
}

module.exports = VisitorNamingService;
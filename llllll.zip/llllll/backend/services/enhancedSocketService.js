const jwt = require('jsonwebtoken');
const User = require('../models/User');
const Conversation = require('../models/Conversation');
const Message = require('../models/Message');
const messageDeduplication = require('./messageDeduplication');

class EnhancedSocketService {
  constructor(io) {
    this.io = io;
    this.connectedUsers = new Map();
    this.typingUsers = new Map();
    this.setupMiddleware();
    this.setupConnection();
  }

  setupMiddleware() {
    this.io.use(async (socket, next) => {
      try {
        const token = socket.handshake.auth.token;
        const userType = socket.handshake.auth.userType;
        
        if (userType === 'visitor') {
          socket.userType = 'visitor';
          socket.visitorId = socket.handshake.auth.visitorId;
          socket.widgetId = socket.handshake.auth.widgetId;
          return next();
        }

        if (!token) {
          return next(new Error('Authentication required'));
        }

        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        const user = await User.findById(decoded.userId).populate('organizationId');
        
        if (!user) {
          return next(new Error('User not found'));
        }

        socket.user = user;
        socket.userType = 'agent';
        next();
      } catch (error) {
        next(new Error('Authentication failed'));
      }
    });
  }

  setupConnection() {
    this.io.on('connection', (socket) => {
      console.log(`${socket.userType} connected: ${socket.id}`);
      
      if (socket.userType === 'agent') {
        this.handleAgentConnection(socket);
      } else if (socket.userType === 'visitor') {
        this.handleVisitorConnection(socket);
      }

      socket.on('disconnect', () => {
        this.handleDisconnection(socket);
      });
    });
  }

  async handleAgentConnection(socket) {
    try {
      // Update agent status
      await User.findByIdAndUpdate(socket.user._id, {
        isOnline: true,
        lastSeen: new Date()
      });

      // Store connection
      this.connectedUsers.set(socket.user._id.toString(), {
        socketId: socket.id,
        type: 'agent',
        organizationId: socket.user.organizationId._id
      });

      // Join organization room
      const orgRoom = `org_${socket.user.organizationId._id}`;
      socket.join(orgRoom);

      // Join assigned conversations
      const conversations = await Conversation.find({
        assignedAgent: socket.user._id,
        status: { $in: ['active', 'waiting'] }
      });

      conversations.forEach(conv => {
        socket.join(`conversation_${conv._id}`);
      });

      // Setup event handlers
      this.setupAgentEventHandlers(socket);

      // Notify organization
      socket.to(orgRoom).emit('agent_online', {
        agentId: socket.user._id,
        agentName: socket.user.name,
        timestamp: new Date()
      });

    } catch (error) {
      console.error('Agent connection error:', error);
    }
  }

  setupAgentEventHandlers(socket) {
    // Join conversation
    socket.on('join_conversation', async (data) => {
      const { conversationId } = data;
      
      const conversation = await Conversation.findOne({
        _id: conversationId,
        organizationId: socket.user.organizationId._id
      });

      if (conversation) {
        socket.join(`conversation_${conversationId}`);
        
        // Mark messages as read
        await Message.updateMany(
          {
            conversationId,
            'sender.type': 'visitor',
            isRead: false
          },
          {
            isRead: true,
            readAt: new Date()
          }
        );

        socket.emit('joined_conversation', { conversationId });
      }
    });

    // Send message with deduplication
    socket.on('send_message', async (data) => {
      try {
        const { conversationId, content } = data;
        
        // Generate message ID for deduplication
        const messageId = messageDeduplication.generateMessageId(
          conversationId,
          content,
          socket.user._id.toString(),
          Date.now()
        );

        // Check for duplicates
        if (await messageDeduplication.isDuplicate(messageId)) {
          console.log('Duplicate message detected, skipping');
          return;
        }

        const conversation = await Conversation.findOne({
          _id: conversationId,
          organizationId: socket.user.organizationId._id
        });

        if (!conversation) {
          socket.emit('message_error', { error: 'Conversation not found' });
          return;
        }

        // Create message
        const message = new Message({
          _id: messageId,
          conversationId,
          sender: {
            type: 'agent',
            id: socket.user._id,
            name: socket.user.name
          },
          content,
          messageType: 'text'
        });

        await message.save();

        // Update conversation
        await Conversation.findByIdAndUpdate(conversationId, {
          lastMessage: { content, timestamp: new Date() },
          updatedAt: new Date(),
          status: conversation.status === 'waiting' ? 'active' : conversation.status,
          assignedAgent: conversation.assignedAgent || socket.user._id
        });

        // Emit to conversation participants
        this.io.to(`conversation_${conversationId}`).emit('new_message', {
          _id: message._id,
          conversationId,
          content,
          sender: {
            type: 'agent',
            id: socket.user._id,
            name: socket.user.name
          },
          createdAt: message.createdAt,
          status: 'sent'
        });

        // Mark message as delivered after 1 second
        setTimeout(() => {
          this.io.to(`conversation_${conversationId}`).emit('message_status_update', {
            messageId: message._id,
            status: 'delivered'
          });
        }, 1000);

        // Emit to visitor widget
        this.io.to(`visitor_${conversation.visitorId}`).emit('agent_message', {
          _id: message._id,
          conversationId,
          message: {
            content,
            sender: { type: 'agent', name: socket.user.name },
            createdAt: message.createdAt
          }
        });

      } catch (error) {
        console.error('Send message error:', error);
        socket.emit('message_error', { error: 'Failed to send message' });
      }
    });

    // Typing indicators with cleanup
    socket.on('typing_start', (data) => {
      const { conversationId } = data;
      const typingKey = `${conversationId}_${socket.user._id}`;
      
      // Clear existing timeout
      if (this.typingUsers.has(typingKey)) {
        clearTimeout(this.typingUsers.get(typingKey));
      }

      // Set auto-cleanup timeout
      const timeout = setTimeout(() => {
        this.typingUsers.delete(typingKey);
        socket.to(`conversation_${conversationId}`).emit('agent_typing_stop', {
          agentId: socket.user._id,
          conversationId
        });
      }, 3000);

      this.typingUsers.set(typingKey, timeout);

      socket.to(`conversation_${conversationId}`).emit('agent_typing', {
        agentId: socket.user._id,
        agentName: socket.user.name,
        conversationId
      });
    });

    socket.on('typing_stop', (data) => {
      const { conversationId } = data;
      const typingKey = `${conversationId}_${socket.user._id}`;
      
      if (this.typingUsers.has(typingKey)) {
        clearTimeout(this.typingUsers.get(typingKey));
        this.typingUsers.delete(typingKey);
      }

      socket.to(`conversation_${conversationId}`).emit('agent_typing_stop', {
        agentId: socket.user._id,
        conversationId
      });
    });

    // Heartbeat
    socket.on('heartbeat', () => {
      socket.emit('heartbeat_ack', { timestamp: Date.now() });
    });
  }

  async handleVisitorConnection(socket) {
    try {
      // Store connection
      this.connectedUsers.set(socket.visitorId, {
        socketId: socket.id,
        type: 'visitor',
        widgetId: socket.widgetId
      });

      // Join visitor room
      socket.join(`visitor_${socket.visitorId}`);
      socket.join(`widget_${socket.widgetId}`);

      this.setupVisitorEventHandlers(socket);

    } catch (error) {
      console.error('Visitor connection error:', error);
    }
  }

  setupVisitorEventHandlers(socket) {
    socket.on('join_conversation', (data) => {
      const { conversationId } = data;
      socket.join(`conversation_${conversationId}`);
      socket.emit('joined_conversation', { conversationId });
    });

    socket.on('send_visitor_message', async (data) => {
      try {
        const { conversationId, content } = data;
        
        // Generate message ID for deduplication
        const messageId = messageDeduplication.generateMessageId(
          conversationId,
          content,
          socket.visitorId,
          Date.now()
        );

        if (await messageDeduplication.isDuplicate(messageId)) {
          return;
        }

        let conversation = await Conversation.findById(conversationId);
        if (!conversation) {
          socket.emit('message_error', { error: 'Conversation not found' });
          return;
        }

        const message = new Message({
          _id: messageId,
          conversationId,
          sender: {
            type: 'visitor',
            id: socket.visitorId
          },
          content,
          messageType: 'text'
        });

        await message.save();

        // Update conversation
        await Conversation.findByIdAndUpdate(conversationId, {
          lastMessage: { content, timestamp: new Date() },
          updatedAt: new Date()
        });

        // Emit to agents
        this.io.to(`conversation_${conversationId}`).emit('new_message', {
          _id: message._id,
          conversationId,
          content,
          sender: {
            type: 'visitor',
            id: socket.visitorId
          },
          createdAt: message.createdAt,
          status: 'delivered'
        });

        // Auto-mark as read when agent is active in conversation
        setTimeout(() => {
          this.io.to(`conversation_${conversationId}`).emit('message_status_update', {
            messageId: message._id,
            status: 'read'
          });
        }, 2000);

      } catch (error) {
        console.error('Visitor message error:', error);
        socket.emit('message_error', { error: 'Failed to send message' });
      }
    });

    // Visitor typing
    socket.on('typing_start', (data) => {
      const { conversationId } = data;
      const typingKey = `${conversationId}_${socket.visitorId}`;
      
      if (this.typingUsers.has(typingKey)) {
        clearTimeout(this.typingUsers.get(typingKey));
      }

      const timeout = setTimeout(() => {
        this.typingUsers.delete(typingKey);
        socket.to(`conversation_${conversationId}`).emit('visitor_typing_stop', {
          visitorId: socket.visitorId,
          conversationId
        });
      }, 3000);

      this.typingUsers.set(typingKey, timeout);

      socket.to(`conversation_${conversationId}`).emit('visitor_typing', {
        visitorId: socket.visitorId,
        conversationId
      });
    });

    socket.on('typing_stop', (data) => {
      const { conversationId } = data;
      const typingKey = `${conversationId}_${socket.visitorId}`;
      
      if (this.typingUsers.has(typingKey)) {
        clearTimeout(this.typingUsers.get(typingKey));
        this.typingUsers.delete(typingKey);
      }

      socket.to(`conversation_${conversationId}`).emit('visitor_typing_stop', {
        visitorId: socket.visitorId,
        conversationId
      });
    });
  }

  async handleDisconnection(socket) {
    try {
      if (socket.userType === 'agent' && socket.user) {
        // Update agent status
        await User.findByIdAndUpdate(socket.user._id, {
          isOnline: false,
          lastSeen: new Date()
        });

        // Clean up typing indicators
        for (const [key, timeout] of this.typingUsers.entries()) {
          if (key.includes(socket.user._id.toString())) {
            clearTimeout(timeout);
            this.typingUsers.delete(key);
          }
        }

        // Remove from connected users
        this.connectedUsers.delete(socket.user._id.toString());

        // Notify organization
        socket.to(`org_${socket.user.organizationId._id}`).emit('agent_offline', {
          agentId: socket.user._id,
          agentName: socket.user.name,
          timestamp: new Date()
        });

      } else if (socket.userType === 'visitor') {
        // Clean up visitor typing indicators
        for (const [key, timeout] of this.typingUsers.entries()) {
          if (key.includes(socket.visitorId)) {
            clearTimeout(timeout);
            this.typingUsers.delete(key);
          }
        }

        this.connectedUsers.delete(socket.visitorId);
      }
    } catch (error) {
      console.error('Disconnection error:', error);
    }
  }

  // Utility methods
  getConnectedAgents(organizationId) {
    const agents = [];
    for (const [userId, connection] of this.connectedUsers.entries()) {
      if (connection.type === 'agent' && connection.organizationId.toString() === organizationId.toString()) {
        agents.push(userId);
      }
    }
    return agents;
  }

  isUserOnline(userId) {
    return this.connectedUsers.has(userId.toString());
  }
}

module.exports = EnhancedSocketService;
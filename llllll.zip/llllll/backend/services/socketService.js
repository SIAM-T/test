const jwt = require('jsonwebtoken');
const User = require('../models/User');
const Conversation = require('../models/Conversation');
const Message = require('../models/Message');

const socketService = (io) => {
  // Middleware for socket authentication
  io.use(async (socket, next) => {
    try {
      const token = socket.handshake.auth.token;
      const userType = socket.handshake.auth.userType; // 'agent' or 'visitor'
      
      console.log('Socket auth attempt:', { userType, hasToken: !!token });
      
      if (userType === 'visitor') {
        // For visitors, we don't need JWT authentication
        socket.userType = 'visitor';
        socket.visitorId = socket.handshake.auth.visitorId;
        socket.widgetId = socket.handshake.auth.widgetId;
        console.log('Visitor authenticated:', socket.visitorId);
        return next();
      }

      if (!token) {
        console.log('No token provided for agent');
        return next(new Error('Authentication error'));
      }

      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      const user = await User.findById(decoded.userId).populate('organizationId');
      
      if (!user) {
        console.log('User not found:', decoded.userId);
        return next(new Error('User not found'));
      }

      socket.user = user;
      socket.userType = 'agent';
      console.log('Agent authenticated successfully:', user.name, user._id);
      next();
    } catch (error) {
      console.error('Socket auth error:', error.message);
      next(new Error('Authentication error'));
    }
  });

  io.on('connection', (socket) => {
    console.log(`${socket.userType} connected: ${socket.id}`);

    if (socket.userType === 'agent') {
      handleAgentConnection(socket, io);
    } else if (socket.userType === 'visitor') {
      handleVisitorConnection(socket, io);
    }

    socket.on('disconnect', () => {
      console.log(`${socket.userType} disconnected: ${socket.id}`);
      if (socket.userType === 'agent') {
        handleAgentDisconnection(socket);
      } else if (socket.userType === 'visitor') {
        handleVisitorDisconnection(socket);
      }
    });
  });
};

const handleAgentConnection = async (socket, io) => {
  try {
    console.log('Agent connecting:', socket.user.name, 'Org:', socket.user.organizationId._id);
    
    // Update agent online status
    await User.findByIdAndUpdate(socket.user._id, {
      isOnline: true,
      lastSeen: new Date()
    });

    // Join organization room
    const orgRoom = `org_${socket.user.organizationId._id}`;
    socket.join(orgRoom);
    console.log('Agent joined org room:', orgRoom);

    // Join assigned conversation rooms
    const assignedConversations = await Conversation.find({
      assignedAgent: socket.user._id,
      status: { $in: ['active', 'waiting'] }
    });

    assignedConversations.forEach(conv => {
      socket.join(`conversation_${conv._id}`);
    });

    // Notify organization about agent coming online
    socket.to(orgRoom).emit('agent_online', {
      agentId: socket.user._id,
      agentName: socket.user.name,
      timestamp: new Date()
    });

    // Handle joining specific conversations
    socket.on('join_conversation', async (data) => {
      const { conversationId } = data;
      
      // Verify conversation belongs to agent's organization
      const conversation = await Conversation.findOne({
        _id: conversationId,
        organizationId: socket.user.organizationId._id
      });

      if (conversation) {
        socket.join(`conversation_${conversationId}`);
        
        // Mark messages as read
        await Message.updateMany(
          {
            conversationId,
            'sender.type': 'visitor',
            isRead: false
          },
          {
            isRead: true,
            readAt: new Date()
          }
        );

        socket.emit('joined_conversation', { conversationId });
      }
    });

    // Handle leaving conversations
    socket.on('leave_conversation', (data) => {
      const { conversationId } = data;
      socket.leave(`conversation_${conversationId}`);
    });

    // Handle sending messages
    socket.on('send_message', async (data) => {
      try {
        const { conversationId, content, sender } = data;
        
        // Verify conversation belongs to agent's organization
        const conversation = await Conversation.findOne({
          _id: conversationId,
          organizationId: socket.user.organizationId._id
        });

        if (!conversation) {
          socket.emit('message_error', { error: 'Conversation not found' });
          return;
        }

        // Create message
        const message = new Message({
          conversationId,
          sender: {
            type: 'agent',
            id: socket.user._id,
            name: socket.user.name
          },
          content,
          messageType: 'text'
        });
        await message.save();

        // Update conversation
        conversation.lastMessage = {
          content,
          timestamp: new Date()
        };
        conversation.updatedAt = new Date();
        if (conversation.status === 'waiting') {
          conversation.status = 'active';
          conversation.assignedAgent = socket.user._id;
        }
        await conversation.save();

        // Emit to all clients in conversation
        io.to(`conversation_${conversationId}`).emit('new_message', {
          _id: message._id,
          conversationId,
          content,
          sender: {
            type: 'agent',
            id: socket.user._id,
            name: socket.user.name
          },
          createdAt: message.createdAt,
          status: 'sent'
        });

        // Status updates
        setTimeout(() => {
          io.to(`conversation_${conversationId}`).emit('message_status_update', {
            messageId: message._id,
            conversationId,
            status: 'delivered'
          });
        }, 1000);
        
        setTimeout(() => {
          io.to(`conversation_${conversationId}`).emit('message_status_update', {
            messageId: message._id,
            conversationId,
            status: 'read'
          });
        }, 3000);

        // Emit to widget if visitor is connected
        io.to(`visitor_${conversation.visitorId}`).emit('agent_message', {
          _id: message._id,
          conversationId,
          message: {
            content,
            sender: {
              type: 'agent',
              name: socket.user.name
            },
            createdAt: message.createdAt
          }
        });

      } catch (error) {
        console.error('Socket send message error:', error);
        socket.emit('message_error', { error: 'Failed to send message' });
      }
    });

    // Handle typing indicators with auto-stop
    socket.on('typing_start', (data) => {
      const { conversationId } = data;
      socket.to(`conversation_${conversationId}`).emit('agent_typing', {
        agentId: socket.user._id,
        agentName: socket.user.name,
        conversationId
      });
      
      // Auto-stop typing after 3 seconds
      clearTimeout(socket.typingTimeout);
      socket.typingTimeout = setTimeout(() => {
        socket.to(`conversation_${conversationId}`).emit('agent_typing_stop', {
          agentId: socket.user._id,
          conversationId
        });
      }, 3000);
    });

    socket.on('typing_stop', (data) => {
      const { conversationId } = data;
      clearTimeout(socket.typingTimeout);
      socket.to(`conversation_${conversationId}`).emit('agent_typing_stop', {
        agentId: socket.user._id,
        conversationId
      });
    });
    
    // Handle heartbeat
    socket.on('heartbeat', (data) => {
      socket.emit('heartbeat_ack', { timestamp: Date.now() });
    });
    
    // Handle conversation status updates
    socket.on('update_conversation_status', async (data) => {
      try {
        const { conversationId, status } = data;
        
        const conversation = await Conversation.findOneAndUpdate(
          {
            _id: conversationId,
            organizationId: socket.user.organizationId._id
          },
          { status, updatedAt: new Date() },
          { new: true }
        );
        
        if (conversation) {
          // Notify all clients in the organization
          io.to(`org_${socket.user.organizationId._id}`).emit('conversation_status_changed', {
            conversationId,
            status,
            updatedBy: socket.user._id,
            timestamp: new Date()
          });
        }
      } catch (error) {
        console.error('Error updating conversation status:', error);
        socket.emit('error', { message: 'Failed to update conversation status' });
      }
    });
    
    // Handle message read receipts
    socket.on('mark_messages_read', async (data) => {
      try {
        const { conversationId } = data;
        
        await Message.updateMany(
          {
            conversationId,
            'sender.type': 'visitor',
            isRead: false
          },
          {
            isRead: true,
            readAt: new Date()
          }
        );
        
        // Notify other agents
        socket.to(`conversation_${conversationId}`).emit('messages_marked_read', {
          conversationId,
          readBy: socket.user._id,
          timestamp: new Date()
        });
      } catch (error) {
        console.error('Error marking messages as read:', error);
      }
    });

  } catch (error) {
    console.error('Agent connection error:', error);
  }
};

const handleVisitorConnection = async (socket, io) => {
  try {
    console.log('Visitor connected:', socket.visitorId);
    
    // Join visitor room
    socket.join(`visitor_${socket.visitorId}`);
    
    // Join widget room
    socket.join(`widget_${socket.widgetId}`);

    // Handle joining conversations
    socket.on('join_conversation', async (data) => {
      const { conversationId } = data;
      console.log('Visitor joining conversation:', conversationId);
      
      // Join conversation room
      socket.join(`conversation_${conversationId}`);
      socket.emit('joined_conversation', { conversationId });
    });

    // Handle visitor typing
    socket.on('typing_start', (data) => {
      const { conversationId } = data;
      console.log('Visitor typing in:', conversationId);
      socket.to(`conversation_${conversationId}`).emit('visitor_typing', {
        visitorId: socket.visitorId,
        conversationId
      });
    });

    socket.on('typing_stop', (data) => {
      const { conversationId } = data;
      console.log('Visitor stopped typing in:', conversationId);
      socket.to(`conversation_${conversationId}`).emit('visitor_typing_stop', {
        visitorId: socket.visitorId,
        conversationId
      });
    });
    
    // Handle visitor sending messages
    socket.on('send_visitor_message', async (data) => {
      try {
        const { conversationId, content } = data;
        
        // Find or create conversation
        let conversation = await Conversation.findById(conversationId);
        if (!conversation) {
          // Create new conversation if it doesn't exist
          conversation = new Conversation({
            visitorId: socket.visitorId,
            widgetId: socket.widgetId,
            status: 'waiting',
            messages: []
          });
          await conversation.save();
          
          // Notify agents about new conversation
          io.emit('new_conversation', {
            conversationId: conversation._id,
            visitorId: socket.visitorId,
            widgetId: socket.widgetId,
            timestamp: new Date()
          });
        }
        
        // Create message
        const message = new Message({
          conversationId: conversation._id,
          sender: {
            type: 'visitor',
            id: socket.visitorId
          },
          content,
          messageType: 'text'
        });
        await message.save();
        
        // Update conversation
        conversation.lastMessage = {
          content,
          timestamp: new Date()
        };
        conversation.updatedAt = new Date();
        await conversation.save();
        
        // Emit to agents
        io.to(`conversation_${conversationId}`).emit('new_message', {
          _id: message._id,
          conversationId,
          content,
          sender: {
            type: 'visitor',
            id: socket.visitorId
          },
          createdAt: message.createdAt,
          status: 'delivered'
        });
        
      } catch (error) {
        console.error('Visitor message error:', error);
        socket.emit('message_error', { error: 'Failed to send message' });
      }
    });

  } catch (error) {
    console.error('Visitor connection error:', error);
  }
};

const handleAgentDisconnection = async (socket) => {
  try {
    if (socket.user && socket.user._id) {
      // Update agent offline status
      await User.findByIdAndUpdate(socket.user._id, {
        isOnline: false,
        lastSeen: new Date()
      });

      // Notify organization about agent going offline
      socket.to(`org_${socket.user.organizationId._id}`).emit('agent_offline', {
        agentId: socket.user._id,
        agentName: socket.user.name,
        timestamp: new Date()
      });
      
      // Emit agent status change
      socket.to(`org_${socket.user.organizationId._id}`).emit('agent_status_changed', {
        agentId: socket.user._id,
        status: 'offline',
        timestamp: new Date()
      });
    }
  } catch (error) {
    console.error('Agent disconnection error:', error);
  }
};

const handleVisitorDisconnection = async (socket) => {
  try {
    console.log('Visitor disconnected:', socket.visitorId);
  } catch (error) {
    console.error('Visitor disconnection error:', error);
  }
};

module.exports = socketService;
const Redis = require('redis');

class MessageDeduplicationService {
  constructor() {
    this.messageCache = new Map(); // Fallback if Redis not available
    this.initRedis();
  }

  async initRedis() {
    try {
      this.redis = Redis.createClient({
        host: process.env.REDIS_HOST || 'localhost',
        port: process.env.REDIS_PORT || 6379
      });
      await this.redis.connect();
    } catch (error) {
      console.warn('Redis not available, using in-memory cache');
    }
  }

  generateMessageId(conversationId, content, senderId, timestamp) {
    const data = `${conversationId}-${content}-${senderId}-${Math.floor(timestamp / 1000)}`;
    return require('crypto').createHash('md5').update(data).digest('hex');
  }

  async isDuplicate(messageId) {
    try {
      if (this.redis) {
        const exists = await this.redis.exists(`msg:${messageId}`);
        if (exists) return true;
        await this.redis.setex(`msg:${messageId}`, 300, '1'); // 5 min expiry
        return false;
      } else {
        if (this.messageCache.has(messageId)) return true;
        this.messageCache.set(messageId, true);
        setTimeout(() => this.messageCache.delete(messageId), 300000);
        return false;
      }
    } catch (error) {
      console.error('Deduplication check failed:', error);
      return false;
    }
  }

  async markProcessed(messageId) {
    try {
      if (this.redis) {
        await this.redis.setex(`msg:${messageId}`, 300, '1');
      } else {
        this.messageCache.set(messageId, true);
        setTimeout(() => this.messageCache.delete(messageId), 300000);
      }
    } catch (error) {
      console.error('Failed to mark message as processed:', error);
    }
  }
}

module.exports = new MessageDeduplicationService();
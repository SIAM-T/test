// Simple test to verify backend structure
const fs = require('fs');
const path = require('path');

console.log('🔍 Checking LiveChatM Backend Structure...\n');

const requiredFiles = [
  // Config
  'config/database.js',
  'config/jwt.js',
  'config/cloudinary.js',
  
  // Controllers
  'controllers/authController.js',
  'controllers/userController.js',
  'controllers/organizationController.js',
  'controllers/widgetController.js',
  'controllers/conversationController.js',
  'controllers/messageController.js',
  'controllers/agentController.js',
  'controllers/analyticsController.js',
  'controllers/fileController.js',
  'controllers/notificationController.js',
  'controllers/embedController.js',
  
  // Models
  'models/User.js',
  'models/Organization.js',
  'models/Widget.js',
  'models/Conversation.js',
  'models/Message.js',
  'models/Visitor.js',
  'models/Analytics.js',
  'models/Notification.js',
  
  // Routes
  'routes/auth.js',
  'routes/users.js',
  'routes/organizations.js',
  'routes/widgets.js',
  'routes/conversations.js',
  'routes/messages.js',
  'routes/agents.js',
  'routes/analytics.js',
  'routes/files.js',
  'routes/notifications.js',
  'routes/embed.js',
  
  // Middleware
  'middleware/auth.js',
  'middleware/validation.js',
  'middleware/upload.js',
  
  // Services
  'services/socketService.js',
  
  // Utils
  'utils/emailService.js',
  'utils/helpers.js',
  
  // Core files
  'server.js',
  'package.json',
  '.env'
];

let allFilesExist = true;

requiredFiles.forEach(file => {
  const filePath = path.join(__dirname, file);
  if (fs.existsSync(filePath)) {
    console.log(`✅ ${file}`);
  } else {
    console.log(`❌ ${file} - MISSING`);
    allFilesExist = false;
  }
});

console.log('\n📊 Backend Structure Summary:');
console.log(`Total files checked: ${requiredFiles.length}`);
console.log(`Status: ${allFilesExist ? '✅ ALL FILES PRESENT' : '❌ SOME FILES MISSING'}`);

if (allFilesExist) {
  console.log('\n🚀 Backend is COMPLETE and ready for production!');
  console.log('\n📋 Next steps:');
  console.log('1. npm install');
  console.log('2. Configure .env file');
  console.log('3. Start MongoDB');
  console.log('4. npm run dev');
} else {
  console.log('\n⚠️  Please create the missing files before running the backend.');
}
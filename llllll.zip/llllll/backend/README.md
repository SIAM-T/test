# LiveChatM Backend

A scalable and secure backend for the LiveChatM platform - a modern alternative to LiveChat.com built with the MERN stack.

## Features

- **Multi-tenant Architecture** - Complete organization isolation
- **Real-time Messaging** - Socket.io powered live chat
- **Widget System** - Embeddable chat widgets for customer websites
- **File Upload** - Cloudinary integration for file handling
- **Analytics** - Comprehensive performance metrics
- **Authentication** - JWT-based secure authentication
- **Role-based Access** - Owner, Admin, and Agent roles
- **Visitor Tracking** - Advanced visitor analytics
- **Notification System** - Real-time notifications

## Tech Stack

- **Node.js** - Runtime environment
- **Express.js** - Web framework
- **MongoDB** - Database with Mongoose ODM
- **Socket.io** - Real-time communication
- **JWT** - Authentication tokens
- **Cloudinary** - File storage and optimization
- **Bcrypt** - Password hashing
- **Nodemailer** - Email notifications

## Installation

1. Install dependencies:
```bash
npm install
```

2. Set up environment variables:
```bash
cp .env.example .env
# Edit .env with your configuration
```

3. Start MongoDB service

4. Run the server:
```bash
# Development
npm run dev

# Production
npm start
```

## Environment Variables

```env
NODE_ENV=development
PORT=5000
MONGODB_URI=mongodb://localhost:27017/livechatm
JWT_SECRET=your-super-secret-jwt-key
JWT_REFRESH_SECRET=your-super-secret-refresh-key
JWT_EXPIRE=7d
JWT_REFRESH_EXPIRE=30d

# Cloudinary Configuration
CLOUDINARY_CLOUD_NAME=your-cloudinary-name
CLOUDINARY_API_KEY=your-cloudinary-api-key
CLOUDINARY_API_SECRET=your-cloudinary-api-secret

# Email Configuration
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USER=your-email@gmail.com
EMAIL_PASS=your-app-password

# Widget CDN
WIDGET_CDN_URL=http://localhost:5000/widget
```

## API Endpoints

### Authentication
- `POST /api/auth/register` - Register new organization
- `POST /api/auth/login` - User login
- `POST /api/auth/refresh` - Refresh access token
- `POST /api/auth/logout` - User logout
- `GET /api/auth/me` - Get current user

### Organizations
- `GET /api/organizations` - Get organization details
- `PUT /api/organizations` - Update organization
- `POST /api/organizations/logo` - Upload organization logo
- `GET /api/organizations/stats` - Get organization statistics

### Users
- `GET /api/users` - Get all users in organization
- `POST /api/users` - Create new user (admin only)
- `PUT /api/users/:id` - Update user (admin only)
- `DELETE /api/users/:id` - Delete user (admin only)
- `GET /api/users/profile` - Get user profile
- `PUT /api/users/profile` - Update user profile
- `POST /api/users/avatar` - Upload user avatar

### Widgets
- `GET /api/widgets` - Get all widgets
- `POST /api/widgets` - Create new widget
- `PUT /api/widgets/:id` - Update widget
- `DELETE /api/widgets/:id` - Delete widget
- `GET /api/widgets/:id/embed` - Get embed code
- `GET /api/widgets/:id/stats` - Get widget statistics

### Conversations
- `GET /api/conversations` - Get all conversations
- `GET /api/conversations/:id` - Get conversation with messages
- `PUT /api/conversations/:id/assign` - Assign conversation to agent
- `PUT /api/conversations/:id/close` - Close conversation
- `PUT /api/conversations/:id/tags` - Update conversation tags
- `PUT /api/conversations/:id/rate` - Rate conversation

### Messages
- `POST /api/messages` - Send message from agent
- `POST /api/messages/visitor` - Send message from visitor
- `GET /api/messages/conversation/:id` - Get messages for conversation
- `PUT /api/messages/read` - Mark messages as read
- `DELETE /api/messages/:id` - Delete message

### Files
- `POST /api/files/upload` - Upload file for conversation
- `POST /api/files/visitor-upload` - Upload file from visitor
- `GET /api/files/:messageId` - Get file by message ID
- `DELETE /api/files/:messageId` - Delete file

### Analytics
- `GET /api/analytics/dashboard` - Get dashboard analytics
- `GET /api/analytics/conversations` - Get conversation analytics
- `GET /api/analytics/widgets` - Get widget analytics
- `GET /api/analytics/response-times` - Get response time analytics
- `GET /api/analytics/satisfaction` - Get satisfaction analytics
- `GET /api/analytics/export` - Export analytics data

### Agents
- `GET /api/agents` - Get all agents
- `GET /api/agents/:id/stats` - Get agent performance statistics
- `GET /api/agents/:id/conversations` - Get agent's conversations
- `PUT /api/agents/availability` - Update agent availability
- `GET /api/agents/workload` - Get agent workload
- `POST /api/agents/auto-assign/:conversationId` - Auto-assign conversation

### Notifications
- `GET /api/notifications` - Get user notifications
- `PUT /api/notifications/:id/read` - Mark notification as read
- `PUT /api/notifications/read-all` - Mark all notifications as read
- `DELETE /api/notifications/:id` - Delete notification
- `GET /api/notifications/settings` - Get notification settings
- `PUT /api/notifications/settings` - Update notification settings

### Widget Embed (Public)
- `GET /api/embed/config/:widgetId` - Get widget configuration
- `POST /api/embed/visitor` - Track visitor
- `GET /api/embed/status/:organizationId` - Get organization online status
- `POST /api/embed/conversation` - Start conversation from widget

## Database Models

### User
- Authentication and user management
- Role-based permissions (owner, admin, agent)
- Organization relationship
- Settings and preferences

### Organization
- Multi-tenant isolation
- Plan limits and settings
- Working hours configuration
- Domain restrictions

### Widget
- Customizable chat widget configuration
- Appearance and behavior settings
- Domain restrictions
- Usage statistics

### Conversation
- Chat session management
- Visitor information
- Agent assignment
- Status tracking and metadata

### Message
- Individual chat messages
- File attachments
- Read status and timestamps
- Sender information

### Visitor
- Website visitor tracking
- Session management
- Location and browser info
- Visit history

### Analytics
- Performance metrics
- Daily/hourly breakdowns
- Agent performance
- Widget statistics

### Notification
- System notifications
- Real-time alerts
- User preferences
- Read status

## Socket.io Events

### Agent Events
- `join_conversation` - Join conversation room
- `leave_conversation` - Leave conversation room
- `typing_start` - Start typing indicator
- `typing_stop` - Stop typing indicator
- `agent_online` - Agent comes online
- `agent_offline` - Agent goes offline

### Visitor Events
- `join_conversation` - Join conversation room
- `typing_start` - Start typing indicator
- `typing_stop` - Stop typing indicator
- `page_change` - Track page navigation

### Server Events
- `new_message` - New message received
- `agent_message` - Message from agent
- `visitor_message` - Message from visitor
- `agent_typing` - Agent is typing
- `visitor_typing` - Visitor is typing
- `new_notification` - New notification

## Security Features

- JWT authentication with refresh tokens
- Password hashing with bcrypt
- Input validation and sanitization
- Rate limiting
- CORS configuration
- XSS protection
- MongoDB injection prevention
- File upload security
- Domain restrictions for widgets

## Performance Optimizations

- Database indexing
- Query optimization
- Connection pooling
- Response compression
- Caching strategies
- Pagination
- File size limits

## Widget Integration

Customers can integrate the chat widget by adding this script to their website:

```html
<script>
  window.LiveChatMConfig = {
    widgetId: "your-widget-id",
    organizationId: "your-org-id"
  };
  (function() {
    var script = document.createElement('script');
    script.src = 'https://your-domain.com/widget/widget.min.js';
    script.async = true;
    document.head.appendChild(script);
  })();
</script>
```

## Development

The backend is designed to be:
- **Scalable** - Handles multiple organizations and high traffic
- **Secure** - Industry-standard security practices
- **Maintainable** - Clean code structure and documentation
- **Extensible** - Easy to add new features and integrations

## License

This project is proprietary software for LiveChatM platform.
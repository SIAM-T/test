const express = require('express');
const router = express.Router();
const { sendEmail, emailTemplates, testEmailConfig } = require('../utils/emailService');
const { auth } = require('../middleware/auth');

// Test email configuration
router.get('/email-config', async (req, res) => {
  try {
    const result = await testEmailConfig();
    res.json(result);
  } catch (error) {
    res.status(500).json({ 
      success: false, 
      message: 'Email test failed',
      error: error.message 
    });
  }
});

// Send test email
router.post('/send-email', auth, async (req, res) => {
  try {
    const { to, subject, message } = req.body;
    
    if (!to || !subject || !message) {
      return res.status(400).json({ 
        success: false, 
        message: 'Missing required fields: to, subject, message' 
      });
    }

    const result = await sendEmail(to, subject, message);
    res.json(result);
  } catch (error) {
    res.status(500).json({ 
      success: false, 
      message: 'Failed to send test email',
      error: error.message 
    });
  }
});

// Test welcome email
router.post('/welcome-email', auth, async (req, res) => {
  try {
    const { email, name, organizationName } = req.body;
    
    if (!email || !name || !organizationName) {
      return res.status(400).json({ 
        success: false, 
        message: 'Missing required fields: email, name, organizationName' 
      });
    }

    const welcomeHtml = emailTemplates.welcome(name, organizationName);
    const result = await sendEmail(email, 'Welcome to LiveChatM!', welcomeHtml);
    res.json(result);
  } catch (error) {
    res.status(500).json({ 
      success: false, 
      message: 'Failed to send welcome email',
      error: error.message 
    });
  }
});

module.exports = router;
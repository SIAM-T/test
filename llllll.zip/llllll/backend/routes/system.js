const express = require('express');
const router = express.Router();
const { testEmailConfig } = require('../utils/emailService');

// Test email configuration
router.get('/test-email', async (req, res) => {
  try {
    const result = await testEmailConfig();
    res.json(result);
  } catch (error) {
    res.status(500).json({ 
      success: false, 
      message: 'Email test failed',
      error: error.message 
    });
  }
});

// System health check
router.get('/health', (req, res) => {
  res.json({
    status: 'OK',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    environment: process.env.NODE_ENV,
    version: '1.0.0'
  });
});

module.exports = router;
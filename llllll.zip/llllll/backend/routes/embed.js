const express = require('express');
const Widget = require('../models/Widget');
const Organization = require('../models/Organization');

const router = express.Router();

// Serve widget script
router.get('/widget.js', async (req, res) => {
  try {
    const { org, widget } = req.query;
    
    // Set CORS headers for widget embedding
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET');
    res.header('Cross-Origin-Resource-Policy', 'cross-origin');
    res.header('Content-Type', 'application/javascript');
    
    // Get widget configuration
    let widgetConfig = {
      primaryColor: '#3B82F6',
      secondaryColor: '#F8FAFC',
      accentColor: '#10B981',
      textColor: '#1F2937',
      theme: 'light',
      borderRadius: 16,
      shadow: 'large',
      opacity: 100,
      position: 'bottom-right',
      size: 'medium',
      margin: 20,
      zIndex: 9999,
      animation: 'bounce',
      autoOpen: false,
      openDelay: 3000,
      minimizeAfter: 30000,
      soundEnabled: true,
      companyName: 'LiveChat',
      greeting: 'Hi! How can I help you today?',
      offlineMessage: 'We\'re currently offline. Leave us a message!',
      placeholder: 'Type your message...',
      showAvatar: true,
      showOnline: true,
      showTyping: true,
      showTimestamp: true,
      showRating: true,
      fileUpload: true,
      emojiPicker: true
    };

    if (org) {
      const organization = await Organization.findById(org);
      if (organization) {
        widgetConfig.companyName = organization.name;
        
        // Try to get widget config
        const widgetDoc = await Widget.findOne({ organizationId: org, isActive: true });
        if (widgetDoc && widgetDoc.config) {
          widgetConfig = { ...widgetConfig, ...widgetDoc.config };
        }
      }
    }

    const widgetScript = `
(function() {
  if (document.getElementById('livechatm-widget')) return;
  
  // Set global config
  window.LiveChatMConfig = {
    apiUrl: '${process.env.NODE_ENV === 'production' ? 'https://your-domain.com/api' : 'http://localhost:5000/api'}',
    organizationId: '${org || ''}',
    widgetId: '${widget || 'default'}'
  };
  
  var config = ${JSON.stringify(widgetConfig)};
  var isOpen = false;
  
  // Create widget container
  var container = document.createElement('div');
  container.id = 'livechatm-widget';
  container.style.cssText = 'position:fixed;z-index:' + (config.zIndex || 9999) + ';font-family:system-ui,-apple-system,sans-serif;';
  
  // Position widget
  var pos = config.position || 'bottom-right';
  var margin = config.margin || 20;
  if (pos.includes('bottom')) container.style.bottom = margin + 'px';
  if (pos.includes('top')) container.style.top = margin + 'px';
  if (pos.includes('right')) container.style.right = margin + 'px';
  if (pos.includes('left')) container.style.left = margin + 'px';
  
  // Create widget button
  var button = document.createElement('div');
  var sizes = { small: '48px', medium: '56px', large: '64px', 'extra-large': '72px' };
  var size = sizes[config.size] || '56px';
  var shadows = {
    small: '0 2px 8px rgba(0,0,0,0.1)',
    medium: '0 4px 12px rgba(0,0,0,0.15)',
    large: '0 8px 24px rgba(0,0,0,0.2)',
    'extra-large': '0 12px 32px rgba(0,0,0,0.25)'
  };
  
  button.style.cssText = 
    'width: ' + size + '; height: ' + size + ';' +
    'background: ' + (config.primaryColor || '#3B82F6') + ';' +
    'border-radius: ' + (config.borderRadius || 16) + 'px;' +
    'cursor: pointer; display: flex; align-items: center; justify-content: center;' +
    'box-shadow: ' + (shadows[config.shadow] || shadows.medium) + ';' +
    'transition: all 0.3s ease; opacity: ' + ((config.opacity || 100) / 100) + ';' +
    'border: none; outline: none;';
  
  button.innerHTML = '<svg width="24" height="24" fill="white" viewBox="0 0 24 24"><path d="M20 2H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h4l4 4 4-4h4c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z"/></svg>';
  
  // Add hover effects
  button.onmouseover = function() { this.style.transform = 'scale(1.1)'; };
  button.onmouseout = function() { this.style.transform = 'scale(1)'; };
  
  // Create chat window
  var chatWindow = document.createElement('div');
  var isMobileDevice = window.innerWidth <= 768;
  var isTablet = window.innerWidth > 768 && window.innerWidth <= 1024;
  chatWindow.style.cssText = 
    'position: fixed;' +
    (isMobileDevice ? 'top: 0; left: 0; right: 0; bottom: 0;' : 'bottom: ' + (parseInt(size) + 10) + 'px; right: ' + margin + 'px;') +
    'width: ' + (isMobileDevice ? '100vw' : isTablet ? '400px' : '380px') + ';' +
    'height: ' + (isMobileDevice ? '100vh' : isTablet ? '600px' : '550px') + ';' +
    (isMobileDevice ? '' : 'max-width: 95vw; max-height: 85vh;') +
    'background: white; border-radius: ' + (isMobileDevice ? '0' : '12px') + ';' +
    'box-shadow: 0 8px 32px rgba(0,0,0,0.2); display: none; flex-direction: column; overflow: hidden;' +
    'z-index: ' + ((config.zIndex || 9999) + 1) + ';';
  
  // Chat header
  var header = document.createElement('div');
  header.style.cssText = 
    'background: ' + (config.primaryColor || '#3B82F6') + '; color: white;' +
    'padding: ' + (isMobileDevice ? '20px 16px' : '16px') + ';' +
    'display: flex; justify-content: space-between; align-items: center;' +
    'min-height: ' + (isMobileDevice ? '60px' : '50px') + ';';
  header.innerHTML = 
    '<div>' +
      '<div style="font-weight: 600; font-size: 16px;">' + (config.companyName || 'LiveChat') + '</div>' +
      '<div style="font-size: 12px; opacity: 0.9;">' + (config.showOnline ? 'Online now' : 'We\\'ll reply soon') + '</div>' +
    '</div>' +
    '<button onclick="this.closest(\\'#livechatm-widget\\').querySelector(\\'[data-chat-window]\\').style.display=\\'none\\'" ' +
            'style="background:none;border:none;color:white;font-size:20px;cursor:pointer;padding:4px;">&times;</button>';
  
  // Chat body
  var body = document.createElement('div');
  body.style.cssText = 
    'flex: 1; padding: ' + (isMobileDevice ? '12px' : '16px') + ';' +
    'overflow-y: auto; background: #f9fafb; min-height: 0;';
  body.innerHTML = 
    '<div style="background: white; padding: 12px; border-radius: 8px; margin-bottom: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">' +
      '<div style="font-size: 14px; color: #374151;">' + (config.greeting || 'Hi! How can I help you today?') + '</div>' +
    '</div>';
  
  // Chat input
  var inputArea = document.createElement('div');
  inputArea.style.cssText = 
    'padding: ' + (isMobileDevice ? '16px' : '16px') + ';' +
    'border-top: 1px solid #e5e7eb; background: white; flex-shrink: 0;' +
    (isMobileDevice ? 'padding-bottom: ' + (window.innerHeight > 600 ? '20px' : '16px') + ';' : '');
  inputArea.innerHTML = 
    '<div style="display: flex; gap: 8px; align-items: end;">' +
      '<input type="text" placeholder="' + (config.placeholder || 'Type your message...') + '" ' +
             'style="flex: 1; padding: ' + (isMobileDevice ? '14px 12px' : '12px') + '; border: 1px solid #d1d5db; border-radius: 8px; outline: none; font-size: ' + (isMobileDevice ? '16px' : '14px') + '; min-height: ' + (isMobileDevice ? '48px' : '40px') + ';" ' +
             'onkeypress="if(event.key===\\'Enter\\') sendMessage()" />' +
      '<button onclick="sendMessage()" ' +
              'style="background: ' + (config.primaryColor || '#3B82F6') + '; color: white; border: none; padding: ' + (isMobileDevice ? '14px 18px' : '12px 16px') + '; border-radius: 8px; cursor: pointer; font-size: ' + (isMobileDevice ? '16px' : '14px') + '; min-height: ' + (isMobileDevice ? '48px' : '40px') + ';">Send</button>' +
    '</div>';
  
  // Cookie functions for unlimited persistence
  function setCookie(name, value, days) {
    var expires = '';
    if (days) {
      var date = new Date();
      date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
      expires = '; expires=' + date.toUTCString();
    } else {
      expires = '; expires=Fri, 31 Dec 9999 23:59:59 GMT'; // Unlimited validity
    }
    document.cookie = name + '=' + (value || '') + expires + '; path=/; SameSite=Lax';
  }
  
  function getCookie(name) {
    var nameEQ = name + '=';
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
      var c = ca[i];
      while (c.charAt(0) === ' ') c = c.substring(1, c.length);
      if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length, c.length);
    }
    return null;
  }
  
  // Socket.IO connection for real-time messages
  var socket = null;
  var visitorId = getCookie('livechatm_visitor_id') || localStorage.getItem('livechatm_visitor_id') || 'visitor_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
  var currentConversationId = getCookie('livechatm_conversation_id') || localStorage.getItem('livechatm_conversation_id') || null;
  
  // Store visitor ID in both cookie and localStorage for maximum persistence
  setCookie('livechatm_visitor_id', visitorId);
  localStorage.setItem('livechatm_visitor_id', visitorId);
  
  function connectSocket() {
    if (typeof io !== 'undefined') {
      socket = io(window.LiveChatMConfig.apiUrl.replace('/api', ''), {
        auth: {
          userType: 'visitor',
          visitorId: visitorId,
          widgetId: window.LiveChatMConfig.widgetId
        }
      });
      
      socket.on('connect', function() {
        console.log('Widget socket connected');
      });
      
      socket.on('new_message', function(data) {
        console.log('Widget received message:', data);
        if (data.sender.type === 'agent') {
          addAgentMessage(data.content, data.sender.name, new Date(data.createdAt));
        }
      });
      
      socket.on('agent_typing', function(data) {
        console.log('Agent typing:', data);
        showTypingIndicator(data.agentName);
      });
      
      socket.on('agent_typing_stop', function(data) {
        console.log('Agent stopped typing');
        hideTypingIndicator();
      });
      
      socket.on('connect', function() {
        console.log('Widget socket connected');
        if (currentConversationId) {
          socket.emit('join_conversation', { conversationId: currentConversationId });
        }
      });
    }
  }
  
  function addAgentMessage(message, agentName, timestamp) {
    var agentMsg = document.createElement('div');
    agentMsg.style.cssText = 
      'background: white; border: 1px solid #e5e7eb;' +
      'padding: ' + (isMobileDevice ? '14px' : '12px') + '; border-radius: 8px; margin-bottom: 12px;' +
      'margin-right: ' + (isMobileDevice ? '15%' : '20%') + '; word-wrap: break-word;';
    agentMsg.innerHTML = 
      '<div style="font-size: ' + (isMobileDevice ? '15px' : '14px') + '; color: #374151; line-height: 1.4;">' + escapeHtml(message) + '</div>' +
      '<div style="font-size: ' + (isMobileDevice ? '12px' : '11px') + '; color: #6b7280; margin-top: 4px;">' + escapeHtml(agentName || 'Support') + ' • ' + timestamp.toLocaleTimeString() + '</div>';
    body.appendChild(agentMsg);
    body.scrollTop = body.scrollHeight;
  }
  
  function escapeHtml(text) {
    var div = document.createElement('div');
    div.textContent = text || '';
    return div.innerHTML;
  }
  
  var typingIndicator = null;
  function showTypingIndicator(agentName) {
    if (typingIndicator) return;
    typingIndicator = document.createElement('div');
    typingIndicator.style.cssText = 'background: white; border: 1px solid #e5e7eb; padding: 12px; border-radius: 8px; margin-bottom: 12px; margin-right: 20%;';
    typingIndicator.innerHTML = 
      '<div style="display: flex; align-items: center; gap: 8px;">' +
        '<div style="font-size: 14px; color: #6b7280;">' + (agentName || 'Support') + ' is typing</div>' +
        '<div style="display: flex; gap: 2px;">' +
          '<div style="width: 4px; height: 4px; background: #6b7280; border-radius: 50%; animation: pulse 1.5s infinite;"></div>' +
          '<div style="width: 4px; height: 4px; background: #6b7280; border-radius: 50%; animation: pulse 1.5s infinite 0.2s;"></div>' +
          '<div style="width: 4px; height: 4px; background: #6b7280; border-radius: 50%; animation: pulse 1.5s infinite 0.4s;"></div>' +
        '</div>' +
      '</div>';
    body.appendChild(typingIndicator);
    body.scrollTop = body.scrollHeight;
  }
  
  function hideTypingIndicator() {
    if (typingIndicator) {
      body.removeChild(typingIndicator);
      typingIndicator = null;
    }
  }
  
  // Load Socket.IO library
  var socketScript = document.createElement('script');
  socketScript.src = window.LiveChatMConfig.apiUrl.replace('/api', '') + '/socket.io/socket.io.js';
  socketScript.onload = connectSocket;
  document.head.appendChild(socketScript);
  
  // Browser detection function
  function getBrowserName(userAgent) {
    if (userAgent.indexOf('Chrome') > -1) return 'Chrome';
    if (userAgent.indexOf('Firefox') > -1) return 'Firefox';
    if (userAgent.indexOf('Safari') > -1) return 'Safari';
    if (userAgent.indexOf('Edge') > -1) return 'Edge';
    if (userAgent.indexOf('Opera') > -1) return 'Opera';
    return 'Unknown';
  }
  
  // Add send message function
  window.sendMessage = function() {
    var input = inputArea.querySelector('input');
    var message = input.value.trim();
    if (!message) return;
    
    // Add user message
    var userMsg = document.createElement('div');
    userMsg.style.cssText = 
      'background: ' + (config.primaryColor || '#3B82F6') + '; color: white;' +
      'padding: ' + (isMobileDevice ? '14px' : '12px') + '; border-radius: 8px; margin-bottom: 12px;' +
      'margin-left: ' + (isMobileDevice ? '15%' : '20%') + '; text-align: right; word-wrap: break-word;';
    userMsg.innerHTML = 
      '<div style="font-size: ' + (isMobileDevice ? '15px' : '14px') + '; line-height: 1.4;">' + escapeHtml(message) + '</div>' +
      '<div style="font-size: ' + (isMobileDevice ? '12px' : '11px') + '; opacity: 0.8; margin-top: 4px;">You • ' + new Date().toLocaleTimeString() + '</div>';
    body.appendChild(userMsg);
    
    input.value = '';
    body.scrollTop = body.scrollHeight;
    
    // Show typing indicator
    if (socket && currentConversationId) {
      socket.emit('typing_start', { conversationId: currentConversationId });
      setTimeout(function() {
        socket.emit('typing_stop', { conversationId: currentConversationId });
      }, 1000);
    }
    
    // Send message to server
    fetch(window.LiveChatMConfig.apiUrl + '/conversations/widget-message', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        organizationId: window.LiveChatMConfig.organizationId,
        widgetId: window.LiveChatMConfig.widgetId,
        message: message,
        visitorId: visitorId,
        visitorInfo: {
          name: 'Visitor',
          userAgent: navigator.userAgent,
          url: window.location.href,
          title: document.title,
          referrer: document.referrer,
          timestamp: new Date().toISOString(),
          browser: getBrowserName(navigator.userAgent),
          os: navigator.platform
        }
      })
    }).then(function(response) {
      if (!response.ok) {
        throw new Error('HTTP ' + response.status + ': ' + response.statusText);
      }
      return response.json();
    }).then(function(data) {
      console.log('Message sent successfully:', data);
      currentConversationId = data.conversationId;
      
      // Store conversation ID in both cookie and localStorage for persistence
      setCookie('livechatm_conversation_id', currentConversationId);
      localStorage.setItem('livechatm_conversation_id', currentConversationId);
      
      // Join conversation room for real-time updates
      if (socket && currentConversationId) {
        socket.emit('join_conversation', { conversationId: currentConversationId });
      }
    }).catch(function(error) {
      console.error('Error sending message:', error);
      // Show error message in widget
      var errorMsg = document.createElement('div');
      errorMsg.style.cssText = 'background: #EF4444; color: white; padding: 8px 12px; border-radius: 6px; margin-bottom: 12px; text-align: center; font-size: 12px;';
      errorMsg.textContent = 'Failed to send message. Please try again.';
      body.appendChild(errorMsg);
      body.scrollTop = body.scrollHeight;
      setTimeout(function() { body.removeChild(errorMsg); }, 3000);
    });
  };
  
  chatWindow.setAttribute('data-chat-window', 'true');
  chatWindow.appendChild(header);
  chatWindow.appendChild(body);
  chatWindow.appendChild(inputArea);
  
  // Toggle chat window
  button.onclick = function() {
    isOpen = !isOpen;
    chatWindow.style.display = isOpen ? 'flex' : 'none';
  };
  
  container.appendChild(button);
  container.appendChild(chatWindow);
  document.body.appendChild(container);
  
  // Load previous conversation if exists
  if (currentConversationId) {
    fetch(window.LiveChatMConfig.apiUrl + '/conversations/public/' + currentConversationId, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json'
      }
    }).then(function(response) {
      if (response.ok) {
        return response.json();
      }
      throw new Error('Failed to load conversation');
    }).then(function(data) {
      if (data && data.messages) {
        // Clear existing messages except greeting
        var existingMessages = body.querySelectorAll('div:not(:first-child)');
        existingMessages.forEach(function(msg) { body.removeChild(msg); });
        
        // Add previous messages
        if (data.messages && Array.isArray(data.messages)) {
          data.messages.forEach(function(msg) {
            if (msg.sender && msg.sender.type === 'visitor') {
              var userMsg = document.createElement('div');
              userMsg.style.cssText = 'background: ' + (config.primaryColor || '#3B82F6') + '; color: white; padding: 12px; border-radius: 8px; margin-bottom: 12px; margin-left: 20%; text-align: right; word-wrap: break-word;';
              userMsg.innerHTML = '<div style="font-size: 14px;">' + escapeHtml(msg.content) + '</div><div style="font-size: 11px; opacity: 0.8; margin-top: 4px;">You • ' + new Date(msg.createdAt).toLocaleTimeString() + '</div>';
              body.appendChild(userMsg);
            } else if (msg.sender && msg.sender.type === 'agent') {
              addAgentMessage(msg.content, msg.sender.name, new Date(msg.createdAt));
            }
          });
        }
        body.scrollTop = body.scrollHeight;
      }
    }).catch(function(error) {
      console.log('Could not load previous messages:', error);
    });
  }
  
  // Auto-open after delay
  if (config.autoOpen && config.openDelay) {
    setTimeout(function() {
      if (!isOpen) button.click();
    }, config.openDelay);
  }
  
  // Animation effects and typing indicator
  var style = document.createElement('style');
  var animations = {
    bounce: '@keyframes bounce { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-10px); } } #livechatm-widget > div:first-child { animation: bounce 2s infinite; }',
    pulse: '@keyframes pulse { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.1); } } #livechatm-widget > div:first-child { animation: pulse 2s infinite; }',
    shake: '@keyframes shake { 0%, 100% { transform: translateX(0); } 25% { transform: translateX(-5px); } 75% { transform: translateX(5px); } } #livechatm-widget > div:first-child { animation: shake 0.5s infinite; }',
    glow: '@keyframes glow { 0%, 100% { box-shadow: 0 0 5px ' + config.primaryColor + '; } 50% { box-shadow: 0 0 20px ' + config.primaryColor + '; } } #livechatm-widget > div:first-child { animation: glow 2s infinite; }'
  };
  
  var styleContent = '@keyframes pulse { 0%, 100% { opacity: 0.4; } 50% { opacity: 1; } }';
  if (config.animation && config.animation !== 'none') {
    styleContent += animations[config.animation] || '';
  }
  
  style.textContent = styleContent;
  document.head.appendChild(style);
  
  console.log('LiveChatM Widget loaded successfully');
})();
`;

    res.send(widgetScript);
  } catch (error) {
    console.error('Widget embed error:', error);
    res.status(500).send('// Widget loading error');
  }
});

module.exports = router;
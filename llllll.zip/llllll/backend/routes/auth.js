const express = require('express');
const { registerValidation, loginValidation } = require('../middleware/validation');
const { auth } = require('../middleware/auth');
const authController = require('../controllers/authController');

const router = express.Router();

// Register new organization and owner
router.post('/register', registerValidation, authController.register);

// Login
router.post('/login', loginValidation, authController.login);

// Refresh token
router.post('/refresh', authController.refreshToken);

// Logout
router.post('/logout', auth, authController.logout);

// Get current user
router.get('/me', auth, authController.getMe);

// Forgot password
router.post('/forgot-password', authController.forgotPassword);

// Reset password
router.post('/reset-password', authController.resetPassword);

// Send verification email
router.post('/send-verification', auth, authController.sendVerificationEmail);

// Verify email
router.post('/verify-email', authController.verifyEmail);

module.exports = router;
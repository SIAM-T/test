const express = require('express');
const { auth } = require('../middleware/auth');
const messageController = require('../controllers/messageController');

const router = express.Router();

// All routes require authentication
router.post('/send', auth, messageController.sendMessage);
router.post('/visitor', messageController.sendVisitorMessage);
router.get('/:conversationId', auth, messageController.getMessages);
router.put('/read', auth, messageController.markAsRead);
router.delete('/:id', auth, messageController.deleteMessage);
router.get('/unread/count', auth, messageController.getUnreadCount);

module.exports = router;
const express = require('express');
const { auth } = require('../middleware/auth');
const conversationController = require('../controllers/conversationController');

const router = express.Router();

// Protected routes (require authentication)
router.get('/', auth, conversationController.getConversations);
router.get('/:id', auth, conversationController.getConversation);

// Public route for widget
router.get('/public/:id', conversationController.getConversationPublic);
router.post('/:id/assign', auth, conversationController.assignConversation);
router.put('/:id/status', auth, conversationController.updateStatus);
router.put('/:id/tags', auth, conversationController.updateTags);
router.get('/:id/stats', auth, conversationController.getStats);
router.post('/:id/messages', auth, conversationController.sendMessage);

// Public routes (no auth required for widget)
router.post('/widget-message', conversationController.handleWidgetMessage);
router.post('/:id/rate', conversationController.rateConversation);

module.exports = router;
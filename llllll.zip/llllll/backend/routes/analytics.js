const express = require('express');
const { auth } = require('../middleware/auth');
const analyticsController = require('../controllers/analyticsController');

const router = express.Router();

// Get analytics data
router.get('/', auth, analyticsController.getAnalytics);
router.get('/dashboard', auth, analyticsController.getAnalytics);

module.exports = router;
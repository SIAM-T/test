const express = require('express');
const { auth, adminAuth, requireEmailVerification } = require('../middleware/auth');
const organizationController = require('../controllers/organizationController');
const { checkMemberLimit, validatePlanDowngrade } = require('../middleware/planLimits');

const router = express.Router();

// Get organization details
router.get('/', auth, requireEmailVerification, organizationController.getOrganization);

// Update organization (owner/admin only)
router.put('/', auth, adminAuth, organizationController.updateOrganization);

// Update plan (owner only)
router.put('/update-plan', auth, (req, res, next) => {
  if (req.user.role !== 'owner') {
    return res.status(403).json({ message: 'Only organization owners can update plans' });
  }
  next();
}, validatePlanDowngrade, organizationController.updatePlan);

// Get organization stats
router.get('/stats', auth, organizationController.getStats);

// Update working hours (owner/admin only)
router.put('/working-hours', auth, adminAuth, organizationController.updateWorkingHours);

// Get plan limits
router.get('/limits', auth, organizationController.getLimits);

// Get organization members (owner/admin only)
router.get('/members', auth, adminAuth, organizationController.getMembers);

// Invite member (owner/admin only)
router.post('/invite', auth, requireEmailVerification, adminAuth, checkMemberLimit, organizationController.inviteMember);

// Remove member
router.delete('/members/:userId', auth, adminAuth, organizationController.removeMember);

// Leave organization
router.post('/leave', auth, organizationController.leaveOrganization);

module.exports = router;
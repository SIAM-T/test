const express = require('express');
const { auth, adminAuth } = require('../middleware/auth');
const { widgetValidation } = require('../middleware/validation');
const widgetController = require('../controllers/widgetController');

const router = express.Router();

// Get all widgets for organization
router.get('/', auth, widgetController.getWidgets);

// Get widget by ID
router.get('/:id', auth, widgetController.getWidget);

// Create new widget (admin only)
router.post('/', auth, adminAuth, widgetValidation, widgetController.createWidget);

// Update widget (admin only)
router.put('/:id', auth, adminAuth, widgetValidation, widgetController.updateWidget);

// Delete widget (soft delete)
router.delete('/:id', auth, adminAuth, widgetController.deleteWidget);

// Get widget embed code
router.get('/:id/embed', auth, widgetController.getEmbedCode);

// Get widget statistics
router.get('/:id/stats', auth, widgetController.getWidgetStats);

module.exports = router;
const express = require('express');
const { auth } = require('../middleware/auth');
const { upload, handleUploadError } = require('../middleware/upload');
const fileController = require('../controllers/fileController');

const router = express.Router();

// Upload file for conversation
router.post('/upload', auth, upload.single('file'), handleUploadError, fileController.uploadFile);

// Upload file from visitor (public endpoint)
router.post('/visitor-upload', upload.single('file'), handleUploadError, fileController.uploadVisitorFile);

// Get file by message ID
router.get('/:messageId', auth, fileController.getFile);

// Delete file
router.delete('/:messageId', auth, fileController.deleteFile);

// Get organization file usage statistics
router.get('/stats/usage', auth, fileController.getUsageStats);

// Get recent files
router.get('/recent/list', auth, fileController.getRecentFiles);

module.exports = router;
const express = require('express');
const { auth, adminAuth } = require('../middleware/auth');
const { upload, handleUploadError } = require('../middleware/upload');
const userController = require('../controllers/userController');

const router = express.Router();

// Get all users in organization
router.get('/', auth, userController.getUsers);

// Get user profile
router.get('/profile', auth, userController.getProfile);

// Update user profile
router.put('/profile', auth, userController.updateProfile);

// Upload avatar
router.post('/avatar', auth, upload.single('avatar'), handleUploadError, userController.uploadAvatar);

// Create new agent (admin only)
router.post('/', auth, adminAuth, userController.createUser);

// Update user (admin only)
router.put('/:id', auth, adminAuth, userController.updateUser);

// Delete user (admin only)
router.delete('/:id', auth, adminAuth, userController.deleteUser);

// Get online agents
router.get('/online', auth, userController.getOnlineAgents);

// Update user settings
router.put('/settings', auth, userController.updateSettings);

// Change password
router.put('/change-password', auth, userController.changePassword);

module.exports = router;
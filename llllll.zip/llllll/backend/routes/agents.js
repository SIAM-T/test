const express = require('express');
const { auth } = require('../middleware/auth');
const agentController = require('../controllers/agentController');

const router = express.Router();

// Get all agents in organization
router.get('/', auth, agentController.getAgents);

// Get agent performance statistics
router.get('/:id/stats', auth, agentController.getAgentStats);

// Get agent's active conversations
router.get('/:id/conversations', auth, agentController.getAgentConversations);

// Update agent availability
router.put('/availability', auth, agentController.updateAvailability);

// Get agent workload
router.get('/workload', auth, agentController.getWorkload);

// Auto-assign conversation to available agent
router.post('/auto-assign/:conversationId', auth, agentController.autoAssign);

module.exports = router;
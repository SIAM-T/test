const express = require('express');
const { auth } = require('../middleware/auth');
const { notificationController } = require('../controllers/notificationController');

const router = express.Router();

// Get notifications for user
router.get('/', auth, notificationController.getNotifications);

// Mark notification as read
router.put('/:id/read', auth, notificationController.markAsRead);

// Mark all notifications as read
router.put('/read-all', auth, notificationController.markAllAsRead);

// Delete notification
router.delete('/:id', auth, notificationController.deleteNotification);

// Get notification settings
router.get('/settings', auth, notificationController.getSettings);

// Update notification settings
router.put('/settings', auth, notificationController.updateSettings);

module.exports = router;